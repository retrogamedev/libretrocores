/*
  libco.aarch64 (2017-06-26)
  author: webgeek1234
  license: public domain

  ============================================================================
  RGDVR BUILD-TIME PATCH — full-file replacement of
  mupen64plus-libretro-nx/libretro-common/libco/aarch64.c, applied by the
  LibretroCores Makefile's `mupen64` target (backup .rgdvr-bak, cp this over,
  restore after build). NOT committed into the core repo.

  WHY: the upstream co_switch_aarch64 saves the general-purpose callee-saved
  registers (x19-x29) but NOT the callee-saved FLOATING-POINT registers d8-d15.
  The AArch64 PCS (AAPCS64 §6.1.2) requires the low 64 bits of v8-v15 (i.e.
  d8-d15) to be preserved across a call. retro_run() co_switches into the game
  coroutine and back; if it doesn't restore d8-d15, it violates the ABI contract
  with ITS caller (the host's emu_thread_func). Any double / NEON local the
  compiler parks in d8-d15 across the retro_run() call then comes back corrupted.

  Symptom that found this: emu_thread_func's `double target_ns` (the frame
  limiter period) read as 0 after retro_run -> no frame cap -> N64 ran flat-out /
  "up and down", while `core_fps` (a global, lives in memory) was fine. It was
  build-dependent ("random") because it hinged on whether codegen chose a d8-d15
  register for target_ns that build. The canonical byuu libco saves d8-d15; this
  webgeek1234 copy does not.

  FIX (3 additions, marked "RGDVR"):
    1. save d8-d15 into the register buffer (offsets 176..232, all unused before)
    2. restore d8-d15 from it on switch-in
    3. zero those slots in co_create so a fresh coroutine starts clean
  Buffer is uint64_t[64] (512 bytes) / co_create allocates size+512, so the
  176..239 byte window is well within bounds.
  ============================================================================
*/

#define LIBCO_C
#include "libco.h"
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#ifndef __APPLE__
#include <malloc.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

static thread_local uint64_t co_active_buffer[64];
static thread_local cothread_t co_active_handle;

asm (
      ".globl co_switch_aarch64\n"
      ".globl _co_switch_aarch64\n"
      "co_switch_aarch64:\n"
      "_co_switch_aarch64:\n"
      "  stp x8,  x9,  [x1]\n"
      "  stp x10, x11, [x1, #16]\n"
      "  stp x12, x13, [x1, #32]\n"
      "  stp x14, x15, [x1, #48]\n"
      "  str x19, [x1, #72]\n"
      "  stp x20, x21, [x1, #80]\n"
      "  stp x22, x23, [x1, #96]\n"
      "  stp x24, x25, [x1, #112]\n"
      "  stp x26, x27, [x1, #128]\n"
      "  stp x28, x29, [x1, #144]\n"
      "  mov x16, sp\n"
      "  stp x16, x30, [x1, #160]\n"
      "  stp d8,  d9,  [x1, #176]\n"   /* RGDVR: save callee-saved FP d8-d15 */
      "  stp d10, d11, [x1, #192]\n"   /* RGDVR */
      "  stp d12, d13, [x1, #208]\n"   /* RGDVR */
      "  stp d14, d15, [x1, #224]\n"   /* RGDVR */

      "  ldp x8,  x9,  [x0]\n"
      "  ldp x10, x11, [x0, #16]\n"
      "  ldp x12, x13, [x0, #32]\n"
      "  ldp x14, x15, [x0, #48]\n"
      "  ldr x19, [x0, #72]\n"
      "  ldp x20, x21, [x0, #80]\n"
      "  ldp x22, x23, [x0, #96]\n"
      "  ldp x24, x25, [x0, #112]\n"
      "  ldp x26, x27, [x0, #128]\n"
      "  ldp x28, x29, [x0, #144]\n"
      "  ldp d8,  d9,  [x0, #176]\n"   /* RGDVR: restore callee-saved FP d8-d15 */
      "  ldp d10, d11, [x0, #192]\n"   /* RGDVR */
      "  ldp d12, d13, [x0, #208]\n"   /* RGDVR */
      "  ldp d14, d15, [x0, #224]\n"   /* RGDVR */
      "  ldp x16, x17, [x0, #160]\n"
      "  mov sp, x16\n"
      "  br x17\n"
    );

/* ASM */
void co_switch_aarch64(cothread_t handle, cothread_t current);

static void crash(void)
{
   /* Called only if cothread_t entrypoint returns. */
   assert(0);
}

cothread_t co_create(unsigned int size, void (*entrypoint)(void))
{
	uint64_t *ptr     = NULL;
   cothread_t handle = 0;
   size              = (size + 1023) & ~1023;
#if HAVE_POSIX_MEMALIGN >= 1
   if (posix_memalign(&handle, 1024, size + 512) < 0)
      return 0;
#else
   handle            = memalign(1024, size + 512);
#endif

   if (!handle)
      return handle;

   ptr     = (uint64_t*)handle;
   /* Non-volatiles.  */
   ptr[0]  = 0; /* x8  */
   ptr[1]  = 0; /* x9  */
   ptr[2]  = 0; /* x10 */
   ptr[3]  = 0; /* x11 */
   ptr[4]  = 0; /* x12 */
   ptr[5]  = 0; /* x13 */
   ptr[6]  = 0; /* x14 */
   ptr[7]  = 0; /* x15 */
   ptr[8]  = 0; /* padding */
   ptr[9]  = 0; /* x19 */
   ptr[10] = 0; /* x20 */
   ptr[11] = 0; /* x21 */
   ptr[12] = 0; /* x22 */
   ptr[13] = 0; /* x23 */
   ptr[14] = 0; /* x24 */
   ptr[15] = 0; /* x25 */
   ptr[16] = 0; /* x26 */
   ptr[17] = 0; /* x27 */
   ptr[18] = 0; /* x28 */
   ptr[22] = 0; /* RGDVR: d8  */
   ptr[23] = 0; /* RGDVR: d9  */
   ptr[24] = 0; /* RGDVR: d10 */
   ptr[25] = 0; /* RGDVR: d11 */
   ptr[26] = 0; /* RGDVR: d12 */
   ptr[27] = 0; /* RGDVR: d13 */
   ptr[28] = 0; /* RGDVR: d14 */
   ptr[29] = 0; /* RGDVR: d15 */
   ptr[20] = (uintptr_t)ptr + size + 512 - 16; /* x30, stack pointer */
   ptr[19] = ptr[20]; /* x29, frame pointer */
   ptr[21] = (uintptr_t)entrypoint; /* PC (link register x31 gets saved here). */
   return handle;
}

cothread_t co_active(void)
{
   if (!co_active_handle)
      co_active_handle = co_active_buffer;
   return co_active_handle;
}

void co_delete(cothread_t handle)
{
   free(handle);
}

void co_switch(cothread_t handle)
{
   cothread_t co_previous_handle = co_active();
   co_switch_aarch64(co_active_handle = handle, co_previous_handle);
}

#ifdef __cplusplus
}
#endif
