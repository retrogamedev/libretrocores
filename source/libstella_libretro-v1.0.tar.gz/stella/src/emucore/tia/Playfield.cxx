//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include "Playfield.hxx"
#include "TIA.hxx"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Playfield::Playfield(uInt32 collisionMask)
  : myCollisionMaskDisabled{collisionMask}
{
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::reset()
{
  myPattern = 0;
  myReflected = false;
  myRefp = false;

  myPf0 = 0;
  myPf1 = 0;
  myPf2 = 0;

  myX = 0;

  myObjectColor = myDebugColor = 0;
  myColorLeft = myColorRight = 0;
  myColorP0 = myColorP1 = 0;
  myColorMode = ColorMode::normal;
  myScoreGlitch = false;
  myScoreHaste = 0;
  myDebugEnabled = false;

  collision = 0;

  updatePattern();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::pf0(uInt8 value)
{
  if (myPf0 == value >> 4U) return;

  // PF0 nibble changed — the low 4 bits of the 20-bit pattern shift in,
  // and any pixels already drawn on this line used the old pattern. The
  // early return above is an optimization.
  myTIA->flushLineCache();

  myPattern = (myPattern & 0x000FFFF0U) | static_cast<uInt32>(value >> 4U);
  myPf0 = value >> 4U;

  updatePattern();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::pf1(uInt8 value)
{
  if (myPf1 == value) return;

  // PF1 byte changed — bit-shuffled into the middle 8 bits of myPattern.
  myTIA->flushLineCache();

  myPattern = (myPattern & 0x000FF00FU)
    | ((value & 0x80U) >> 3U)
    | ((value & 0x40U) >> 1U)
    | ((value & 0x20U) << 1U)
    | ((value & 0x10U) << 3U)
    | ((value & 0x08U) << 5U)
    | ((value & 0x04U) << 7U)
    | ((value & 0x02U) << 9U)
    | ((value & 0x01U) << 11U);

  myPf1 = value;
  updatePattern();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::pf2(uInt8 value)
{
  if (myPf2 == value) return;

  // PF2 byte changed — slotted into the high 8 bits of myPattern.
  myTIA->flushLineCache();

  myPattern = (myPattern & 0x00000FFFU) | static_cast<uInt32>(value << 12U);
  myPf2 = value;

  updatePattern();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::ctrlpf(uInt8 value)
{
  const bool reflected = (value & 0x01U) > 0;
  const ColorMode colorMode = (value & 0x06U) == 0x02 ? ColorMode::score : ColorMode::normal;

  if (myReflected == reflected && myColorMode == colorMode) return;

  // CTRLPF affects reflect mode (right-half indexing) and score-mode color
  // selection — both change rendered output mid-line.
  myTIA->flushLineCache();

  myReflected = reflected;
  myColorMode = colorMode;
  myScoreHaste = (myColorMode == ColorMode::score && myScoreGlitch) ? 1 : 0;
  applyColors();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::toggleEnabled(bool enabled)
{
  myIsSuppressed = !enabled;

  updatePattern();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::toggleCollisions(bool enabled)
{
  // Only keep bit 15 active if collisions are disabled.
  myCollisionMaskEnabled = enabled ? 0xFFFF : (0x8000U | myCollisionMaskDisabled);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::setColor(uInt8 color)
{
  // COLUPF only feeds the playfield in normal mode — in score mode the
  // halves take colors from COLUP0/COLUP1 instead. The mode check is the
  // optimization that skips the flush when this color isn't visible.
  if (color != myObjectColor && myColorMode == ColorMode::normal) myTIA->flushLineCache();

  myObjectColor = color;
  applyColors();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::setColorP0(uInt8 color)
{
  // COLUP0 only feeds the playfield in score mode (left half).
  if (color != myColorP0 && myColorMode == ColorMode::score) myTIA->flushLineCache();

  myColorP0 = color;
  applyColors();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::setColorP1(uInt8 color)
{
  // COLUP1 only feeds the playfield in score mode (right half).
  if (color != myColorP1 && myColorMode == ColorMode::score) myTIA->flushLineCache();

  myColorP1 = color;
  applyColors();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::setScoreGlitch(bool enable)
{
  myScoreGlitch = enable;
  myScoreHaste = (myColorMode == ColorMode::score && myScoreGlitch) ? 1 : 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::setDebugColor(uInt8 color)
{
  // Debug palette override changed.
  myTIA->flushLineCache();
  // allow slight luminance variations without changing color
  if((color & 0xeU) == 0xe)
    color -= 2;
  if((color & 0xeU) == 0x0)
    color += 2;
  myDebugColor = color;
  applyColors();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::enableDebugColors(bool enabled)
{
  // Debug color source toggled.
  myTIA->flushLineCache();
  myDebugEnabled = enabled;
  applyColors();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::applyColorLoss()
{
  // PAL color-loss LSB flip on the rendered color.
  myTIA->flushLineCache();
  applyColors();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::nextLine()
{
  collision = myCollisionMaskDisabled;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::applyColors()
{
  if (myDebugEnabled)
    myColorLeft = myColorRight = myDebugColor;
  else
  {
    switch (myColorMode)
    {
      case ColorMode::normal:
        if (myTIA->colorLossActive())
          myColorLeft = myColorRight = myObjectColor |= 0x01U;
        else
          myColorLeft = myColorRight = myObjectColor &= 0xfeU;
        break;

      case ColorMode::score:
        if (myTIA->colorLossActive())
        {
          myColorLeft  = myColorP0 |= 0x01U;
          myColorRight = myColorP1 |= 0x01U;
        }
        else
        {
          myColorLeft  = myColorP0 &= 0xfeU;
          myColorRight = myColorP1 &= 0xfeU;
        }
        break;

      default:
        break;  // Not supposed to get here
    }
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
uInt8 Playfield::getColor() const
{
  if (!myDebugEnabled)
    return myX < static_cast<uInt16>(TIAConstants::H_PIXEL / 2 - myScoreHaste) ? myColorLeft : myColorRight;
  else
  {
    if (myX < static_cast<uInt16>(TIAConstants::H_PIXEL / 2 - myScoreHaste))
    {
      // left side:
      if(myX < 16)
        return myDebugColor - 2;    // PF0
      if(myX < 48)
        return myDebugColor;        // PF1
    }
    else
    {
      // right side:
      if(!myReflected)
      {
        if(myX < TIAConstants::H_PIXEL / 2 + 16)
          return myDebugColor - 2;  // PF0
        if(myX < TIAConstants::H_PIXEL / 2 + 48)
          return myDebugColor;      // PF1
      }
      else
      {
        if(myX < TIAConstants::H_PIXEL / 2 + 32)
          return myDebugColor - 2;  // PF2
        if(myX < TIAConstants::H_PIXEL / 2 + 64)
          return myDebugColor;      // PF1
      }
    }
    return myDebugColor + 2;        // PF2/PF0
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void Playfield::updatePattern()
{
  myEffectivePattern = myIsSuppressed ? 0 : myPattern;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool Playfield::save(Serializer& out) const
{
  try
  {
    out.putInt(collision);
    out.putInt(myCollisionMaskDisabled);
    out.putInt(myCollisionMaskEnabled);

    out.putBool(myIsSuppressed);

    out.putByte(myColorLeft);
    out.putByte(myColorRight);
    out.putByte(myColorP0);
    out.putByte(myColorP1);
    out.putByte(myObjectColor);
    out.putByte(myDebugColor);
    out.putBool(myDebugEnabled);

    out.putByte(std::to_underlying(myColorMode));
    out.putBool(myScoreGlitch);

    out.putInt(myPattern);
    out.putInt(myEffectivePattern);
    out.putBool(myRefp);
    out.putBool(myReflected);

    out.putByte(myPf0);
    out.putByte(myPf1);
    out.putByte(myPf2);

    out.putInt(myX);
  }
  catch(...)
  {
    cerr << "ERROR: TIA_Playfield::save\n";
    return false;
  }

  return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool Playfield::load(Serializer& in)
{
  try
  {
    collision = in.getInt();
    myCollisionMaskDisabled = in.getInt();
    myCollisionMaskEnabled = in.getInt();

    myIsSuppressed = in.getBool();

    myColorLeft = in.getByte();
    myColorRight = in.getByte();
    myColorP0 = in.getByte();
    myColorP1 = in.getByte();
    myObjectColor = in.getByte();
    myDebugColor = in.getByte();
    myDebugEnabled = in.getBool();

    myColorMode = static_cast<ColorMode>(in.getByte());
    myScoreGlitch = in.getBool();
    myScoreHaste = myColorMode == ColorMode::score && myScoreGlitch ? 1 : 0;

    myPattern = in.getInt();
    myEffectivePattern = in.getInt();
    myRefp = in.getBool();
    myReflected = in.getBool();

    myPf0 = in.getByte();
    myPf1 = in.getByte();
    myPf2 = in.getByte();

    myX = in.getInt();

    applyColors();
    updatePattern();
  }
  catch(...)
  {
    cerr << "ERROR: TIA_Playfield::load\n";
    return false;
  }

  return true;
}
