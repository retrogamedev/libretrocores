//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#ifndef CARTRIDGE_SB_HXX
#define CARTRIDGE_SB_HXX

#include "bspf.hxx"
#include "CartEnhanced.hxx"
#include "System.hxx"
#ifdef DEBUGGER_SUPPORT
  #include "CartSBWidget.hxx"
#endif

/**
  Cartridge class used for SB "SUPERbanking" 128K-256K bankswitched games.
  Like the 0840 and UA schemes, SB places its hotspots in the lower address
  space (below $1000) rather than near $1FF0: accessing $0800-$081F selects
  one of 32 banks (128K), and $0800-$083F selects one of 64 banks (256K).
  The low bits of the hotspot address give the bank number directly.  The
  entire hotspot block mirrors at $0900, $0A00, etc. through $0FFF.  ROM
  size is variable; the constructor auto-detects 128K vs. 256K from the
  image size.

  @author  Fred X. Quimby, Thomas Jentzsch
*/
class CartridgeSB : public CartridgeEnhanced
{
  friend class CartridgeSBWidget;

  public:
    /**
      Create a new cartridge using the specified image

      @param image     Span of the ROM image
      @param md5       The md5sum of the ROM image
      @param settings  A reference to the various settings (read-only)
      @param bsSize    The size specified by the bankswitching scheme
                       (where 0 means variable-sized ROM)
    */
    CartridgeSB(ByteSpan image, string_view md5,
                const Settings& settings, size_t bsSize = 0);
    ~CartridgeSB() override = default;

  public:
    /**
      Install cartridge in the specified system.  Invoked by the system
      when the cartridge is attached to it.

      @param system The system the device should install itself in
    */
    void install(System& system) override;

    /**
      Get a descriptor for the device name (used in error checking).

      @return The name of the object
    */
    string name() const override { return "CartridgeSB"; }

  #ifdef DEBUGGER_SUPPORT
    /**
      Get debugger widget responsible for accessing the inner workings
      of the cart.
    */
    CartDebugWidget* debugWidget(GuiObject* boss, const GUI::Font& lfont,
        const GUI::Font& nfont) override
    {
      return new CartridgeSBWidget(boss, lfont, nfont, *this);
    }
  #endif

  public:
    /**
      Get the byte at the specified address.

      @return The byte at the specified address
    */
    uInt8 peek(uInt16 address) override;

    /**
      Change the byte at the specified address to the given value

      @param address The address where the value should be stored
      @param value The value to be stored at the address
      @return  True if the poke changed the device address space, else false
    */
    bool poke(uInt16 address, uInt8 value) override;

    uInt16 hotspot() const override { return 0x0800; }

  private:
    bool checkSwitchBank(uInt16 address, uInt8) override;
    uInt16 getStartBank() const override { return romBankCount() - 1; }

  private:
    // Previous Device's page access
    std::array<System::PageAccess, 8> myHotSpotPageAccess;

  private:
    // Following constructors and assignment operators not supported
    CartridgeSB() = delete;
    CartridgeSB(const CartridgeSB&) = delete;
    CartridgeSB(CartridgeSB&&) = delete;
    CartridgeSB& operator=(const CartridgeSB&) = delete;
    CartridgeSB& operator=(CartridgeSB&&) = delete;
};

#endif  // CARTRIDGE_SB_HXX
