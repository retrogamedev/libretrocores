//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#ifndef CARTRIDGE_JANE_HXX
#define CARTRIDGE_JANE_HXX

#include "CartEnhanced.hxx"
#ifdef DEBUGGER_SUPPORT
#include "CartJANEWidget.hxx"
#endif

/**
  Cartridge class used for the Tarzan prototype (scheme name "JANE").  There
  are four 4K banks selected by reading four non-contiguous hotspots:
  $1FF0 (bank 0), $1FF1 (bank 1), $1FF8 (bank 2), $1FF9 (bank 3).  The
  scheme was reverse-engineered from the prototype ROM; "JANE" is the name
  assigned by Stella.  Note that the hotspots overlap with the standard F8
  positions ($1FF8/$1FF9) but also include $1FF0/$1FF1, and the cart starts
  in bank 1 rather than bank 0.

  @author  Thomas Jentzsch
*/
class CartridgeJANE : public CartridgeEnhanced
{
  friend class CartridgeJANEWidget;

  public:
    /**
      Create a new cartridge using the specified image

      @param image     Span of the ROM image
      @param md5       The md5sum of the ROM image
      @param settings  A reference to the various settings (read-only)
      @param bsSize    The size specified by the bankswitching scheme
    */
    CartridgeJANE(ByteSpan image, string_view md5,
                  const Settings& settings, size_t bsSize = 16_KB);
    ~CartridgeJANE() override = default;

  public:
    /**
      Get a descriptor for the device name (used in error checking).

      @return The name of the object
    */
    string name() const override { return "CartridgeJANE"; }

  #ifdef DEBUGGER_SUPPORT
    /**
      Get debugger widget responsible for accessing the inner workings
      of the cart.
    */
    CartDebugWidget* debugWidget(GuiObject* boss, const GUI::Font& lfont,
                                 const GUI::Font& nfont) override
    {
      return new CartridgeJANEWidget(boss, lfont, nfont, *this);
    }
  #endif

    uInt16 hotspot() const override { return 0x1FF0; }

  private:
    bool checkSwitchBank(uInt16 address, uInt8 value) override;
    uInt16 getStartBank() const override { return 1; }

  private:
    // Following constructors and assignment operators not supported
    CartridgeJANE() = delete;
    CartridgeJANE(const CartridgeJANE&) = delete;
    CartridgeJANE(CartridgeJANE&&) = delete;
    CartridgeJANE& operator=(const CartridgeJANE&) = delete;
    CartridgeJANE& operator=(CartridgeJANE&&) = delete;
};

#endif  // CARTRIDGE_JANE_HXX
