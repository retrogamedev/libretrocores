//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include "Dialog.hxx"
#include "Font.hxx"
#include "EventHandler.hxx"
#include "FrameBuffer.hxx"
#include "FBSurface.hxx"
#include "OSystem.hxx"
#include "Icon.hxx"
#include "Widget.hxx"
#include "StateManager.hxx"
#include "RewindManager.hxx"
#include "TimeLineWidget.hxx"
#include "TIASurface.hxx"

#include "Console.hxx"
#include "TIA.hxx"
#include "System.hxx"

#include "TimeMachineDialog.hxx"
#include "Layout.hxx"
#include "Base.hxx"

// This dialog is a compact translucent HUD bar with fixed-size icon buttons, so
// it deliberately uses its own tight metrics rather than the standard Dialog
// form helpers (hBorder()/buttonGap()/buttonHeight()/...).
static constexpr int BUTTON_W = 14, BUTTON_H = 14;
static constexpr int H_BORDER = 6, V_BORDER = 4, BUTTON_GAP = 4;
static constexpr int BUTTON_WIDTH = BUTTON_W + 10, BUTTON_HEIGHT = BUTTON_H + 10;

static constexpr std::array<uInt32, BUTTON_H> RECORD_BITS = {
  0b00000111100000,
  0b00011111111000,
  0b00111111111100,
  0b01111111111110,
  0b01111111111110,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b01111111111110,
  0b01111111111110,
  0b00111111111100,
  0b00011111111000,
  0b00000111100000
};
static constexpr GUI::Icon RECORD(BUTTON_W, BUTTON_H, RECORD_BITS);
static constexpr std::array<uInt32, BUTTON_H> STOP_BITS = {
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111
};
static constexpr GUI::Icon STOP(BUTTON_W, BUTTON_H, STOP_BITS);
static constexpr std::array<uInt32, BUTTON_H> EXIT_BITS = {
  0b01100000000110,
  0b11110000001111,
  0b11111000011111,
  0b01111100111110,
  0b00111111111100,
  0b00011111111000,
  0b00001111110000,
  0b00001111110000,
  0b00011111111000,
  0b00111111111100,
  0b01111100111110,
  0b11111000011111,
  0b11110000001111,
  0b01100000000110
};
static constexpr GUI::Icon EXIT(BUTTON_W, BUTTON_H, EXIT_BITS);

static constexpr std::array<uInt32, BUTTON_H> REWIND_ALL_BITS = {
  0,
  0b11000011000011,
  0b11000111000111,
  0b11001111001111,
  0b11011111011111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11011111011111,
  0b11001111001111,
  0b11000111000111,
  0b11000011000011,
  0
};
static constexpr GUI::Icon REWIND_ALL(BUTTON_W, BUTTON_H, REWIND_ALL_BITS);
static constexpr std::array<uInt32, BUTTON_H> REWIND_1_BITS = {
  0,
  0b00000110001110,
  0b00001110001110,
  0b00011110001110,
  0b00111110001110,
  0b01111110001110,
  0b11111110001110,
  0b11111110001110,
  0b01111110001110,
  0b00111110001110,
  0b00011110001110,
  0b00001110001110,
  0b00000110001110,
  0
};
static constexpr GUI::Icon REWIND_1(BUTTON_W, BUTTON_H, REWIND_1_BITS);
static constexpr std::array<uInt32, BUTTON_H> PLAYBACK_BITS = {
  0b11000000000000,
  0b11110000000000,
  0b11111100000000,
  0b11111111000000,
  0b11111111110000,
  0b11111111111100,
  0b11111111111111,
  0b11111111111111,
  0b11111111111100,
  0b11111111110000,
  0b11111111000000,
  0b11111100000000,
  0b11110000000000,
  0b11000000000000
};
static constexpr GUI::Icon PLAYBACK(BUTTON_W, BUTTON_H, PLAYBACK_BITS);
static constexpr std::array<uInt32, BUTTON_H> UNWIND_1_BITS = {
  0,
  0b01110001100000,
  0b01110001110000,
  0b01110001111000,
  0b01110001111100,
  0b01110001111110,
  0b01110001111111,
  0b01110001111111,
  0b01110001111110,
  0b01110001111100,
  0b01110001111000,
  0b01110001110000,
  0b01110001100000,
  0
};
static constexpr GUI::Icon UNWIND_1(BUTTON_W, BUTTON_H, UNWIND_1_BITS);
static constexpr std::array<uInt32, BUTTON_H> UNWIND_ALL_BITS = {
  0,
  0b11000011000011,
  0b11100011100011,
  0b11110011110011,
  0b11111011111011,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111111111111,
  0b11111011111011,
  0b11110011110011,
  0b11100011100011,
  0b11000011000011,
  0
};
static constexpr GUI::Icon UNWIND_ALL(BUTTON_W, BUTTON_H, UNWIND_ALL_BITS);
static constexpr std::array<uInt32, BUTTON_H> SAVE_ALL_BITS = {
  0b00000111100000,
  0b00000111100000,
  0b00000111100000,
  0b00000111100000,
  0b11111111111111,
  0b01111111111110,
  0b00111111111100,
  0b00011111111000,
  0b00001111110000,
  0b00000111100000,
  0b00000011000000,
  0b00000000000000,
  0b11111111111111,
  0b11111111111111,
};
static constexpr GUI::Icon SAVE_ALL(BUTTON_W, BUTTON_H, SAVE_ALL_BITS);
static constexpr std::array<uInt32, BUTTON_H> LOAD_ALL_BITS = {
  0b00000011000000,
  0b00000111100000,
  0b00001111110000,
  0b00011111111000,
  0b00111111111100,
  0b01111111111110,
  0b11111111111111,
  0b00000111100000,
  0b00000111100000,
  0b00000111100000,
  0b00000111100000,
  0b00000000000000,
  0b11111111111111,
  0b11111111111111,
};
static constexpr GUI::Icon LOAD_ALL(BUTTON_W, BUTTON_H, LOAD_ALL_BITS);

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
TimeMachineDialog::TimeMachineDialog(OSystem& osystem, DialogContainer& parent,
                                     int width)
  : Dialog(osystem, parent)
{
  const GUI::Font& font = instance().frameBuffer().font();

  // The parent determines our width (based on window size); our height is
  // whatever the two rows turn out to need (see layout())
  _w = width;

  this->clearFlags(Widget::Flag::ClearBG); // does only work combined with blending (0..100)!
  this->clearFlags(Widget::Flag::Border);
  this->setFlags(Widget::Flag::NoBG);

  // Widgets are only created here (at placeholder positions); layout() assigns
  // all geometry from the current font and dialog width.

  // NOLINTBEGIN(cppcoreguidelines-prefer-member-initializer)
  // Index info (current + last state index)
  myCurrentIdxWidget = new LabelWidget(this, font, "1000", TextAlign::Left, kBGColor);
  myCurrentIdxWidget->setTextColor(kColorInfo);
  myCurrentIdxWidget->setFlags(Widget::Flag::ClearBG | Widget::Flag::NoBG);
  myLastIdxWidget = new LabelWidget(this, font, "1000", TextAlign::Right, kBGColor);
  myLastIdxWidget->setFlags(Widget::Flag::ClearBG | Widget::Flag::NoBG);
  myLastIdxWidget->setTextColor(kColorInfo);

  // Timeline scrubber
  myTimeline = new TimeLineWidget(this, font, Cmd::Timeline);
  myTimeline->setMinValue(0);

  // Time info (current + last time)
  myCurrentTimeWidget = new LabelWidget(this, font, "00:00.00", TextAlign::Left, kBGColor);
  myCurrentTimeWidget->setFlags(Widget::Flag::ClearBG | Widget::Flag::NoBG);
  myCurrentTimeWidget->setTextColor(kColorInfo);
  myLastTimeWidget = new LabelWidget(this, font, "00:00.00", TextAlign::Right, kBGColor);
  myLastTimeWidget->setFlags(Widget::Flag::ClearBG | Widget::Flag::NoBG);
  myLastTimeWidget->setTextColor(kColorInfo);

  // Buttons
  myToggleWidget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                    STOP, Cmd::Toggle);
  myToggleWidget->setToolTip("Toggle Time Machine mode.");
  myExitWidget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                  EXIT, Cmd::Exit);
  myExitWidget->setToolTip("Exit Time Machine dialog.");
  myRewindAllWidget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                       REWIND_ALL,
                                       Cmd::RewindAll);
  myRewind1Widget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                     REWIND_1, Cmd::Rewind1,
                                     true);
  myPlayBackWidget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                      PLAYBACK, Cmd::PlayBack);
  myPlayBackWidget->setToolTip("Start playback of Time Machine states.");
  myUnwind1Widget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                     UNWIND_1, Cmd::Unwind1,
                                     true);
  myUnwindAllWidget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                       UNWIND_ALL,
                                       Cmd::UnwindAll);
  mySaveAllWidget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                     SAVE_ALL, Cmd::SaveAll);
  mySaveAllWidget->setToolTip("Save all Time Machine states.");
  myLoadAllWidget = new ButtonWidget(this, font, BUTTON_WIDTH, BUTTON_HEIGHT,
                                     LOAD_ALL, Cmd::LoadAll);
  myLoadAllWidget->setToolTip("Load all Time Machine states.");

  // Message (fills the space between the buttons and the last-time readout)
  myMessageWidget = new LabelWidget(this, font, "", TextAlign::Left, kBGColor);
  myMessageWidget->setFlags(Widget::Flag::ClearBG | Widget::Flag::NoBG);
  myMessageWidget->setTextColor(kColorInfo);
  // NOLINTEND(cppcoreguidelines-prefer-member-initializer)
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::layout()
{
  using GUI::BoxLayout;
  using GUI::stretchedItem;
  using GUI::anchoredItem;
  using GUI::alignedItem;
  using GUI::HAlign;
  using GUI::VAlign;
  using Dir = BoxLayout::Dir;

  // Row 1: current-index label, timeline (fills), last-index label
  auto row1 = std::make_unique<BoxLayout>(Dir::Horizontal);
  row1->addAuto(anchoredItem(myCurrentIdxWidget));
  row1->addSpace(BUTTON_GAP * 2);
  row1->addStretch(alignedItem(myTimeline, HAlign::Fill, VAlign::Center));
  row1->addSpace(BUTTON_GAP * 2);
  row1->addAuto(anchoredItem(myLastIdxWidget));

  // Row 2: current-time label, transport buttons, message (fills), last-time label.
  // The text readouts are centered on the (taller) icon buttons.
  auto row2 = std::make_unique<BoxLayout>(Dir::Horizontal);
  row2->addAuto(anchoredItem(myCurrentTimeWidget));
  row2->addSpace(BUTTON_GAP * 4);
  row2->addFixed(anchoredItem(myToggleWidget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP);
  row2->addFixed(anchoredItem(myExitWidget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP * 4);
  row2->addFixed(anchoredItem(myRewindAllWidget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP);
  row2->addFixed(anchoredItem(myRewind1Widget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP);
  row2->addFixed(anchoredItem(myPlayBackWidget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP);
  row2->addFixed(anchoredItem(myUnwind1Widget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP);
  row2->addFixed(anchoredItem(myUnwindAllWidget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP * 4);
  row2->addFixed(anchoredItem(mySaveAllWidget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP);
  row2->addFixed(anchoredItem(myLoadAllWidget), BUTTON_WIDTH);
  row2->addSpace(BUTTON_GAP * 4);
  row2->addStretch(stretchedItem(myMessageWidget));
  row2->addAuto(anchoredItem(myLastTimeWidget));

  // Two stacked rows, inset by the HUD borders.  The parent gave us our width;
  // our height is as tall as the two rows need to be
  auto root = std::make_unique<BoxLayout>(Dir::Vertical, 0, H_BORDER, V_BORDER);
  root->addAuto(std::move(row1));
  root->addAuto(std::move(row2));

  _h = _th + static_cast<int>(root->naturalSize().h);

  root->doLayout(0, _th, _w, _h - _th);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::setPosition()
{
  // Place on the bottom of the screen, centered horizontally
  const Common::Size& screen = instance().frameBuffer().screenSize();
  const Common::Rect& dst = surface().dstRect();
  surface().setDstPos((screen.w - dst.w()) >> 1U, screen.h - dst.h() - 10);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::loadConfig()
{
  surface().setBlendLevel(92);
  surface().enableBlend(true);

  initBar();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::handleKeyDown(StellaKey key, StellaMod mod, bool repeated)
{
  // The following shortcuts duplicate the shortcuts in EventHandler
  const Event::Type event = instance().eventHandler().eventForKey(EventMode::kEmulationMode, key, mod);

  switch(event)
  {
    case Event::ExitMode:
      handleCommand(nullptr, Cmd::Exit, 0, 0);
      break;

    case Event::Rewind1Menu:
      handleCommand(nullptr, Cmd::Rewind1, 0, 0);
      break;

    case Event::Rewind10Menu:
      handleCommand(nullptr, Cmd::Rewind10, 0, 0);
      break;

    case Event::RewindAllMenu:
      handleCommand(nullptr, Cmd::RewindAll, 0, 0);
      break;

    case Event::Unwind1Menu:
      handleCommand(nullptr, Cmd::Unwind1, 0, 0);
      break;

    case Event::Unwind10Menu:
      handleCommand(nullptr, Cmd::Unwind10, 0, 0);
      break;

    case Event::UnwindAllMenu:
      handleCommand(nullptr, Cmd::UnwindAll, 0, 0);
      break;

    case Event::LoadAllStates:
      if(!repeated)
        handleCommand(nullptr, Cmd::LoadAll, 0, 0);
      break;

    case Event::SaveAllStates:
      if(!repeated)
        handleCommand(nullptr, Cmd::SaveAll, 0, 0);
      break;

    // Hotkey only commands (no button available)
    case Event::SaveState:
    case Event::PreviousState:
    case Event::NextState:
    case Event::LoadState:
      if(!repeated)
        instance().eventHandler().handleEvent(event);
      break;

    case Event::TakeSnapshot:
      if(!repeated)
      {
        instance().eventHandler().handleEvent(Event::TakeSnapshot);
        instance().frameBuffer().setPendingRender();
      }
      break;

    default:
      Dialog::handleKeyDown(key, mod, repeated);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::handleKeyUp(StellaKey key, StellaMod mod)
{
  // The following shortcuts duplicate the shortcuts in EventHandler
  // Note: mode switches must happen in key UP

  const Event::Type event =
    instance().eventHandler().eventForKey(EventMode::kEmulationMode, key, mod);

  if(event == Event::TogglePlayBackMode || key == StellaKey::SPACE)
    handleCommand(nullptr, Cmd::PlayBack, 0, 0);
  else
    Dialog::handleKeyUp(key, mod);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::handleCommand(CommandSender* sender, GuiCmd::Code cmd,
                                      int data, int id)
{
  switch(cmd)
  {
    case Cmd::Timeline:
    {
      const Int32 winds = myTimeline->getValue() -
          instance().state().rewindManager().getCurrentIdx() + 1;
      handleWinds(winds);
      break;
    }

    case Cmd::Toggle:
      instance().toggleTimeMachine();
      handleToggle();
      break;

    case Cmd::Exit:
      instance().eventHandler().leaveMenuMode();
      break;

    case Cmd::Rewind1:
      handleWinds(-1);
      break;

    case Cmd::Rewind10:
      handleWinds(-10);
      break;

    case Cmd::RewindAll:
      handleWinds(-1000);
      break;

    case Cmd::PlayBack:
      instance().eventHandler().enterPlayBackMode();
      break;

    case Cmd::Unwind1:
      handleWinds(1);
      break;

    case Cmd::Unwind10:
      handleWinds(10);
      break;

    case Cmd::UnwindAll:
      handleWinds(1000);
      break;

    case Cmd::SaveAll:
      instance().eventHandler().handleEvent(Event::SaveAllStates);
      break;

    case Cmd::LoadAll:
      instance().eventHandler().handleEvent(Event::LoadAllStates);
      initBar();
      break;


    default:
      Dialog::handleCommand(sender, cmd, data, 0);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::initBar()
{
  const RewindManager& r = instance().state().rewindManager();
  const IntArray cycles = r.cyclesList();

  // Set range and intervals for timeline
  const uInt32 maxValue = cycles.size() > 1
    ? static_cast<uInt32>(cycles.size() - 1)
    : 0;
  myTimeline->setMaxValue(maxValue);
  myTimeline->setStepValues(cycles);

  myMessageWidget->setLabel("");
  handleWinds(_enterWinds);
  _enterWinds = 0;

  handleToggle();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
string TimeMachineDialog::getTimeString(uInt64 cycles, size_t scanlines)
{
  const bool isNTSC = scanlines <= 287;
  constexpr size_t NTSC_FREQ = 1193182; // ~76*262*60
  constexpr size_t PAL_FREQ  = 1182298; // ~76*312*50
  const size_t freq = isNTSC ? NTSC_FREQ : PAL_FREQ; // = cycles/second

  const auto minutes = static_cast<uInt32>(cycles / (freq * 60));
  cycles -= minutes * (freq * 60);
  const auto seconds = static_cast<uInt32>(cycles / freq);
  cycles -= seconds * freq;
  const auto frames  = static_cast<uInt32>(cycles / (scanlines * 76));

  return std::format("{:02}:{:02}.{:02}", minutes, seconds, frames);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::handleWinds(Int32 numWinds)
{
  RewindManager& r = instance().state().rewindManager();

  if(numWinds)
  {
    const uInt64 startCycles = r.getCurrentCycles();
    if(numWinds < 0) r.rewindStates(-numWinds);
    else             r.unwindStates(numWinds);

    const uInt64 elapsed = instance().console().system().cycles() - startCycles;
    if(elapsed > 0)
    {
      const string message = r.getUnitString(elapsed);

      myMessageWidget->setLabel(std::format("({}{})", numWinds < 0 ? '-' : '+',
                                            message));
    }
  }

  // Update time
  const size_t scanlines =
      std::max<size_t>(instance().console().tia().scanlinesLastFrame(), 240);
  myCurrentTimeWidget->setLabel(getTimeString(r.getCurrentCycles() - r.getFirstCycles(), scanlines));
  myLastTimeWidget->setLabel(getTimeString(r.getLastCycles() - r.getFirstCycles(), scanlines));
  myTimeline->setValue(r.getCurrentIdx()-1);
  // Update index
  myCurrentIdxWidget->setValue(r.getCurrentIdx());
  myLastIdxWidget->setValue(r.getLastIdx());
  // Enable/disable buttons
  myRewindAllWidget->setEnabled(!r.atFirst());
  myRewind1Widget->setEnabled(!r.atFirst());
  myPlayBackWidget->setEnabled(!r.atLast());
  myUnwindAllWidget->setEnabled(!r.atLast());
  myUnwind1Widget->setEnabled(!r.atLast());
  mySaveAllWidget->setEnabled(r.getLastIdx() != 0);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void TimeMachineDialog::handleToggle()
{
  myToggleWidget->setIcon(instance().state().mode() == StateManager::Mode::Off ?
    RECORD : STOP);
}
