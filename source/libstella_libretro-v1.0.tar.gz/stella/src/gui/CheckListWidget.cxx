//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include "Dialog.hxx"
#include "FBSurface.hxx"
#include "ScrollBarWidget.hxx"
#include "CheckListWidget.hxx"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
CheckListWidget::CheckListWidget(GuiObject* boss, const GUI::Font& font)
  : ListWidget(boss, font)
{
  // rowheight is determined by largest item on a line, so the row count that
  // follows from it is settled by setHeight(), which reflows the checkboxes too
  _lineHeight = std::max(_lineHeight, CheckboxWidget::boxSize(_font));
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::setPos(const Common::Point& pos)
{
  ListWidget::setPos(pos);
  reflowCheckboxes();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::setHeight(int h)
{
  // Recomputes _rows (and revalidates the scrollbar/selection)
  ListWidget::setHeight(h);
  reflowCheckboxes();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::refreshFont()
{
  ListWidget::refreshFont();
  // The base reset _lineHeight to the plain font line height; the row must
  // still clear the checkbox (mirrors the constructor)
  _lineHeight = std::max(_lineHeight, CheckboxWidget::boxSize(_font));
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::reflowCheckboxes()
{
  // Grow the pool so there is a checkbox for every visible row.  The boss owns
  // these widgets for its lifetime and there is no removal API, so we only ever
  // append (surplus rows are hidden below).
  while(std::cmp_less(_checkList.size(), _rows))
  {
    auto* t = new CheckboxWidget(_boss, _font, "",
                                 CheckboxWidget::Cmd::CheckAction);
    t->setTextColor(kTextColor);
    t->setTarget(this);
    t->setID(static_cast<int>(_checkList.size()));
    _checkList.push_back(t);
  }

  // Position each checkbox against the list's current origin; hide any that
  // fall past the visible row count
  int ypos = _y + 2;
  for(int i = 0; std::cmp_less(i, _checkList.size()); ++i)
  {
    if(i < _rows)
    {
      _checkList[i]->setPos(_x + 2, ypos);
      _checkList[i]->setVisible(true);
      ypos += _lineHeight;
    }
    else
      _checkList[i]->setVisible(false);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::setList(const StringList& list, const BoolArray& state)
{
  _list = list;
  _stateList = state;

  assert(_list.size() == _stateList.size());

  // Enable all checkboxes
  for(int i = 0; i < _rows; ++i)
    _checkList[i]->setFlags(Widget::Flag::Enabled);

  // Then turn off any extras
  if(std::cmp_less(_stateList.size(), _rows))
    for(int i = static_cast<int>(_stateList.size()); i < _rows; ++i)
      _checkList[i]->clearFlags(Widget::Flag::Enabled);

  ListWidget::recalc();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::setLine(int line, string_view str, bool state)
{
  if(std::cmp_greater_equal(line, _list.size()))
    return;

  _list[line]      = str;
  _stateList[line] = state;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::drawWidget(bool hilite)
{
//cerr << "CheckListWidget::drawWidget\n";
  FBSurface& s = _boss->dialog().surface();
  const int len = static_cast<int>(_list.size());

  // Draw a thin frame around the list and to separate columns
  s.frameRect(_x, _y, _w, _h, hilite ? kWidColorHi : kColor);
  s.vLine(_x + CheckboxWidget::boxSize(_font) + 5, _y, _y + _h - 1, kColor);

  // Draw the list items
  const Common::Rect r(getEditRect());
  for (int i = 0, pos = _currentPos; i < _rows && pos < len; i++, pos++)
  {
    // Draw checkboxes for correct lines (takes scrolling into account)
    _checkList[i]->setState(_stateList[pos]);
    _checkList[i]->setDirty();
    _checkList[i]->draw();

    const int y = _y + 2 + _lineHeight * i + 2;
    ColorId textColor = kTextColor;

    // Draw the selected item inverted, on a highlighted background.
    if (_selectedItem == pos)
    {
      if(_hasFocus && !_editMode)
      {
        s.fillRect(_x + r.x() - 3, _y + 1 + _lineHeight * i,
                   _w - r.x(), _lineHeight, kTextColorHi);
        textColor = kTextColorInv;
      }
      else
        s.frameRect(_x + r.x() - 3, _y + 1 + _lineHeight * i,
                    _w - r.x(), _lineHeight, kTextColorHi);
    }

    if (_selectedItem == pos && _editMode)
    {
      adjustOffset();
      s.drawString(_font, editString(), _x + r.x(), y, r.w(), kTextColor,
                   TextAlign::Left, -_editScrollOffset, false);
    }
    else
      s.drawString(_font, _list[pos], _x + r.x(), y, r.w(), textColor);
  }

  // Only draw the caret while editing, and if it's in the current viewport
  if(_editMode &&
     (!_useScrollbar ||
     ((_selectedItem >= _scrollBar->currentPos()) &&
      (_selectedItem < _scrollBar->currentPos() + _rows))))
    drawCaretSelection();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Common::Rect CheckListWidget::getEditRect() const
{
  const uInt32
    xoffset = CheckboxWidget::boxSize(_font) + 10,
    yoffset = std::max((_selectedItem - _currentPos), 0) * _lineHeight;

  return {
    2 + xoffset, 1 + yoffset,
    _w - (xoffset - 15), _lineHeight + yoffset
  };
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool CheckListWidget::getState(int line) const
{
  if(line >= 0 && std::cmp_less(line, _stateList.size()))
    return _stateList[line];
  else
    return false;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool CheckListWidget::handleEvent(Event::Type e)
{
  if(e == Event::UISelect)
  {
    // Simulate a mouse button click
    _checkList[ListWidget::getSelected()]->handleMouseUp(0, 0, MouseButton::LEFT, 0);
    return true;
  }
  else
    return ListWidget::handleEvent(e);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void CheckListWidget::handleCommand(CommandSender* sender, GuiCmd::Code cmd,
                                    int data, int id)
{
  if(cmd == CheckboxWidget::Cmd::CheckAction)
  {
    // Figure out which line has been checked
    const int line = _currentPos + id;
    _stateList[line] = static_cast<bool>(data);

    // Let the boss know about it
    sendCommand(Cmd::ListItemChecked, line, _id);
  }
  else
    ListWidget::handleCommand(sender, cmd, data, id);
}
