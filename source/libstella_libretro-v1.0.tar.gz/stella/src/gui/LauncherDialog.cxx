//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include "bspf.hxx"
#include "Bankswitch.hxx"
#include "BrowserDialog.hxx"
#include "ContextMenu.hxx"
#include "DialogContainer.hxx"
#include "Dialog.hxx"
#include "EditTextWidget.hxx"
#include "FileListWidget.hxx"
#include "LauncherFileListWidget.hxx"
#include "NavigationWidget.hxx"
#include "FSNode.hxx"
#include "OptionsDialog.hxx"
#include "GameInfoDialog.hxx"
#include "HighScoresDialog.hxx"
#include "HighScoresManager.hxx"
#include "GlobalPropsDialog.hxx"
#include "StellaSettingsDialog.hxx"
#include "WhatsNewDialog.hxx"
#include "ProgressDialog.hxx"
#include "MessageBox.hxx"
#include "ToolTip.hxx"
#include "TimerManager.hxx"
#include "OSystem.hxx"
#include "FrameBuffer.hxx"
#include "FBSurface.hxx"
#include "EventHandler.hxx"
#include "StellaKeys.hxx"
#include "Props.hxx"
#include "PropsSet.hxx"
#include "RomImageWidget.hxx"
#include "RomInfoWidget.hxx"
#include "TIAConstants.hxx"
#include "Settings.hxx"
#include "Font.hxx"
#include "FontManager.hxx"
#include "Layout.hxx"
#include "Icons.hxx"
#include "Version.hxx"
#include "MediaFactory.hxx"
#include "LauncherDialog.hxx"
#include "Random.hxx"

namespace {

// A thin draggable vertical divider.  While dragged it reports its new
// (dialog-relative) x position via the given command, so the owning dialog
// can resize the areas on either side of it.
class DividerWidget : public Widget, public CommandSender
{
  public:
    DividerWidget(GuiObject* boss, const GUI::Font& font, int w, GuiCmd::Code cmd)
      : Widget(boss, font),
        CommandSender(boss),
        myCmd{cmd}
    {
      // My width is the dialog's choice; my height is the area I divide, which
      // the dialog's layout gives me
      _w = w;

      // Flag::TrackMouse is required for handleMouseMoved() to be delivered
      // (Dialog only forwards moves to widgets that request mouse tracking)
      _flags = Widget::Flag::Enabled | Widget::Flag::TrackMouse;
    }
    ~DividerWidget() override = default;

    void handleMouseDown(int x, int y, MouseButton b, int clickCount) override
    {
      if(b == MouseButton::LEFT)
        myDragging = true;
    }
    void handleMouseUp(int x, int y, MouseButton b, int clickCount) override
    {
      myDragging = false;
    }
    void handleMouseMoved(int x, int y) override
    {
      if(myDragging)
        sendCommand(myCmd, _x + x, 0);  // dialog-relative cursor x
    }

  protected:
    void drawWidget(bool hilite) override
    {
      FBSurface& s = dialog().surface();
      const int x = _x + _w / 2;
      const ColorId color = (isHighlighted() || myDragging)
                            ? kWidColorHi : kShadowColor;

      s.vLine(x - 1, _y, _y + _h - 1, color);
      s.vLine(x + 1, _y, _y + _h - 1, color);
    }

  private:
    bool myDragging{false};
    GuiCmd::Code myCmd{GuiCmd::None};

  private:
    DividerWidget() = delete;
    DividerWidget(const DividerWidget&) = delete;
    DividerWidget(DividerWidget&&) = delete;
    DividerWidget& operator=(const DividerWidget&) = delete;
    DividerWidget& operator=(DividerWidget&&) = delete;
};

}  // namespace

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
LauncherDialog::LauncherDialog(OSystem& osystem, DialogContainer& parent,
                               int w, int h)
  : Dialog(osystem, parent, osystem.frameBuffer().launcherFont(), "",
           w, h),
    CommandSender(this)
{
  // Create the widgets (in focus order); layout() assigns all geometry
  addPathWidgets();
  addFilteringWidgets();

  // NOLINTNEXTLINE(cppcoreguidelines-prefer-member-initializer)
  mySelectedItem = addRomWidgets() - 2;  // Highlight 'Rom Listing'
  addButtonWidgets();
  myNavigationBar->setList(myList);

  tooltip().setFont(_font);

  applyFiltering();
  setHelpAnchor("ROMInfo");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
LauncherDialog::~LauncherDialog() = default;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::addFilteringWidgets()
{
  WidgetArray wid;
  // NOLINTBEGIN(cppcoreguidelines-prefer-member-initializer)
  myReloadButton = new ButtonWidget(this, _font,
                                    GUI::icon_reload_small, Cmd::Reload);
  myReloadButton->setToolTip("Reload listing (Ctrl+R)");
  wid.push_back(myReloadButton);

  myFilterLbl = new LabelWidget(this, _font, "Filter");

  myPattern = new EditTextWidget(this, _font, 1);
  myPattern->setToolTip("Enter filter text to reduce file list.\n"
    "Use '*' and '?' as wildcards.");
  wid.push_back(myPattern);

  mySubDirsButton = new ButtonWidget(this, _font,
                                     GUI::icon_reload_small, Cmd::SubDirs);
  mySubDirsButton->setToolTip("Toggle subdirectories (Ctrl+D)");
  wid.push_back(mySubDirsButton);

  myRomCount = new LabelWidget(this, _font, "", TextAlign::Right);

  myRandomRomButton = new ButtonWidget(this, _font,
                                       GUI::icon_random_small, Cmd::LoadRandomRom);
#ifndef BSPF_MACOS
  myRandomRomButton->setToolTip("Load random ROM (Alt+R)");
#else
  myRandomRomButton->setToolTip("Load random ROM (Cmd+R)");
#endif
  wid.push_back(myRandomRomButton);

  mySettingsButton = new ButtonWidget(this, _font,
    GUI::icon_settings_small, "Options" + ELLIPSIS, Cmd::Options);
  mySettingsButton->setToolTip("Open Options dialog (Ctrl+O)");
  wid.push_back(mySettingsButton);

  addToFocusList(wid);
  // NOLINTEND(cppcoreguidelines-prefer-member-initializer)
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::addPathWidgets()
{
  WidgetArray wid;
  // The navigation bar; its geometry (and that of its children) is assigned by
  // layout()
  myNavigationBar = new NavigationWidget(this, _font);

  // Help icon (variant/size re-picked in layout())
  myHelpButton = new ButtonWidget(this, _font,
                                  GUI::icon_help_small, Dialog::Cmd::Help);
  myHelpButton->setToolTip(std::format("Click for help. ({})",
    instance().eventHandler().getMappingDesc(Event::UIHelp, EventMode::kMenuMode)));
  myHelpButton->setEnabled(true);
  wid.push_back(myHelpButton);
  addToFocusList(wid);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
int LauncherDialog::addRomWidgets()
{
  const int fontWidth = Dialog::fontWidth();
  const int HBORDER   = Dialog::hBorder();
  const int VGAP      = Dialog::vGap();
  WidgetArray wid;

  // The bottom button row can be toggled on/off at runtime; we always create its
  // widgets and just show/hide them in layout(), so toggling needs no rebuild
  myShowButtons = instance().settings().getBool("launcherbuttons");

  // Estimate the list/column height the way layout() sizes the main row, so the
  // ROM info font (chosen once, here) is sized for the right area
  const int fixedRows = myShowButtons ? 3 : 2;
  const int listHeight = (_h - 2 * Dialog::vBorder())
    - fixedRows * Dialog::buttonHeight() - fixedRows * (VGAP * 2);

  // The ROM info viewer can be toggled on/off at runtime; we always create its
  // widgets and just show/hide them in layout(), so toggling needs no rebuild
  myShowRomInfo = instance().settings().getFloat("romviewer") > 0.F;

  // Determine the ROM info column width: the persisted drag width if present,
  // otherwise the configured zoom level (a default zoom when currently disabled,
  // so the widgets have a sensible size ready to be shown)
  const float savedFraction = instance().settings().getFloat("romwidth");
  int imageWidth = 0;
  if(savedFraction > 0.F)
    imageWidth = clampRomInfoWidth(
      static_cast<int>(std::round(savedFraction * (_w - HBORDER * 2))), listHeight);
  else
  {
    const float zoom = myShowRomInfo
      ? instance().settings().getFloat("romviewer") : 1.F;
    imageWidth = static_cast<int>(getRomInfoZoom(listHeight, zoom)
                                  * TIAConstants::viewableWidth);
  }
  // Remember the ROM info width as a fraction of the content width, so it scales
  // proportionally when the window is resized (see layout())
  myRomInfoFraction = imageWidth > 0
    ? static_cast<float>(imageWidth) / (_w - HBORDER * 2) : 0.F;

  // remember initial ROM directory for returning there via home button
  instance().settings().setValue("startromdir", getRomDir());
  myList = new LauncherFileListWidget(this, _font);
  myList->setEditable(false);
  myList->setListMode(FSNode::ListMode::All);
  // since we cannot know how many files there are, use a really high value here
  myList->progress().setRange(0, 50000, 5);
  myList->progress().setMessage("        Filtering files" + ELLIPSIS + "        ");
  wid.push_back(myList);

  // Create the ROM info area (if enabled); layout() shows/hides and positions it
  if(imageWidth > 0)
  {
    // Choose the ROM info font for the (estimated) available area.  The image
    // is (roughly) the column width squared, plus a label
    const int imageHeight = imageWidth + RomImageWidget::labelHeight(_font);
    const Common::Size fontArea(imageWidth - fontWidth * 2,
                                listHeight - imageHeight - VGAP * 4);
    setRomInfoFont(fontArea);

    const GUI::Font& romInfoFont = instance().fonts().romInfoFont();
    myRomImageWidget = new RomImageWidget(this, romInfoFont);
    wid.push_back(myRomImageWidget);
    myRomInfoWidget = new RomInfoWidget(this, romInfoFont);
    // Draggable divider between the list and the ROM info column
    myDivider = new DividerWidget(this, _font, fontWidth, Cmd::RomWidthChanged);
  }
  return addToFocusList(wid);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::addButtonWidgets()
{
  WidgetArray wid;
  // Four equal-width buttons at the bottom; each sizes itself from its label and
  // layout() then stretches them to share the row
#ifndef BSPF_MACOS
  myStartButton   = new ButtonWidget(this, _font, "Select", Cmd::LoadROM);
  wid.push_back(myStartButton);
  myGoUpButton    = new ButtonWidget(this, _font, "Go Up", ListWidget::Cmd::ParentDir);
  wid.push_back(myGoUpButton);
  myOptionsButton = new ButtonWidget(this, _font, "Options" + ELLIPSIS, Cmd::Options);
  wid.push_back(myOptionsButton);
  myQuitButton    = new ButtonWidget(this, _font, "Quit", Cmd::Quit);
  wid.push_back(myQuitButton);
#else
  myQuitButton    = new ButtonWidget(this, _font, "Quit", Cmd::Quit);
  wid.push_back(myQuitButton);
  myOptionsButton = new ButtonWidget(this, _font, "Options" + ELLIPSIS, Cmd::Options);
  wid.push_back(myOptionsButton);
  myGoUpButton    = new ButtonWidget(this, _font, "Go Up", ListWidget::Cmd::ParentDir);
  wid.push_back(myGoUpButton);
  myStartButton   = new ButtonWidget(this, _font, "Select", Cmd::LoadROM);
  wid.push_back(myStartButton);
#endif
  myStartButton->setToolTip("Start emulation of selected ROM\nor switch to selected directory.");
  addToFocusList(wid);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::showRomWidgets(bool show)
{
  if(!myRomImageWidget || !myRomInfoWidget)
    return;

  if(show)
  {
    myRomImageWidget->setVisible(true);
    myRomInfoWidget->setVisible(true);
    if(myDivider)
      myDivider->setVisible(true);
  }
  else
  {
    myRomImageWidget->setVisible(false);
    myRomInfoWidget->setVisible(false);
    if(myDivider)
      myDivider->setVisible(false);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::showButtonWidgets(bool show)
{
  if(!myStartButton || !myGoUpButton || !myOptionsButton || !myQuitButton)
    return;

  // Disabling (not just hiding) keeps a hidden button out of Tab/joystick
  // focus cycling, which only skips disabled widgets (see setFocusForList)
  myStartButton->setVisible(show);
  myStartButton->setEnabled(show);
  myOptionsButton->setVisible(show);
  myOptionsButton->setEnabled(show);
  myQuitButton->setVisible(show);
  myQuitButton->setEnabled(show);
  // Go Up additionally depends on whether there is a parent directory;
  // updateUI() re-derives that half of its enabled state
  myGoUpButton->setVisible(show);
  myGoUpButton->setEnabled(show && myList->currentDir().hasParent());
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::updateRomCount()
{
  myRomCount->setLabel(std::format("{} items found",
    myList->getList().size() - (currentDir().hasParent() ? 1 : 0)));
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
int LauncherDialog::clampRomInfoWidth(int imageWidth, int colHeight) const
{
  const int fontWidth  = Dialog::fontWidth();
  const int fontHeight = Dialog::fontHeight();
  const int HBORDER    = Dialog::hBorder();
  const int contentW   = _w - HBORDER * 2;

  // Horizontal limit: keep at least MIN_LAUNCHER_CHARS for the list
  const int hMax = contentW - fontWidth - MIN_LAUNCHER_CHARS * fontWidth;
  // Vertical limit: the (roughly square) image, its label and a couple of
  // info text lines must all fit in the column height.  The launcher font is
  // used as a conservative estimate (the ROM info font is never larger).
  const int vMax = colHeight - fontHeight * 4;

  const int minW = MIN_ROMINFO_CHARS * fontWidth;
  const int maxW = std::max(std::min(hMax, vMax), minW);

  return BSPF::clamp(imageWidth, minW, maxW);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::layout()
{
  // Derive the available (logical) size from the current window, clamped to the
  // minimum computed at the end of the previous layout (the widgets have no
  // usable geometry until this method runs, so the minimum can't be read up
  // front).  Most WMs honour SDL's minimum-size hint; this clamp is a fallback.
  const uInt32 scale = instance().frameBuffer().hidpiScaleFactor();
  const Common::Rect& image = instance().frameBuffer().imageRect();
  const int w = std::max(static_cast<int>(image.w() / scale),
                         static_cast<int>(myMinSize.w));
  const int h = std::max(static_cast<int>(image.h() / scale),
                         static_cast<int>(myMinSize.h));

  // Persist the launcher window size, so it is restored next time (on restart
  // and when returning from a game).  While an interactive resize is in
  // progress this is deferred: the settle pass re-runs layout() and persists
  // the final size exactly once per drag.  (Settings::setValue ignores an
  // unchanged value, so calling it unconditionally here is cheap.)
  const bool resizing = parent().resizeInProgress();
  if(!resizing)
    instance().settings().setValue("launcherres",
        Common::Size(static_cast<uInt32>(w), static_cast<uInt32>(h)));
  _w = w;
  _h = h;

  using GUI::BoxLayout;
  using GUI::widgetItem;
  using GUI::alignedItem;
  using GUI::anchoredItem;
  using GUI::HAlign;
  using GUI::VAlign;
  using Dir = BoxLayout::Dir;

  const int HBORDER      = Dialog::hBorder();
  const int vBorder      = Dialog::vBorder();
  const int fontWidth    = Dialog::fontWidth();
  const int fontHeight   = Dialog::fontHeight();
  const int lineHeight   = Dialog::lineHeight();
  const int buttonHeight = Dialog::buttonHeight();
  const int rowGap       = Dialog::vGap() * 2;
  const int LBL_GAP      = fontWidth;
  const int BTN_GAP      = fontWidth / 4;

  // The icons come in two sizes; re-pick them here, since a live font change may
  // have crossed the threshold.  Each button re-sizes itself around the icon it
  // is given, so nothing here says how wide one is
  const bool largeIcons = _font.isLarge();
  const GUI::Icon& reloadIcon   = largeIcons ? GUI::icon_reload_large   : GUI::icon_reload_small;
  const GUI::Icon& randomIcon   = largeIcons ? GUI::icon_random_large   : GUI::icon_random_small;
  const GUI::Icon& settingsIcon = largeIcons ? GUI::icon_settings_large : GUI::icon_settings_small;
  const GUI::Icon& helpIcon     = largeIcons ? GUI::icon_help_large     : GUI::icon_help_small;

  myReloadButton->setIcon(reloadIcon);
  myRandomRomButton->setIcon(randomIcon);
  mySettingsButton->setIcon(settingsIcon);
  if(myHelpButton)
    myHelpButton->setIcon(helpIcon);
  // The subdirs button shows the current on/off state in the matching variant
  const bool subdirs = instance().settings().getBool("launchersubdirs");
  mySubDirsButton->setIcon(subdirs
    ? (largeIcons ? GUI::icon_subdirs_large_on  : GUI::icon_subdirs_small_on)
    : (largeIcons ? GUI::icon_subdirs_large_off : GUI::icon_subdirs_small_off));

  // Filtering row: the filter field absorbs the slack; everything else packs
  // around it.  This row is the widest thing in the dialog, so it is what the
  // window minimum ends up being -- which is why everything in it always fits
  const auto makeFilterRow = [&] {
    auto row = std::make_unique<BoxLayout>(Dir::Horizontal, 0, HBORDER, 0);
    row->addAuto(anchoredItem(myReloadButton));
    row->addSpace(LBL_GAP * 2);
    row->addAuto(anchoredItem(myFilterLbl));
    row->addSpace(LBL_GAP);
    row->addStretch(widgetItem(myPattern, EditTextWidget::calcWidth(_font, "123456")));
    row->addSpace(BTN_GAP);
    row->addAuto(anchoredItem(mySubDirsButton));
    row->addSpace(BTN_GAP + LBL_GAP);
    row->addFixed(alignedItem(myRomCount, HAlign::Fill, VAlign::Center),
                  _font.getStringWidth("12345 items found"));
    row->addSpace(LBL_GAP * 2);
    row->addAuto(anchoredItem(myRandomRomButton));
    row->addSpace(BTN_GAP);
    row->addAuto(anchoredItem(mySettingsButton));
    return row;
  };

  // Path / navigation row: the bar fills the width, the help button anchors
  // to the right
  const auto makePathRow = [&] {
    auto row = std::make_unique<BoxLayout>(Dir::Horizontal, BTN_GAP, HBORDER, 0);
    row->addStretch(widgetItem(myNavigationBar, MIN_LAUNCHER_CHARS * fontWidth));
    if(myHelpButton)
      row->addAuto(anchoredItem(myHelpButton));
    return row;
  };

  // Bottom button row (optional): four equal-width buttons
  const bool hasButtonRow = myShowButtons && myStartButton && myGoUpButton
                         && myOptionsButton && myQuitButton;
  const auto makeButtonRow = [&] {
    auto row = std::make_unique<BoxLayout>(Dir::Horizontal, Dialog::buttonGap(),
                                           HBORDER, 0);
#ifndef BSPF_MACOS
    row->addStretch(widgetItem(myStartButton));
    row->addStretch(widgetItem(myGoUpButton));
    row->addStretch(widgetItem(myOptionsButton));
    row->addStretch(widgetItem(myQuitButton));
#else
    row->addStretch(widgetItem(myQuitButton));
    row->addStretch(widgetItem(myOptionsButton));
    row->addStretch(widgetItem(myGoUpButton));
    row->addStretch(widgetItem(myStartButton));
#endif
    return row;
  };

  // Main row: the ROM list, plus an optional ROM info column (divider + image
  // over info text).  The column width is a fraction of the content width so it
  // scales with the window, clamped to keep both list and image usable
  const bool showRom = myShowRomInfo && myRomImageWidget && myRomInfoWidget;
  const int minRomW = MIN_ROMINFO_CHARS * fontWidth;

  const auto makeMainRow = [&](int imageWidth) {
    auto row = std::make_unique<BoxLayout>(Dir::Horizontal, 0, HBORDER, 0);
    row->addStretch(widgetItem(myList, MIN_LAUNCHER_CHARS * fontWidth,
                               lineHeight * 3));
    if(imageWidth > 0)
    {
      row->addFixed(widgetItem(myDivider), fontWidth);

      // The image cell and the column are fixed at the current (fraction- and
      // clamp-derived) width, but both compress as the window shrinks: declare
      // their floors so minSize() reports a size-independent minimum
      const GUI::Font& romInfoFont = instance().fonts().romInfoFont();
      const int labelHeight = RomImageWidget::labelHeight(romInfoFont);
      auto romCol = std::make_unique<BoxLayout>(Dir::Vertical);
      romCol->addFixed(widgetItem(myRomImageWidget, minRomW),
                       imageWidth + labelHeight, minRomW + labelHeight);
      romCol->addSpace(romInfoFont.getFontHeight() / 2);
      romCol->addStretch(widgetItem(myRomInfoWidget, minRomW, fontHeight * 2));
      row->addFixed(std::move(romCol), imageWidth, minRomW);
    }
    return row;
  };

  // Assemble the vertical stack; the main row takes whatever the others leave
  const auto makeRoot = [&](int imageWidth) {
    auto stack = std::make_unique<BoxLayout>(Dir::Vertical, 0, 0, vBorder);
    stack->addFixed(makePathRow(), buttonHeight);
    stack->addSpace(rowGap);
    stack->addFixed(makeFilterRow(), buttonHeight);
    stack->addSpace(rowGap);
    stack->addStretch(makeMainRow(imageWidth));
    if(hasButtonRow)
    {
      stack->addSpace(rowGap);
      stack->addFixed(makeButtonRow(), buttonHeight);
    }
    return stack;
  };

  // The ROM image is square, so how WIDE the column may be depends on how TALL
  // the main row is -- and only the layout knows that.  So lay the stack out
  // once with the list alone, ask the list what height it was given, and lay it
  // out again for real.  (The ROM widgets are not in that first pass, so nothing
  // rescales an image for it.)
  int imageWidth = 0;
  if(showRom)
  {
    makeRoot(0)->doLayout(0, 0, _w, _h);
    imageWidth = clampRomInfoWidth(
        static_cast<int>(std::round(myRomInfoFraction * (_w - HBORDER * 2))),
        myList->getHeight());
  }

  showRomWidgets(imageWidth > 0);
  showButtonWidgets(hasButtonRow);

  auto root = makeRoot(imageWidth);
  root->doLayout(0, 0, _w, _h);

  // The layout tree also yields the minimum content size (from the items'
  // declared minimums, so it is independent of the current size), used to
  // clamp the next layout and as the window manager's minimum-size hint.
  // The hint is NOT re-applied while an interactive resize is in progress —
  // re-asserting a minimum mid-drag fights the resize itself (the window can
  // only shrink up to the last hint per motion, felt as heavy lag).  The
  // settle pass applies the final value once the drag ends.
  myMinSize = root->minSize();
  if(!resizing)
    instance().frameBuffer().setWindowMinSize(myMinSize);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const string& LauncherDialog::selectedRom() const
{
  return currentNode().getPath();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const string& LauncherDialog::selectedRomMD5()
{
  if(currentNode().isDirectory() || !Bankswitch::isValidRomName(currentNode()))
    return EmptyString();

  // Attempt to conserve memory
  if(myMD5List.size() > 500)
    myMD5List.clear();

  // Lookup MD5, and if not present, cache it
  const auto [it, _] = myMD5List.try_emplace(
    currentNode().getPath(), "");
  if(it->second.empty())
    it->second = OSystem::getROMMD5(currentNode());
  return it->second;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const FSNode& LauncherDialog::currentNode() const
{
  return myList->selected();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
const FSNode& LauncherDialog::currentDir() const
{
  return myList->currentDir();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::reload()
{
  const bool extensions = instance().settings().getBool("launcherextensions");

  myMD5List.clear();
  myList->setShowFileExtensions(extensions);
  myList->reload();
  myPendingReload = false;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleQuit()
{
  // saveConfig() will be done in quit()
  close();
  instance().eventHandler().quit();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::quit()
{
  saveConfig();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::tick()
{
  if(myPendingReload && myReloadTime < TimerManager::getTicks() / 1000)
    reload();

  if(myPendingRomInfo && myRomInfoTime < TimerManager::getTicks() / 1000)
    loadPendingRomInfo();

  Dialog::tick();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::loadConfig()
{
  // Should we use a temporary directory specified on the commandline, or the
  // default one specified by the settings?
  Settings& settings = instance().settings();
  const string& romdir = getRomDir();
  const string& version = settings.getString("stella.version");

  // Show "What's New" message when a new version of Stella is run for the first time
  if(version < STELLA_VERSION)
  {
    openWhatsNew();
    settings.setValue("stella.version", STELLA_VERSION);
  }

  toggleSubDirs(false);
  myList->setShowFileExtensions(settings.getBool("launcherextensions"));
  // Favorites
  myList->loadFavorites();

  // Assume that if the list is empty, this is the first time that loadConfig()
  // has been called (and we should reload the list)
  if(myList->getList().empty())
  {
    FSNode node(romdir.empty() ? "~" : romdir);
    if(!myList->isDirectory(node))
      node = FSNode("~");

    myList->setInitialDirectory(node, settings.getString("lastrom"));
    updateUI();
  }
  Dialog::setFocus(getFocusList()[mySelectedItem]);

  if(myRomImageWidget && myRomInfoWidget)
  {
    myRomImageWidget->reloadProperties(currentNode());
    myRomInfoWidget->reloadProperties(currentNode());
  }

  myList->clearFlags(Widget::Flag::WantsRawData); // always reset this
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::saveConfig()
{
  Settings& settings = instance().settings();

  if(settings.getBool("followlauncher"))
    settings.setValue("romdir", myList->currentDir().getShortPath());

  // Favorites
  myList->saveFavorites();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::updateUI()
{
  // Only enable the 'up' button if there's a parent directory (and the
  // button row is even shown -- showButtonWidgets() sets the other half)
  if(myGoUpButton)
    myGoUpButton->setEnabled(myShowButtons && myList->currentDir().hasParent());
  // Only enable the navigation buttons if function is available
  myNavigationBar->updateUI();

  // Indicate how many files were found
  updateRomCount();

  loadRomInfo();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
string LauncherDialog::getRomDir()
{
  const Settings& settings = instance().settings();
  const string& tmpromdir = settings.getString("tmpromdir");

  return !tmpromdir.empty() ? tmpromdir : settings.getString("romdir");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool LauncherDialog::matchWithWildcardsIgnoreCase(
    string_view str, string_view pattern)
{
  string in{str};
  string pat{pattern};

  BSPF::toUpperCase(in);
  BSPF::toUpperCase(pat);

  return BSPF::matchWithWildcards(in, pat);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::applyFiltering()
{
  myList->setNameFilter(
    [&](const FSNode& node) {
      myList->incProgress();
      if(!node.isDirectory())
      {
        // Only show valid ROMs
        string ext;
        if(!Bankswitch::isValidRomName(node, ext) ||
           BSPF::compareIgnoreCase(ext, "zip") == 0) // exclude ZIPs without any valid ROMs
          return false;

        // Skip over files that don't match the pattern in the 'pattern' textbox
        if(myPattern && !myPattern->getText().empty() &&
           !matchWithWildcardsIgnoreCase(node.getName(), myPattern->getText()))
          return false;
      }
      return true;
    }
  );
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
float LauncherDialog::getRomInfoZoom(int listHeight, float zoom) const
{
  // The ROM info area is some multiple of the minimum TIA image size
  if(zoom > 0.F)
  {
    const GUI::Font& smallFont = instance().frameBuffer().smallFont();
    const int fontWidth = Dialog::fontWidth(),
              HBORDER   = Dialog::hBorder();

    // upper zoom limit - at least 24 launchers chars/line and 7 + 4 ROM info lines
    if((_w - (HBORDER * 2 + fontWidth + 30) - zoom * TIAConstants::viewableWidth)
       / fontWidth < MIN_LAUNCHER_CHARS)
    {
      zoom = static_cast<float>(_w - (HBORDER * 2 + fontWidth + 30) - MIN_LAUNCHER_CHARS * fontWidth)
        / TIAConstants::viewableWidth;
    }
    if((listHeight - 12 - zoom * TIAConstants::viewableHeight) <
       MIN_ROMINFO_ROWS * smallFont.getLineHeight() +
       MIN_ROMINFO_LINES * smallFont.getFontHeight())
    {
      zoom = static_cast<float>(listHeight - 12 -
                   MIN_ROMINFO_ROWS * smallFont.getLineHeight() -
                   MIN_ROMINFO_LINES * smallFont.getFontHeight())
        / TIAConstants::viewableHeight;
    }

    // lower zoom limit - at least 30 ROM info chars/line
    if((zoom * TIAConstants::viewableWidth)
       / smallFont.getMaxCharWidth() < MIN_ROMINFO_CHARS + 6)
    {
      zoom = static_cast<float>(MIN_ROMINFO_CHARS * smallFont.getMaxCharWidth() + 6)
        / TIAConstants::viewableWidth;
    }
  }
  return zoom;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::setRomInfoFont(const Common::Size& area)
{
  // The role may name a font of its own, in which case FontManager has
  // already set it and there is nothing to fit
  if(instance().settings().getString(
        FontManager::settingKey(FontManager::FontRole::RomInfo))
     != FontManager::AUTO_FONT)
    return;

  // Try to pick a font that works best, based on the available area.  The
  // candidates come from the font registry, but which of them fits is a
  // question about this dialog's layout, so it is decided here
  for(const FontDesc* font: FontManager::romInfoFonts())
  {
    // only use fonts <= launcher fonts
    if(std::cmp_greater_equal(Dialog::fontHeight(), font->height)
       && std::cmp_greater_equal(area.h,
            MIN_ROMINFO_ROWS * font->height + 2 + MIN_ROMINFO_LINES * font->height)
       && std::cmp_greater_equal(area.w, MIN_ROMINFO_CHARS * font->maxwidth))
    {
      instance().fonts().changeRomInfoFont(*font);
      return;
    }
  }
  instance().fonts().changeRomInfoFont(FontManager::smallestDesc());
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::setRomInfoEnabled(bool enable)
{
  if(enable == myShowRomInfo)
    return;

  myShowRomInfo = enable;

  // Re-flow so the list and ROM info column take their new widths, and the
  // viewer widgets are shown/hidden
  layout();

  if(enable)
    loadRomInfo();                  // load image/info for the current selection
  else if(myRomImageWidget)
    myRomImageWidget->clearProperties();  // stop rendering the image surface
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::setButtonsEnabled(bool enable)
{
  if(enable == myShowButtons)
    return;

  myShowButtons = enable;

  // Re-flow so the main row takes back/gives up the space, and the button
  // row itself is shown/hidden
  layout();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::loadRomInfo()
{
  if(!myShowRomInfo || !myRomImageWidget || !myRomInfoWidget)
    return;

  // Update ROM info UI item, delayed
  myRomInfoTime = TimerManager::getTicks() / 1000 + myRomImageWidget->pendingLoadTime();
  myPendingRomInfo = true;

  const string& md5 = selectedRomMD5();
  Properties properties;
  if(!md5.empty())
  {
    // Make sure to load a per-ROM properties entry, if one exists
    instance().propSet().loadPerROM(currentNode(), md5);

    // And now get the properties for this ROM
    instance().propSet().getMD5(md5, properties);
  }
  else
  {
    const Bankswitch::Type type = Bankswitch::typeFromExtension(currentNode());
    if(type == Bankswitch::Type::AUTO)
    {
      myRomImageWidget->clearProperties();
      myRomInfoWidget->clearProperties();
      return;
    }
    properties.set(PropType::Cart_Name, currentNode().getBaseName());
    properties.set(PropType::Cart_Type, Bankswitch::typeToName(type));
  }
  myRomImageWidget->setProperties(currentNode(), properties, false);
  myRomInfoWidget->setProperties(currentNode(), properties, false);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::loadPendingRomInfo()
{
  myPendingRomInfo = false;

  if(!myRomImageWidget || !myRomInfoWidget)
    return;

  const string& md5 = selectedRomMD5();
  Properties properties;
  if(!md5.empty())
  {
    // Make sure to load a per-ROM properties entry, if one exists
    instance().propSet().loadPerROM(currentNode(), md5);

    // And now get the properties for this ROM
    instance().propSet().getMD5(md5, properties);
  }
  else
  {
    const Bankswitch::Type type = Bankswitch::typeFromExtension(currentNode());
    if(type == Bankswitch::Type::AUTO)
      return;
    properties.set(PropType::Cart_Name, currentNode().getBaseName());
    properties.set(PropType::Cart_Type, Bankswitch::typeToName(type));
  }
  myRomImageWidget->setProperties(currentNode(), properties);
  myRomInfoWidget->setProperties(currentNode(), properties);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleFavoritesChanged()
{
  if(instance().settings().getBool("favorites"))
  {
    myList->loadFavorites();
  }
  else
  {
    if(myList->inVirtualDir())
      myList->selectParent();
    myList->saveFavorites(true);
    myList->clearFavorites();
  }
  reload();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleContextMenu()
{
  const string& cmd = contextMenu().getSelectedTag().toString();

  if(cmd == "favorite")
    myList->toggleUserFavorite();
  else if(cmd == "remove")
  {
    myList->removeFavorite();
    reload();
  }
  else if(cmd == "removefavorites")
    removeAllFavorites();
  else if(cmd == "removepopular")
    removeAllPopular();
  else if(cmd == "removerecent")
    removeAllRecent();
  else if(cmd == "properties")
    openGameProperties();
  else if(cmd == "override")
    openGlobalProps();
  else if(cmd == "extensions")
    toggleExtensions();
  else if(cmd == "sorting")
    toggleSorting();
  else if(cmd == "subdirs")
    sendCommand(Cmd::SubDirs, 0, 0);
  else if(cmd == "homedir")
    sendCommand(FileListWidget::Cmd::HomeDir, 0, 0);
  else if(cmd == "highscores")
    openHighScores();
  else if(cmd == "reload")
    reload();
  else if(cmd == "options")
    openSettings();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
ContextMenu& LauncherDialog::contextMenu()
{
  if(myContextMenu == nullptr)
    // Create (empty) context menu for ROM list options
    myContextMenu = std::make_unique<ContextMenu>(this, _font);

  return *myContextMenu;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleKeyDown(StellaKey key, StellaMod mod, bool repeated)
{
  // Grab the key before passing it to the actual dialog and check for
  // context menu keys
  bool handled = false;

  if(!(myPattern && myPattern->isHighlighted()
      && instance().eventHandler().checkEventForKey(EventMode::kEditMode, key, mod)))
  {
    if(StellaModTest::isControl(mod))
    {
      handled = true;
      switch(key)
      {
        case StellaKey::D:
          sendCommand(Cmd::SubDirs, 0, 0);
          break;

        case StellaKey::E:
          toggleExtensions();
          break;

        case StellaKey::F:
          myList->toggleUserFavorite();
          break;

        case StellaKey::G:
          openGameProperties();
          break;

        case StellaKey::H:
          if(instance().highScores().enabled())
            openHighScores();
          break;

        case StellaKey::O:
          openSettings();
          break;

        case StellaKey::P:
          openGlobalProps();
          break;

        case StellaKey::R:
          reload();
          break;

        case StellaKey::S:
          toggleSorting();
          break;

        case StellaKey::X:
          myList->removeFavorite();
          reload();
          break;

        default:
          handled = false;
          break;
      }
    }
    else if(StellaModTest::isAlt(mod) && key == StellaKey::R)
    {
      loadRandomRom();
      handled = true;
    }
  }
  // Required because BrowserDialog does not want raw input
  if(!handled && (repeated || !myList->handleKeyDown(key, mod)))
    Dialog::handleKeyDown(key, mod, repeated);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleJoyDown(int stick, int button, bool longPress)
{
  myEventHandled = false;
  myList->setFlags(Widget::Flag::WantsRawData);   // allow handling long button press
  Dialog::handleJoyDown(stick, button, longPress);
  myList->clearFlags(Widget::Flag::WantsRawData); // revert flag afterwards!
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleJoyUp(int stick, int button)
{
  // open power-up options and settings for 2nd and 4th button if not mapped otherwise
  const Event::Type e = instance().eventHandler().eventForJoyButton(EventMode::kMenuMode, stick, button);

  if(myList->isHighlighted() && button == 1 && (e == Event::UIOK || e == Event::NoType))
    openGlobalProps();
  if(myList->isHighlighted() && button == 3 && (e == Event::UITabPrev || e == Event::NoType))
    openSettings();
  else if(!myEventHandled)
    Dialog::handleJoyUp(stick, button);

  myList->clearFlags(Widget::Flag::WantsRawData); // stop allowing to handle long button press
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
Event::Type LauncherDialog::getJoyAxisEvent(int stick, JoyAxis axis, JoyDir adir, int button)
{
  Event::Type event = instance().eventHandler().eventForJoyAxis(EventMode::kMenuMode, stick, axis, adir, button);

  // map axis events for launcher
  switch(event)
  {
    case Event::UITabPrev:
      event = Event::UIPgUp;
      break;

    case Event::UITabNext:
      event = Event::UIPgDown;
      break;

    default:
      break;
  }
  return event;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleMouseUp(int x, int y, MouseButton b, int clickCount)
{
  // Grab right mouse button for context menu, send left to base class
  if(b == MouseButton::RIGHT
    && x + getAbsX() >= myList->getLeft() && x + getAbsX() <= myList->getRight()
    && y + getAbsY() >= myList->getTop() && y + getAbsY() <= myList->getBottom())
  {
    openContextMenu(x, y);
  }
  else
    Dialog::handleMouseUp(x, y, b, clickCount);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::handleCommand(CommandSender* sender, GuiCmd::Code cmd,
                                   int data, int id)
{
  switch(cmd)
  {
    case Cmd::RomWidthChanged:
    {
      // The divider was dragged: 'data' is the dialog-relative cursor x.
      // The ROM info column spans from there to the right border.
      const int HBORDER   = Dialog::hBorder();
      const int contentW  = _w - HBORDER * 2;
      const int imageWidth = clampRomInfoWidth((_w - HBORDER) - data,
                                               myList->getHeight());

      myRomInfoFraction = static_cast<float>(imageWidth) / contentW;
      instance().settings().setValue("romwidth", myRomInfoFraction);

      layout();
      break;
    }

    case Cmd::SubDirs:
      toggleSubDirs();
      break;

    case Cmd::LoadROM:
      if(myList->isDirectory(myList->selected()))
      {
        if(myList->selected().getName() == "..")
          myList->selectParent();
        else
          myList->selectDirectory();
        break;
      }
      [[fallthrough]];
    case FileListWidget::Cmd::ItemActivated:
      loadRom();
      break;

    case Cmd::LoadRandomRom:
      loadRandomRom();
      break;

    case ListWidget::Cmd::ParentDir:
      myList->selectParent();
      break;

    case Cmd::Options:
      openSettings();
      break;

    case Cmd::Reload:
      reload();
      break;

    case FileListWidget::Cmd::ItemChanged:
      updateUI();
      break;

    case ListWidget::Cmd::LongButtonPress:
      if(!currentNode().isDirectory() && Bankswitch::isValidRomName(currentNode()))
        openContextMenu();
      myEventHandled = true;
      break;

    case EditableWidget::Cmd::Changed:
    case EditableWidget::Cmd::Accept:
    {
      const bool subDirs = instance().settings().getBool("launchersubdirs");

      myList->setIncludeSubDirs(subDirs);
      if(subDirs && cmd == EditableWidget::Cmd::Changed)
      {
        // delay (potentially slow) subdirectories reloads until user stops typing
        myReloadTime = TimerManager::getTicks() / 1000 +
          LauncherFileListWidget::getQuickSelectDelay();
        myPendingReload = true;
      }
      else
        reload();
      break;
    }

    case Cmd::Quit:
      handleQuit();
      break;

    case Cmd::RomDirChosen:
    {
      string_view romDir = instance().settings().getString("romdir");

      if(myList->currentDir().getPath() != romDir)
      {
        FSNode node(romDir);

        if(!myList->isDirectory(node))
          node = FSNode("~");

        myList->setInitialDirectory(node);
      }
      if(romDir != instance().settings().getString("startromdir"))
      {
        instance().settings().setValue("startromdir", romDir);
        reload();
      }
      break;
    }

    case Cmd::FavouritesChanged:
      handleFavoritesChanged();
      break;

    case Cmd::ExtensionsChanged:
      reload();
      break;

    case Cmd::RomViewerChanged:
      setRomInfoEnabled(instance().settings().getFloat("romviewer") > 0.F);
      break;

    case Cmd::ButtonsChanged:
      setButtonsEnabled(instance().settings().getBool("launcherbuttons"));
      break;

    case Cmd::FontChanged:
      // The launcher font was changed at runtime.  Swap it in place (every
      // widget references the same Font object), then refresh the cached
      // font-derived state and re-flow — no restart required.
      instance().refreshFonts();
      // A larger font can raise the content minimum past the window's
      // current size; layout() (run by refreshFont() above) has already
      // recomputed myMinSize for the new font, so grow the window to fit
      instance().frameBuffer().growWindowTo(myMinSize);
      break;

    case ContextMenu::Cmd::ItemSelected:
      handleContextMenu();
      break;

    case RomInfoWidget::Cmd::Clicked:
    {
      const string& url = myRomInfoWidget->getUrl();

      if(!url.empty())
        MediaFactory::openURL(url);
      break;
    }

    default:
      Dialog::handleCommand(sender, cmd, data, 0);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::loadRom()
{
  // Assumes that the ROM will be loaded successfully, has to be done
  //  before saving the config.
  myList->updateFavorites();
  saveConfig();

  const string& result = instance().createConsole(currentNode(), selectedRomMD5());
  if(result.empty())
  {
    instance().settings().setValue("lastrom", myList->getSelectedString());

    // If romdir has never been set, set it now based on the selected rom
    if(instance().settings().getString("romdir").empty())
      instance().settings().setValue("romdir", currentNode().getParent().getShortPath());
  }
  else
    instance().frameBuffer().showTextMessage(result, MessagePosition::MiddleCenter, true);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::openContextMenu(int x, int y)
{
  // Dynamically create context menu for ROM list options

  bool addCancel = false;
  if(x < 0 || y < 0)
  {
    // Long pressed button, determine position from currently selected list item
    x = myList->getLeft() + myList->getWidth() / 2;
    y = myList->getTop() + (myList->getSelected() - myList->currentPos() + 1) * _font.getLineHeight();
    addCancel = true;
  }

  struct ContextItem {
    string label;
    string shortcut;
    string key;
    explicit ContextItem(string_view _label, string_view _shortcut,
                         string_view _key)
      : label{_label}, shortcut{_shortcut}, key{_key} {}
    // For items that have no keyboard shortcut
    ContextItem(string_view _label, string_view _key)
      : label{_label}, key{_key} {}
  };
  using ContextList = std::vector<ContextItem>;
  ContextList items;
  const bool useFavorites = instance().settings().getBool("favorites");

  if(useFavorites)
  {
    if(!currentNode().isDirectory())
    {
      if(LauncherFileListWidget::isUserDir(currentNode().getName()))
        items.emplace_back("Remove all from favorites", "removefavorites");
      if(LauncherFileListWidget::isPopularDir(currentNode().getName()))
        items.emplace_back("Remove all from most popular", "removepopular");
      if(LauncherFileListWidget::isRecentDir(currentNode().getName()))
        items.emplace_back("Remove all from recently played", "removerecent");
      if(myList->inRecentDir())
        items.emplace_back("Remove from recently played", "Ctrl+X", "remove");
      if(myList->inPopularDir())
        items.emplace_back("Remove from most popular", "Ctrl+X", "remove");
    }
    if((currentNode().isDirectory() && currentNode().getName() != "..")
      || Bankswitch::isValidRomName(currentNode()))
      items.emplace_back(myList->isUserFavorite(myList->selected().getPath())
        ? "Remove from favorites"
        : "Add to favorites", "Ctrl+F", "favorite");
  }
  if(!currentNode().isDirectory() && Bankswitch::isValidRomName(currentNode()))
  {
    items.emplace_back("Game properties" + ELLIPSIS, "Ctrl+G", "properties");
    items.emplace_back("Power-on options" + ELLIPSIS, "Ctrl+P", "override");
    if(instance().highScores().enabled())
      items.emplace_back("High scores" + ELLIPSIS, "Ctrl+H", "highscores");
  }
  items.emplace_back(instance().settings().getBool("launcherextensions")
    ? "Disable file extensions"
    : "Enable file extensions", "Ctrl+E", "extensions");
  if(useFavorites && myList->inVirtualDir())
    items.emplace_back(instance().settings().getBool("altsorting")
      ? "Normal sorting"
      : "Alternative sorting", "Ctrl+S", "sorting");
  if(addCancel)
    items.emplace_back("Cancel", ""); // closes the context menu and does nothing

  // Format items for menu, aligning all shortcuts to the right
  VariantList varItems;
  auto maxLen = 0UZ;
  for(const auto& item: items)
    maxLen = std::max(maxLen, item.label.length());

  for(auto& item: items)
    VarList::push_back(varItems, " " + item.label.append(maxLen - item.label.length(), ' ')
      + "  " + item.shortcut + " ", item.key);
  contextMenu().addItems(varItems);

  // Add menu at current x,y mouse location
  contextMenu().show(x + getAbsX(), y + getAbsY(), surface().dstRect(), 0);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::loadRandomRom()
{
  const Random rand;
  int tries = 100; // limit to 100 tries, in case the directory contains no ROMs

  do {
    myList->setSelected(rand.next() % myList->getList().size());
  } while(myList->isDirectory(myList->selected()) && --tries);
  if(tries)
    loadRom();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::openSettings()
{
  saveConfig();

  // Create an options dialog, similar to the in-game one
  if(instance().settings().getBool("basic_settings"))
    myDialog = std::make_unique<StellaSettingsDialog>(instance(), parent(),
                                                      AppMode::launcher);
  else
    myDialog = std::make_unique<OptionsDialog>(instance(), parent(), this,
                                               AppMode::launcher);
  myDialog->open();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::openGameProperties()
{
  if(!currentNode().isDirectory() && Bankswitch::isValidRomName(currentNode()))
  {
    // Create game properties dialog
    myDialog = std::make_unique<GameInfoDialog>(instance(), parent(),
      instance().frameBuffer().font(), this);
    myDialog->open();
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::openGlobalProps()
{
  if(!currentNode().isDirectory() && Bankswitch::isValidRomName(currentNode()))
  {
    // Create global props dialog, which is used to temporarily override
    // ROM properties
    myDialog = std::make_unique<GlobalPropsDialog>(this,
                                              instance().frameBuffer().font());
    myDialog->open();
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::openHighScores()
{
  // Create an high scores dialog, similar to the in-game one
  myDialog = std::make_unique<HighScoresDialog>(instance(), parent(), AppMode::launcher);
  myDialog->open();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::openWhatsNew()
{
  myDialog = std::make_unique<WhatsNewDialog>(instance(), parent());
  myDialog->open();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::toggleSubDirs(bool toggle)
{
  bool subdirs = instance().settings().getBool("launchersubdirs");

  if(toggle)
  {
    subdirs = !subdirs;
    instance().settings().setValue("launchersubdirs", subdirs);
  }

  const bool largeIcons = _font.isLarge();
  mySubDirsButton->setIcon(subdirs
    ? (largeIcons ? GUI::icon_subdirs_large_on  : GUI::icon_subdirs_small_on)
    : (largeIcons ? GUI::icon_subdirs_large_off : GUI::icon_subdirs_small_off));

  myList->setIncludeSubDirs(subdirs);
  if(toggle)
    reload();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::toggleExtensions()
{
  const bool extensions = !instance().settings().getBool("launcherextensions");

  instance().settings().setValue("launcherextensions", extensions);
  myList->setShowFileExtensions(extensions);
  reload();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::toggleSorting()
{
  if(myList->inVirtualDir())
  {
    // Toggle between normal and alternative sorting of virtual directories
    const bool altSorting = !instance().settings().getBool("altsorting");

    instance().settings().setValue("altsorting", altSorting);
    reload();
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::removeAllFavorites()
{
  GUI::MessageBox::confirm(this,
    "This will remove ALL ROMs from\n"
    "your 'Favorites' list!\n\n"
    "Are you sure?",
    [this](bool ok) { if(ok) { myList->removeAllUserFavorites(); reload(); } },
    "Remove all Favorites", "Yes", "No");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::removeAll(string_view name, const std::function<void()>& action)
{
  GUI::MessageBox::confirm(this,
    std::format("This will remove ALL ROMs from\nyour '{}' list!\n\nAre you sure?", name),
    [this, action](bool ok) { if(ok) { action(); reload(); } },
    std::format("Remove all {}", name), "Yes", "No");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::removeAllPopular()
{
  removeAll("Most Popular", [this] { myList->removeAllPopular(); });
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void LauncherDialog::removeAllRecent()
{
  removeAll("Recently Played", [this] { myList->removeAllRecent(); });
}
