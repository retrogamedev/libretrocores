//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include "OSystem.hxx"
#include "Console.hxx"
#include "EventHandler.hxx"
#include "Launcher.hxx"
#include "PropsSet.hxx"
#include "ControllerDetector.hxx"
#include "NTSCFilter.hxx"
#include "PopUpWidget.hxx"
#include "MessageBox.hxx"
#include "TIASurface.hxx"
#include "Layout.hxx"

#include "StellaSettingsDialog.hxx"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
StellaSettingsDialog::StellaSettingsDialog(OSystem& osystem,
                                           DialogContainer& parent,
                                           AppMode mode)
  : Dialog(osystem, parent, osystem.frameBuffer().font(), "Basic settings"),
    myMode{mode}
{
  WidgetArray wid;

  // NOLINTBEGIN(cppcoreguidelines-prefer-member-initializer)
  myAdvancedButton = new ButtonWidget(this, _font,
    "Use Advanced Settings" + ELLIPSIS, Cmd::AdvancedSettings);
  wid.push_back(myAdvancedButton);
  myHelpButton = new ButtonWidget(this, _font, "Help" + ELLIPSIS, Cmd::Help);
  wid.push_back(myHelpButton);

  myGlobalLbl = new LabelWidget(this, _font, "Global settings:");
  createUIOptions(wid);
  createVideoOptions(wid);

  myGameSettings = new LabelWidget(this, _font, "Game settings:");
  createGameOptions(wid);

  // Add Defaults, OK and Cancel buttons
  addDefaultsOKCancelBGroup(wid, _font);

  addToFocusList(wid);
  // NOLINTEND(cppcoreguidelines-prefer-member-initializer)
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
StellaSettingsDialog::~StellaSettingsDialog() = default;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::createUIOptions(WidgetArray& wid)
{
  VariantList items;

  VarList::push_back(items, "Standard", "standard");
  VarList::push_back(items, "Classic", "classic");
  VarList::push_back(items, "Light", "light");
  myThemePopupLbl = new LabelWidget(this, _font, "UI theme");
  myThemePopup = new PopUpWidget(this, _font, items);
  wid.push_back(myThemePopup);

  // Dialog position
  items.clear();
  VarList::push_back(items, "Centered", 0);
  VarList::push_back(items, "Left top", 1);
  VarList::push_back(items, "Right top", 2);
  VarList::push_back(items, "Right bottom", 3);
  VarList::push_back(items, "Left bottom", 4);
  myPositionPopupLbl = new LabelWidget(this, _font, "Dialogs position");
  myPositionPopup = new PopUpWidget(this, _font, items);
  wid.push_back(myPositionPopup);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::createVideoOptions(WidgetArray& wid)
{
  const GUI::Font& ifont = instance().frameBuffer().infoFont();
  VariantList items;

  // TV effects options
  const int swidth = 11;

  // These controls all draw their own label, and the pop-up sizes its own value
  // box; layout() gives the group one label column and one box width (see
  // GUI::alignLabels / GUI::alignPopUps), so none of them names a width here

  // TV Mode
  VarList::push_back(items, "Disabled", static_cast<uInt32>(NTSCFilter::Preset::OFF));
  VarList::push_back(items, "RGB", static_cast<uInt32>(NTSCFilter::Preset::RGB));
  VarList::push_back(items, "S-Video", static_cast<uInt32>(NTSCFilter::Preset::SVIDEO));
  VarList::push_back(items, "Composite", static_cast<uInt32>(NTSCFilter::Preset::COMPOSITE));
  VarList::push_back(items, "Bad adjust", static_cast<uInt32>(NTSCFilter::Preset::BAD));
  myTVModeLbl = new LabelWidget(this, _font, "TV mode");
  myTVMode = new PopUpWidget(this, _font, items);
  wid.push_back(myTVMode);

  // Scanline intensity
  myTVScanIntenseLbl = new LabelWidget(this, _font, "Scanline intensity");
  myTVScanIntense = new SliderWidget(this, _font, swidth, Cmd::ScanlinesChanged, 3);
  myTVScanIntense->setMinValue(0); myTVScanIntense->setMaxValue(10);
  myTVScanIntense->setTickmarkIntervals(2);
  wid.push_back(myTVScanIntense);

  // TV Phosphor blend level
  myTVPhosLevelLbl = new LabelWidget(this, _font, "Phosphor blend");
  myTVPhosLevel = new SliderWidget(this, _font, swidth, Cmd::PhosphorChanged, 3);
  myTVPhosLevel->setMinValue(0); myTVPhosLevel->setMaxValue(10);
  myTVPhosLevel->setTickmarkIntervals(2);
  wid.push_back(myTVPhosLevel);

  // FS overscan
  myTVOverscanLbl = new LabelWidget(this, _font, "Overscan (*)");
  myTVOverscan = new SliderWidget(this, _font, swidth, Cmd::OverscanChanged, 3);
  myTVOverscan->setMinValue(0); myTVOverscan->setMaxValue(10);
  myTVOverscan->setTickmarkIntervals(2);
  wid.push_back(myTVOverscan);

  myOverscanInfo = new LabelWidget(this, ifont, "(*) Change requires launcher reboot");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::createGameOptions(WidgetArray& wid)
{
  const GUI::Font& ifont = instance().frameBuffer().infoFont();
  VariantList ctrls;

  VarList::push_back(ctrls, "Auto-detect", "AUTO");
  VarList::push_back(ctrls, "Joystick", "JOYSTICK");
  VarList::push_back(ctrls, "Paddles", "PADDLES");
  VarList::push_back(ctrls, "Booster Grip", "BOOSTERGRIP");
  VarList::push_back(ctrls, "Driving", "DRIVING");
  VarList::push_back(ctrls, "Keyboard", "KEYBOARD");
  VarList::push_back(ctrls, "Amiga mouse", "AMIGAMOUSE");
  VarList::push_back(ctrls, "Atari mouse", "ATARIMOUSE");
  VarList::push_back(ctrls, "Trak-Ball", "TRAKBALL");
  VarList::push_back(ctrls, "Sega Genesis", "GENESIS");
  VarList::push_back(ctrls, "Joy2B+", "JOY_2B+"); // TODO: should work, but needs testing with real hardware
  VarList::push_back(ctrls, "QuadTari", "QUADTARI");

  // Both port popups offer this same (fixed) list, so they size themselves to it
  myLeftPortLbl = new LabelWidget(this, _font, "Left port");
  myLeftPort = new PopUpWidget(this, _font, ctrls, Cmd::LeftControllerChanged);
  wid.push_back(myLeftPort);
  myLeftPortDetected = new LabelWidget(this, ifont, "Sega Genesis detected");

  myRightPortLbl = new LabelWidget(this, _font, "Right port");
  myRightPort = new PopUpWidget(this, _font, ctrls, Cmd::RightControllerChanged);
  wid.push_back(myRightPort);
  myRightPortDetected = new LabelWidget(this, ifont, "Sega Genesis detected");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::layout()
{
  using GUI::BoxLayout;
  using GUI::stretchedItem;
  using GUI::GridLayout;
  using GUI::anchoredItem;
  using GUI::labeledRow;
  using GUI::indentedItem;
  using Dir = BoxLayout::Dir;

  const int fontWidth    = Dialog::fontWidth(),
            buttonHeight = Dialog::buttonHeight(),
            VBORDER      = Dialog::vBorder(),
            HBORDER      = Dialog::hBorder(),
            VGAP         = Dialog::vGap(),
            INDENT       = Dialog::indent();

  // The pop-ups and the sliders each have a separate label; all share one
  // label column, lining their boxes and tracks up down the dialog...
  GUI::alignLabels({{myThemePopupLbl}, {myPositionPopupLbl}, {myTVModeLbl},
                    {myTVScanIntenseLbl}, {myTVPhosLevelLbl}, {myTVOverscanLbl}});
  // ...and one shared box width keeps the pop-ups' right edges flush too
  GUI::alignPopUps({myThemePopup, myPositionPopup, myTVMode});

  // Top row: "Use Advanced Settings" fills the width (but never shrinks below
  // what its own label needs), "Help" keeps its width at the right
  auto buttonRow = std::make_unique<BoxLayout>(Dir::Horizontal);
  buttonRow->addStretch(stretchedItem(myAdvancedButton,
                                      myAdvancedButton->getWidth()));
  buttonRow->addSpace(fontWidth);
  buttonRow->addAuto(anchoredItem(myHelpButton));

  // Game settings: the two controller ports.  Each pop-up sits right of its
  // label in a column as wide as the longer of the two, and its "detected" line
  // sits beneath it in that same column -- so nothing measures a label
  auto ports = std::make_unique<GridLayout>(2, 4, fontWidth, VGAP);
  ports->columnAuto(0).columnAuto(1);
  for(int r = 0; r < 4; ++r)
    ports->rowAuto(r);
  ports->place(0, 0, anchoredItem(myLeftPortLbl));
  ports->place(1, 0, anchoredItem(myLeftPort));
  ports->place(1, 1, anchoredItem(myLeftPortDetected));
  ports->place(0, 2, anchoredItem(myRightPortLbl));
  ports->place(1, 2, anchoredItem(myRightPort));
  ports->place(1, 3, anchoredItem(myRightPortDetected));

  auto portsRow = std::make_unique<BoxLayout>(Dir::Horizontal);
  portsRow->addSpace(INDENT);
  portsRow->addStretch(std::move(ports));

  auto root = std::make_unique<BoxLayout>(Dir::Vertical, 0, HBORDER, VBORDER);
  root->addAuto(std::move(buttonRow));
  root->addSpace(VGAP * 2);

  // Global settings: header, then the indented UI and video options
  root->addAuto(anchoredItem(myGlobalLbl));
  root->addSpace(VGAP);
  auto themeRow = std::make_unique<BoxLayout>(Dir::Horizontal);
  themeRow->addSpace(INDENT);
  themeRow->addStretch(labeledRow(myThemePopupLbl, myThemePopup));
  root->addAuto(std::move(themeRow));
  root->addSpace(VGAP);
  auto positionRow = std::make_unique<BoxLayout>(Dir::Horizontal);
  positionRow->addSpace(INDENT);
  positionRow->addStretch(labeledRow(myPositionPopupLbl, myPositionPopup));
  root->addAuto(std::move(positionRow));
  root->addSpace(VGAP * 5);
  auto tvModeRow = std::make_unique<BoxLayout>(Dir::Horizontal);
  tvModeRow->addSpace(INDENT);
  tvModeRow->addStretch(labeledRow(myTVModeLbl, myTVMode));
  root->addAuto(std::move(tvModeRow));
  root->addSpace(VGAP);
  root->addAuto(labeledRow(myTVScanIntenseLbl, myTVScanIntense, 0, INDENT));
  root->addSpace(VGAP);
  root->addAuto(labeledRow(myTVPhosLevelLbl, myTVPhosLevel, 0, INDENT));
  root->addSpace(VGAP);
  root->addAuto(labeledRow(myTVOverscanLbl, myTVOverscan, 0, INDENT));
  root->addSpace(VGAP);
  root->addAuto(indentedItem(myOverscanInfo, INDENT));
  root->addSpace(VGAP * 5);

  root->addAuto(anchoredItem(myGameSettings));
  root->addSpace(VGAP);
  root->addAuto(std::move(portsRow));

  // The dialog is as large as its content asks to be, and at least wide enough
  // for the button row below it (which the content knows nothing about)
  const Common::Size natural = root->naturalSize();

  _w = std::max(static_cast<int>(natural.w), Dialog::buttonGroupWidth());
  _h = _th + static_cast<int>(natural.h) + buttonHeight + VBORDER;

  root->doLayout(0, _th, _w, _h - _th);

  // Standard button group (Defaults / OK / Cancel) along the bottom edge
  layoutButtonGroup();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::loadConfig()
{
  const Settings& settings = instance().settings();

  // UI palette
  const string& theme = settings.getString("uipalette");
  myThemePopup->setSelected(theme, "standard");
  // Dialog position
  myPositionPopup->setSelected(settings.getString("dialogpos"), "0");

  // TV Mode
  myTVMode->setSelected(settings.getString("tv.filter"), "0");

  // TV scanline intensity
  myTVScanIntense->setValue(valueToLevel(settings.getInt("tv.scanlines")));

  // TV phosphor blend
  myTVPhosLevel->setValue(valueToLevel(settings.getInt(PhosphorHandler::SETTING_BLEND)));

  // TV overscan
  myTVOverscan->setValue(settings.getInt("tia.fs_overscan"));

  handleOverscanChange();

  // Controllers
  if(instance().hasConsole())
  {
    myGameProperties = instance().console().properties();
  }
  else
  {
    const string& md5 = instance().launcher().selectedRomMD5();
    instance().propSet().getMD5(md5, myGameProperties);
  }
  loadControllerProperties(myGameProperties);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::saveConfig()
{
  Settings& settings = instance().settings();

  // UI palette
  settings.setValue("uipalette", myThemePopup->getSelectedTag().toString());
  instance().frameBuffer().setUIPalette();
  instance().frameBuffer().update(FrameBuffer::UpdateMode::REDRAW);

  // Dialog position
  settings.setValue("dialogpos", myPositionPopup->getSelectedTag().toString());

  // TV Mode
  instance().settings().setValue("tv.filter", myTVMode->getSelectedTag().toString());

  // TV phosphor mode
  instance().settings().setValue(PhosphorHandler::SETTING_MODE,
                                 myTVPhosLevel->getValue() > 0
                                  ? PhosphorHandler::VALUE_ALWAYS
                                  : PhosphorHandler::VALUE_BYROM);
  // TV phosphor blend
  instance().settings().setValue(PhosphorHandler::SETTING_BLEND,
    levelToValue(myTVPhosLevel->getValue()));

  // TV scanline intensity and interpolation
  instance().settings().setValue("tv.scanlines",
    levelToValue(myTVScanIntense->getValue()));

  // TV overscan
  instance().settings().setValue("tia.fs_overscan", myTVOverscan->getValueLabel());

  // Controller properties
  myGameProperties.set(PropType::Controller_Left, myLeftPort->getSelectedTag().toString());
  myGameProperties.set(PropType::Controller_Right, myRightPort->getSelectedTag().toString());

  // Always insert; if the properties are already present, nothing will happen
  instance().propSet().insert(myGameProperties);
  instance().saveConfig();

  // In any event, inform the Console
  if(instance().hasConsole())
    instance().console().setProperties(myGameProperties);

  // Finally, issue a complete framebuffer re-initialization...
  instance().createFrameBuffer();

  // ... and apply potential setting changes to the TIA surface
  instance().frameBuffer().tiaSurface().updateSurfaceSettings();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::setDefaults()
{
  // UI Theme
  myThemePopup->setSelected("standard");
  // Dialog position
  myPositionPopup->setSelected("0");

  // TV effects
  myTVMode->setSelected("RGB", static_cast<uInt32>(NTSCFilter::Preset::RGB));
  // TV scanline intensity
  myTVScanIntense->setValue(3); // 18
  // TV phosphor blend
  myTVPhosLevel->setValue(6); // = 45
  // TV overscan
  myTVOverscan->setValue(0);

  // Load the default game properties
  Properties defaultProperties;
  string_view md5 = myGameProperties.get(PropType::Cart_MD5);

  instance().propSet().getMD5(md5, defaultProperties, true);

  loadControllerProperties(defaultProperties);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::handleCommand(CommandSender* sender, GuiCmd::Code cmd,
                                         int data, int id)
{
  switch(cmd)
  {
    case GuiObject::Cmd::Defaults:
      setDefaults();
      break;

    case GuiObject::Cmd::OK:
      saveConfig();
      [[fallthrough]];
    case GuiObject::Cmd::Close:
      if(myMode != AppMode::emulator)
        close();
      else
        instance().eventHandler().leaveMenuMode();
      break;

    case Cmd::AdvancedSettings:
      switchSettingsMode();
      break;

    case Cmd::Help:
      openHelp();
      break;

    case Cmd::ScanlinesChanged:
      if(myTVScanIntense->getValue() == 0)
        myTVScanIntense->setValueLabel("Off");
      break;

    case Cmd::PhosphorChanged:
      if(myTVPhosLevel->getValue() == 0)
        myTVPhosLevel->setValueLabel("Off");
      break;

    case Cmd::OverscanChanged:
      handleOverscanChange();
      break;

    case Cmd::LeftControllerChanged:
    case Cmd::RightControllerChanged:
      updateControllerStates();
      break;

    default:
      Dialog::handleCommand(sender, cmd, data, 0);
      break;
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::handleOverscanChange()
{
  if(myTVOverscan->getValue() == 0)
  {
    myTVOverscan->setValueLabel("Off");
    myTVOverscan->setValueUnit("");
  }
  else
    myTVOverscan->setValueUnit("%");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::switchSettingsMode()
{
  GUI::MessageBox::confirm(this,
    "Warning!\n\n"
    "Advanced settings should be\n"
    "handled with care! When in\n"
    "doubt, read the manual.\n\n"
    "If you are sure you want to\n"
    "proceed with the switch, click\n"
    "'OK', otherwise click 'Cancel'.",
    [this](bool ok) {
      if(ok)
      {
        instance().settings().setValue("basic_settings", false);
        if(myMode != AppMode::emulator)
          close();
        else
          instance().eventHandler().leaveMenuMode();
      }
    },
    "Switch settings mode");
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::loadControllerProperties(const Properties& props)
{
  // Determine whether we should enable the "Game settings:"
  // We always enable it in emulation mode, or if a valid ROM is selected
  // in launcher mode
  bool enable = false;

  if(instance().eventHandler().state() == EventHandlerState::LAUNCHER)
    enable = !instance().launcher().selectedRomMD5().empty();
  else
    // Any in-game menu: enabled whenever a console is running behind it
    enable = instance().hasConsole();

  myGameSettings->setEnabled(enable);
  myLeftPort->setEnabled(enable);
  myLeftPortLbl->setEnabled(enable);
  myLeftPortDetected->setEnabled(enable);
  myRightPort->setEnabled(enable);
  myRightPortLbl->setEnabled(enable);
  myRightPortDetected->setEnabled(enable);

  if(enable)
  {
    string controller{props.get(PropType::Controller_Left)};
    myLeftPort->setSelected(controller, "AUTO");
    controller = props.get(PropType::Controller_Right);
    myRightPort->setSelected(controller, "AUTO");

    updateControllerStates();
  }
  else
  {
    myLeftPort->clearSelection();
    myRightPort->clearSelection();
    myLeftPortDetected->setLabel("");
    myRightPortDetected->setLabel("");
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
int StellaSettingsDialog::levelToValue(int level)
{
  static constexpr int NUM_LEVELS = 11;
  static constexpr std::array<uInt8, NUM_LEVELS> values = {
    0, 5, 11, 18, 26, 35, 45, 56, 68, 81, 95
  };

  return values[std::min(level, NUM_LEVELS - 1)];
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
int StellaSettingsDialog::valueToLevel(int value)
{
  static constexpr int NUM_LEVELS = 11;
  static constexpr std::array<uInt8, NUM_LEVELS> values = {
    0, 5, 11, 18, 26, 35, 45, 56, 68, 81, 95
  };

  for(int i = NUM_LEVELS - 1; i > 0; --i)
  {
    if(std::cmp_greater_equal(value, values[i]))
      return i;
  }
  return 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::openHelp()
{
  // Create an help dialog, similar to the in-game one
  if(myHelpDialog == nullptr)
    myHelpDialog = std::make_unique<HelpDialog>(instance(), parent(), _font);
  myHelpDialog->open();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void StellaSettingsDialog::updateControllerStates()
{
  ByteArray image;
  string md5{myGameProperties.get(PropType::Cart_MD5)};

  // try to load the image for auto detection
  if(!instance().hasConsole())
  {
    const FSNode& node = FSNode(instance().launcher().selectedRom());
    if(node.exists() && !node.isDirectory())
      image = instance().openROM(node, md5);
  }

  string label;
  Controller::Type type = Controller::getType(myLeftPort->getSelectedTag().toString());
  if(type == Controller::Type::Unknown)
  {
    if(instance().hasConsole())
      label = (instance().console().leftController().name()) + " detected";
    else if(!image.empty())
      label = std::format("{} detected", ControllerDetector::detectName(image, type,
                                             Controller::Jack::Left,
                                             instance().settings()));
  }
  myLeftPortDetected->setLabel(label);

  label = "";
  type = Controller::getType(myRightPort->getSelectedTag().toString());
  if(type == Controller::Type::Unknown)
  {
    if(instance().hasConsole())
      label = (instance().console().rightController().name()) + " detected";
    else if(!image.empty())
      label = std::format("{} detected", ControllerDetector::detectName(image, type,
                                             Controller::Jack::Right,
                                             instance().settings()));
  }
  myRightPortDetected->setLabel(label);

  // Compumate bankswitching scheme doesn't allow to select controllers
  const bool enableSelectControl = myGameProperties.get(PropType::Cart_Type) != "CM";
  myLeftPortLbl->setEnabled(enableSelectControl);
  myRightPortLbl->setEnabled(enableSelectControl);
  myLeftPort->setEnabled(enableSelectControl);
  myRightPort->setEnabled(enableSelectControl);
}
