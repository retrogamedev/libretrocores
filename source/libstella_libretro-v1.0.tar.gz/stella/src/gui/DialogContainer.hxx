//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#ifndef DIALOG_CONTAINER_HXX
#define DIALOG_CONTAINER_HXX

class Dialog;
class OSystem;
class EventHandler;

#include "EventHandlerConstants.hxx"
#include "Event.hxx"
#include "StellaKeys.hxx"
#include "Stack.hxx"
#include "bspf.hxx"

/**
  The base class for groups of dialog boxes.  Each dialog box has a
  parent.  In most cases, the parent is itself a dialog box, but in the
  case of the lower-most dialog box, this class is its parent.

  This class keeps track of its children (dialog boxes), organizes them into
  a stack, and handles their events.

  @author  Stephen Anthony
*/
class DialogContainer
{
  friend class EventHandler;
  friend class Dialog;

  public:
    /**
      Create a new DialogContainer stack
    */
    explicit DialogContainer(OSystem& osystem);
    virtual ~DialogContainer() = default;

  public:
    /**
      Update the dialog container with the current time.
      This is useful if we want to trigger events at some specified time.

      @param time  The current time in microseconds
    */
    virtual void updateTime(uInt64 time);

    /**
      Handle a keyboard Unicode text event.

      @param text   Unicode character string
    */
    void handleTextEvent(char text);

    /**
      Handle a keyboard single-key event.

      @param key      Actual key symbol
      @param mod      Modifiers
      @param pressed  Pressed (true) or released (false)
    */
    void handleKeyEvent(StellaKey key, StellaMod mod, bool pressed, bool repeat);

    /**
      Handle a mouse motion event.

      @param x  The x location
      @param y  The y location
    */
    void handleMouseMotionEvent(int x, int y);

    /**
      Handle a mouse button event.

      @param b        The mouse button
      @param pressed  Whether the button was pressed (true) or released (false)
      @param x        The x location
      @param y        The y location
    */
    void handleMouseButtonEvent(MouseButton b, bool pressed, int x, int y);

    /**
      Handle a joystick button event.

      @param stick   The joystick number
      @param button  The joystick button
      @param pressed Pressed (true) or released (false)
    */
    void handleJoyBtnEvent(int stick, int button, bool pressed);

    /**
      Handle a joystick axis event.

      @param stick  The joystick number
      @param axis   The joystick axis
      @param adir   Value associated with given axis
    */
    void handleJoyAxisEvent(int stick, JoyAxis axis, JoyDir adir, int button);

    /**
      Handle a joystick hat event.

      @param stick  The joystick number
      @param hat    The joystick hat
      @param hdir   Direction of the given hat
    */
    void handleJoyHatEvent(int stick, int hat, JoyHatDir hdir, int button);

    /**
      Handle an arbitray dialog event.

      @param event  The send event
    */
    void handleEvent(Event::Type event);

    /**
      Tick the dialog and all its widgets.
    */
    void tick();

    /**
      Draw the stack of menus (full indicates to redraw all items).
    */
    void draw(bool full = false);

    /**
      Render the stack of menus.
    */
    void render();

    /**
      Answers whether a full redraw is required.
    */
    bool needsRedraw() const;

    /**
      Answers whether the base dialog is currently active
      (ie, there are no overlaid dialogs other than the bottom one)
    */
    bool baseDialogIsActive() const;

    /**
      Reset dialog stack to the main configuration menu.
    */
    void reStack();

    /**
      Inform the container that it should resize according to the current
      screen dimensions.  We make this virtual, since the container may or
      may not choose to do a resize, and even if it does, *how* it does it
      is determined by the specific container.
    */
    virtual void requestResize();

    /**
      Whether an interactive window resize is currently in progress.  Dialogs
      can use this to defer work that should not run on every frame of a drag
      (e.g. re-asserting the window minimum size, persisting the final size)
      until the resize has settled.
    */
    virtual bool resizeInProgress() const { return false; }

    /**
      Apply a pending live window resize (recorded via FrameBuffer::liveResize)
      and re-flow this container, throttled to roughly the display rate.
      Returns true if it applied — the caller then presents the new frame.

      This is driven from the resize event handler (not just the main loop) so
      that it also runs during the Windows/macOS modal resize loop, when the
      main loop — and hence updateTime() — is blocked.  The base container does
      nothing.
    */
    virtual bool applyResize() { return false; }

    /**
      Re-flow every dialog in the stack for the current window size.
    */
    void relayout();

    /**
      Re-font every dialog belonging to this container after the font has been
      changed in place (see OSystem::refreshFonts), so they re-font live with
      no restart.  Reaches every dialog registered with us, not just the open
      stack: one that is merely cached (e.g. the menus OverlayMenu keeps per
      EventHandlerState) would otherwise stay stale until next shown.
    */
    void refreshFont();

    /**
      Return (and possibly create) the bottom-most dialog of this container.
    */
    virtual Dialog* baseDialog() = 0;

    /**
      Set input speeds.
    */
    static void setDoubleClickDelay(int delay) { S_DOUBLE_CLICK_DELAY = delay; }
    static void setControllerDelay(int delay) { S_REPEAT_INITIAL_DELAY = delay; }
    static void setControllerRate(int rate) {
      S_REPEAT_SUSTAIN_DELAY = (rate > 0 ? (1000 / rate) : 50);
    }

  private:
    // Clears all continuous-event tracking state (mouse/joy button/axis/hat down,
    // last-click); called at construction and by reStack()
    void reset();

    /**
      Add a dialog box to the stack.
    */
    int addDialog(Dialog* d);

    /**
      Remove the topmost dialog box from the stack.
    */
    void removeDialog();

    /**
      Track every dialog built for this container, whether or not it is
      currently on the stack.  A Dialog registers itself as it is constructed
      and deregisters as it is destroyed, the way a Widget adds itself to its
      boss's child list -- so nothing has to remember to do it by hand.
    */
    void registerDialog(Dialog* d);
    void deregisterDialog(const Dialog* d);

  protected:
    // Parent system, used to reach the frame buffer/event handler/settings
    OSystem& myOSystem;
    // The currently open dialogs, bottom to top; the top one receives input
    Common::FixedStack<Dialog*> myDialogStack;

  private:
    // Every dialog belonging to this container, in creation order and
    // non-owning (each is owned by whatever created it).  A superset of
    // myDialogStack, which holds only the currently open ones
    vector<Dialog*> myAllDialogs;

    // Indicates the most current time (in milliseconds) as set by updateTime()
    uInt64 myTime{0};

    // Input-repeat timing, in milliseconds; set via setDoubleClickDelay() etc.
    static inline uInt64 S_DOUBLE_CLICK_DELAY = 500;
    static inline uInt64 S_REPEAT_INITIAL_DELAY = 400;
    static inline uInt64 S_REPEAT_SUSTAIN_DELAY = 50;
    static constexpr uInt64 S_REPEAT_NONE = 1ULL << 24U; // loooong
    static constexpr uInt64 S_LONG_PRESS_DELAY = 1000; // 1 second

    // For continuous 'mouse down' events
    struct {
      int x{0};
      int y{0};
      MouseButton b{MouseButton::NONE};
    } myCurrentMouseDown;
    // When the held mouse button next re-fires (see updateTime())
    uInt64 myClickRepeatTime{0};

    // For continuous 'joy button down' events
    struct {
      int stick{-1};
      int button{-1};
    } myCurrentButtonDown;
    // When the held joystick button next re-fires / triggers its long-press
    uInt64 myButtonRepeatTime{0};
    uInt64 myButtonLongPressTime{0};
    // Set once a button has fired its long-press, so the eventual release
    // isn't also reported as a (short) button-up
    bool myIgnoreButtonUp{false};

    // For continuous 'joy axis down' events
    struct {
      int stick{-1};
      JoyAxis axis{JoyAxis::NONE};
      JoyDir adir{JoyDir::NONE};
    } myCurrentAxisDown;
    // When the held joystick axis next re-fires
    uInt64 myAxisRepeatTime{0};

    // For continuous 'joy hat' events
    struct {
      int stick{-1};
      int hat{-1};
      JoyHatDir hdir{JoyHatDir::CENTER};
    } myCurrentHatDown;
    // When the held joystick hat next re-fires
    uInt64 myHatRepeatTime{0};

    // Position and time of last mouse click (used to detect double clicks)
    struct {
      int x{0}, y{0}; // Position of mouse when the click occurred
      int count{0};   // How often was it already pressed?
      uInt64 time{0}; // Time
    } myLastClick;

  private:
    // Following constructors and assignment operators not supported
    DialogContainer() = delete;
    DialogContainer(const DialogContainer&) = delete;
    DialogContainer(DialogContainer&&) = delete;
    DialogContainer& operator=(const DialogContainer&) = delete;
    DialogContainer& operator=(DialogContainer&&) = delete;
};

#endif  // DIALOG_CONTAINER_HXX
