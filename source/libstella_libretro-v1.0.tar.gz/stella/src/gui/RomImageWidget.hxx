//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#ifndef ROM_IMAGE_WIDGET_HXX
#define ROM_IMAGE_WIDGET_HXX

class FBSurface;
class Properties;

#include "Widget.hxx"

/**
  Shows a ROM's snapshot image(s) in the launcher, with navigation
  between multiple matches and a zoom mode.

  @author  Stephen Anthony and Thomas Jentzsch
*/
class RomImageWidget : public Widget
{
  public:
    RomImageWidget(GuiObject *boss, const GUI::Font& font);
    ~RomImageWidget() override = default;

    // Height reserved below the image for its label/counter line
    static int labelHeight(const GUI::Font& font)
    {
      return font.getFontHeight() * 9 / 8;
    }

    // Sets the properties to load an image for (parsed immediately if the
    // launcher is active); 'full' additionally loads every matching snapshot,
    // not just the first, so changeImage() has something to cycle through
    void setProperties(const FSNode& node, const Properties& properties,
                       bool full = true);
    // Clears the display; used when nothing (or an invalid ROM) is selected
    void clearProperties();
    // Re-parses the current properties (e.g. after a change made in the ROM browser)
    void reloadProperties(const FSNode& node);

    // Reposition and resize the widget, rescaling the current image to fit.
    // Used when the launcher (and thus this widget) is resized.
    void setArea(int x, int y, int w, int h) override;
    // Loads the previous/next (direction -1/+1) image in myImageList, if any
    bool changeImage(int direction = 1);
    // Toggle zoom via keyboard
    void toggleImageZoom();
    void disableImageZoom() { myZoomMode = false; }

    // Estimated time (ms) the next image load may take, for callers deciding
    // whether to show a "loading" indicator first
    uInt64 pendingLoadTime() const { return myMaxLoadTime * timeFactor; }

  #ifdef IMAGE_SUPPORT
    // Arrow keys/PgUp/PgDn change images; OK/Select toggles zoom
    bool handleEvent(Event::Type event) override;
    // Clicking the left/right nav arrow changes images; elsewhere toggles zoom
    void handleMouseUp(int x, int y, MouseButton b, int clickCount) override;
    // Tracks which nav area (left/right/zoom) the mouse is currently over
    void handleMouseMoved(int x, int y) override;
    // Advances the hover-to-zoom delay timer, growing/shrinking the zoomed view
    void tick() override;
  #endif

  protected:
    // Draws the image (or an error message), its label/counter, and (while
    // highlighted) the prev/next/zoom navigation icons
    void drawWidget(bool hilite) override;

  private:
    // Builds myImageList (or loads the single best-match image if !full) from
    // myProperties, and loads the first entry
    void parseProperties(const FSNode& node, bool full = true);
  #ifdef IMAGE_SUPPORT
    // Finds every snapshot matching 'propName'/'romName' into myImageList,
    // sorted so 'oldFileName' (the previously first match) stays first
    bool getImageList(const string& propName, const string& romName,
                      const string& oldFileName);
    // Tries 'fileName' with a .png then a .jpg extension; appends whichever loads
    bool tryImageFormats(string& fileName);
    // Loads 'fileName' (by its extension) into mySurface, updating mySurfaceIsValid
    bool loadImage(const string& fileName);
    // Format-specific loaders, called by loadImage(); also extract myLbl from metadata
    bool loadPng(const string& fileName);
    bool loadJpg(const string& fileName);

    // Rescales mySurface (and, when zoomed, myFrameSurface) for the current
    // area or the zoomed layout; positions them via positionSurfaces()
    void zoomSurfaces(bool zoomed, bool force = false);
    // Places mySurface (and myFrameSurface, if zoomed) at their on-screen destination
    void positionSurfaces();
  #endif

  private:
    // Pending load time safety factor
    static constexpr double timeFactor = 1.2;

  private:
    // Navigation areas
    enum class Area: uInt8 {
      NONE,
      LEFT,
      RIGHT,
      ZOOM
    };

    // Zoom delay [frames]
    static constexpr uInt32 DELAY_TIME = 45;

    // The zoom is faster requested than released, so that repeated zooms
    //  are shown faster. This constant defines how much faster.
    static constexpr uInt32 REQUEST_SPEED = 2;

    // Surface pointer holding the image
    shared_ptr<FBSurface> mySurface;

    // Surface pointer holding the navigation elements
    shared_ptr<FBSurface> myNavSurface;

    // Surface pointer holding the frame around the zoomed image
    shared_ptr<FBSurface> myFrameSurface;

    // Whether the surface should be redrawn by drawWidget()
    bool mySurfaceIsValid{false};

    // Rectangle holdering the original surface size
    Common::Rect mySrcRect;

    // Zoom icon rectangle
    Common::Rect myZoomRect;

    // True for keyboard zooming
    bool myZoomMode{false};

    // Surface zoom status
    bool myIsZoomed{false};

  #ifdef IMAGE_SUPPORT
    // Zoom delay timer
    uInt32 myZoomTimer{0};

    // Initial zoom position
    Common::Point myZoomPos;

    // Last mouse position, used for zooming
    Common::Point myMousePos;
  #endif

    // Current navigation area of the mouse
    Area myMouseArea{Area::NONE};

    // The properties for the currently selected ROM
    Properties myProperties;

    // Indicates if the current properties should actually be used
    bool myHaveProperties{false};

    // Indicates if an error occurred in creating/displaying the surface
    string mySurfaceErrorMsg;

    // Height of the image area
    int myImageHeight{0};

    // Contains the list of image names for the current ROM
    FSList myImageList;

    // Index of currently displayed image
    size_t myImageIdx{0};

    // Label for the loaded image
    string myLbl;

    // Maximum load time, for adapting pending loads delay
    uInt64 myMaxLoadTime{0};

  private:
    // Following constructors and assignment operators not supported
    RomImageWidget() = delete;
    RomImageWidget(const RomImageWidget&) = delete;
    RomImageWidget(RomImageWidget&&) = delete;
    RomImageWidget& operator=(const RomImageWidget&) = delete;
    RomImageWidget& operator=(RomImageWidget&&) = delete;
};

#endif  // ROM_IMAGE_WIDGET_HXX
