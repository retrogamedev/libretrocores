//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include "OSystem.hxx"
#include "EventHandler.hxx"
#include "Widget.hxx"
#include "Font.hxx"
#include "EditTextWidget.hxx"
#include "PopUpWidget.hxx"
#include "StringListWidget.hxx"
#include "Variant.hxx"
#include "Layout.hxx"
#include "JoystickDialog.hxx"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
JoystickDialog::JoystickDialog(GuiObject* boss, const GUI::Font& font)
  : Dialog(boss->instance(), boss->parent(), font, "Controller database")
{
  WidgetArray wid;

  // NOLINTBEGIN(cppcoreguidelines-prefer-member-initializer)
  // Joystick list
  myJoyList = new StringListWidget(this, font);
  myJoyList->setEditable(false);
  wid.push_back(myJoyList);

  // Joystick ID
  myIDLbl = new LabelWidget(this, font, "Controller ID");
  myJoyText = new EditTextWidget(this, font,
      static_cast<int>(string_view("Unplugged").size()));
  myJoyText->setEditable(false);

  // Port
  VariantList ports;
  VarList::push_back(ports, "Auto",  static_cast<Int32>(PhysicalJoystick::Port::AUTO));
  VarList::push_back(ports, "Left",  static_cast<Int32>(PhysicalJoystick::Port::LEFT));
  VarList::push_back(ports, "Right", static_cast<Int32>(PhysicalJoystick::Port::RIGHT));

  myJoyPortLbl = new LabelWidget(this, font, "Port");
  myJoyPort = new PopUpWidget(this, font, ports, Cmd::Port);
  myJoyPort->setToolTip("Define default mapping port.");
  wid.push_back(myJoyPort);

  // Buttons at bottom
  myCloseBtn = new ButtonWidget(this, font, "Close", GuiObject::Cmd::Close);
  addOKWidget(myCloseBtn);  addCancelWidget(myCloseBtn);

  myRemoveBtn = new ButtonWidget(this, font, "Remove", Cmd::Remove);
  myRemoveBtn->clearFlags(Widget::Flag::Enabled);

  // Now we can finally add the widgets to the focus list
  wid.push_back(myRemoveBtn);
  wid.push_back(myCloseBtn);
  addToFocusList(wid);
  // NOLINTEND(cppcoreguidelines-prefer-member-initializer)
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void JoystickDialog::layout()
{
  using GUI::BoxLayout;
  using GUI::widgetItem;
  using GUI::anchoredItem;
  using GUI::labeledRow;
  using Dir = BoxLayout::Dir;

  const int fontWidth    = Dialog::fontWidth(),
            buttonHeight = Dialog::buttonHeight(),
            VBORDER      = Dialog::vBorder(),
            HBORDER      = Dialog::hBorder();

  // Remove and Close share one width, the wider of the two
  GUI::alignButtons({myRemoveBtn, myCloseBtn});

  GUI::alignLabels({{myJoyPortLbl}});

  // The list shows a reasonable number of joysticks by default -- which, with
  // the room device names need, is what sizes the dialog; more entries scroll.
  auto root = std::make_unique<BoxLayout>(Dir::Vertical, 0, HBORDER, VBORDER);
  root->addStretch(widgetItem(myJoyList, 60 * fontWidth,
                              ListWidget::calcHeight(_font, 12)));
  root->addSpace(VBORDER);
  root->addSpace(buttonHeight);  // reserve the button row

  // The list STRETCHES, so the band for the button group has to be reserved
  // above (see CheatCodeDialog for the same gotcha)
  const Common::Size natural = root->naturalSize();
  _w = std::max(static_cast<int>(natural.w), Dialog::buttonGroupWidth());
  _h = _th + static_cast<int>(natural.h);

  root->doLayout(0, _th, _w, _h - _th);

  // The button band is entirely this dialog's own: the controller ID readout on
  // the left, Remove / Close (which keep their natural widths, not the standard
  // group's) on the right.  Everything keeps its own size and is centered in the
  // (taller) band, so all the texts line up
  auto band = std::make_unique<BoxLayout>(Dir::Horizontal);
  band->addAuto(anchoredItem(myIDLbl));
  band->addSpace(fontWidth);
  band->addAuto(anchoredItem(myJoyText));
  band->addSpace(fontWidth * 2);
  band->addAuto(labeledRow(myJoyPortLbl, myJoyPort));
  band->addStretchSpace();
  band->addAuto(anchoredItem(myRemoveBtn));
  band->addSpace(fontWidth);
  band->addAuto(anchoredItem(myCloseBtn));
  layoutButtonBand(std::move(band));
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void JoystickDialog::loadConfig()
{
  myJoyIDs.clear();

  StringList sticks;
  for(const auto& entry: instance().eventHandler().physicalJoystickList())
  {
    sticks.push_back(entry.name);
    myJoyIDs.push_back(entry.ID);
    myJoyPorts.push_back(static_cast<int>(entry.port));
  }
  myJoyList->setList(sticks);
  myJoyList->setSelected(0);
  if(sticks.empty())
  {
    myRemoveBtn->setEnabled(false);
    myJoyText->setText("");
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void JoystickDialog::handleEvent(Event::Type event)
{
  if(event == Event::Type::UIReload)
    loadConfig();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void JoystickDialog::handleCommand(CommandSender* sender, GuiCmd::Code cmd,
                                   int data, int id)
{
  switch(cmd)
  {
    case GuiObject::Cmd::OK:
      close();
      break;

    case Cmd::Port:
      myJoyPorts[myJoyList->getSelected()] = myJoyPort->getSelected();
      instance().eventHandler().setPhysicalJoystickPortInDatabase(
          myJoyList->getSelectedString(),
          static_cast<PhysicalJoystick::Port>(myJoyPort->getSelected()));
      break;

    case Cmd::Remove:
      instance().eventHandler().removePhysicalJoystickFromDatabase(
          myJoyList->getSelectedString());
      loadConfig();
      break;

    case ListWidget::Cmd::SelectionChanged:
    {
      const bool isPlugged = myJoyIDs[data] >= 0;
      if(isPlugged)
      {
        myJoyText->setText(std::format("C{}", myJoyIDs[data]));
        myJoyPort->setSelected(myJoyPorts[data]);
      }
      else
      {
        myJoyText->setText("Unplugged");
        myJoyPort->setText("");
      }
      myJoyPortLbl->setEnabled(isPlugged);
      myJoyPort->setEnabled(isPlugged);
      myRemoveBtn->setEnabled(!isPlugged);
      break;
    }

    default:
      Dialog::handleCommand(sender, cmd, data, id);
      break;
  }
}
