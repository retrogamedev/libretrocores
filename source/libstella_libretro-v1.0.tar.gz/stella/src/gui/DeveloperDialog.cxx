//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include "bspf.hxx"
#include "OSystem.hxx"
#include "PointingDevice.hxx"
#include "SaveKey.hxx"
#include "AtariVox.hxx"
#include "Settings.hxx"
#include "DevSettingsHandler.hxx"
#include "PopUpWidget.hxx"
#include "RadioButtonWidget.hxx"
#include "ColorWidget.hxx"
#include "TabWidget.hxx"
#include "TabPaneWidget.hxx"
#include "Widget.hxx"
#include "Layout.hxx"
#include "Font.hxx"
#include "Console.hxx"
#include "TIA.hxx"
#include "JitterEmulation.hxx"
#include "EventHandler.hxx"
#include "StateManager.hxx"
#include "RewindManager.hxx"
#include "M6502.hxx"
#include "CartELF.hxx"
#ifdef DEBUGGER_SUPPORT
  #include "Debugger.hxx"
  #include "DebuggerDialog.hxx"
  #include "FontManager.hxx"
#endif
#include "DeveloperDialog.hxx"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
DeveloperDialog::DeveloperDialog(OSystem& osystem, DialogContainer& parent,
                                 const GUI::Font& font)
  : Dialog(osystem, parent, font, "Developer settings"),
    DevSettingsHandler(osystem)
{
  // Widgets are only created here (at placeholder geometry); layout() sizes the
  // dialog and positions everything from the current font.  The tab bar geometry
  // is recomputed in layout() via TabWidget::updateTabSizes().
  // NOLINTBEGIN(cppcoreguidelines-prefer-member-initializer)
  myTab = new TabWidget(this, font);
  addTabWidget(myTab);

  addEmulationTab(font);
  addTiaTab(font);
  addVideoTab(font);
  addTimeMachineTab(font);
  addDebuggerTab(font);

  WidgetArray wid;
  addDefaultsOKCancelBGroup(wid, font);
  addBGroupToFocusList(wid);

  // Activate the first tab
  myTab->setActiveTab(0);

  setHelpAnchor("Debugger");
  // NOLINTEND(cppcoreguidelines-prefer-member-initializer)
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
DeveloperDialog::~DeveloperDialog() = default;

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::layout()
{
  const int buttonHeight = Dialog::buttonHeight(),
            VBORDER      = Dialog::vBorder(),
            VGAP         = Dialog::vGap();
  constexpr int xpos = 2;

  // Both dimensions come from what the tabs ask for: nothing here counts rows or
  // columns.  Every tab lays itself out via the tab widget, so there is no
  // per-tab code here either
  const Common::Size tabSize = myTab->naturalSize();

  myTab->setPos(xpos, VGAP + _th);
  myTab->setWidth(static_cast<int>(tabSize.w));
  myTab->setHeight(static_cast<int>(tabSize.h));

  _w = myTab->getWidth() + 2 * xpos;
  _h = _th + VGAP + myTab->getHeight() + VBORDER + buttonHeight + VBORDER;

  // Recompute the tab-bar geometry for the current font/width
  myTab->updateTabSizes();

  // Standard button group (Defaults / OK / Cancel) along the bottom edge
  layoutButtonGroup();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::addEmulationTab(const GUI::Font& font)
{
  const GUI::Font& infofont = instance().frameBuffer().infoFont();
  WidgetArray wid;
  VariantList items;

  const int tabID = myTab->addTab(" Emulation ", TabWidget::AUTO_WIDTH);
  auto* pane = new TabPaneWidget(myTab, font);
  myTab->setPaneWidget(tabID, pane);

  // settings set
  mySettingsGroupEmulation = std::make_unique<RadioButtonGroup>();
  myEmuSettings[0] = new RadioButtonWidget(pane, font, "Player settings",
                                           mySettingsGroupEmulation.get(), Cmd::PlayerSettings);
  myEmuSettings[0]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myEmuSettings[0]);
  myEmuSettings[1] = new RadioButtonWidget(pane, font, "Developer settings",
                                           mySettingsGroupEmulation.get(), Cmd::DeveloperSettings);
  myEmuSettings[1]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myEmuSettings[1]);

  myFrameStatsWidget = new CheckboxWidget(pane, font, "Console info overlay");
  myFrameStatsWidget->setToolTip(Event::ToggleFrameStats);
  wid.push_back(myFrameStatsWidget);

  myDetectedInfoWidget = new CheckboxWidget(pane, font, "Detected settings info");
  myDetectedInfoWidget->setToolTip("Display detected controllers, bankswitching\n"
                                   "and TV types at ROM start.");
  wid.push_back(myDetectedInfoWidget);

  // AtariVox/SaveKey/PlusROM access
  myExternAccessWidget = new CheckboxWidget(pane, font, "External access messages");
  myExternAccessWidget->setToolTip("Display a message for any external access\n"
                                   "AtariVox/SaveKey EEPROM, PlusROM, Supercharger...).");
  wid.push_back(myExternAccessWidget);

  // 2600/7800 mode
  items.clear();
  VarList::push_back(items, "Atari 2600", "2600");
  VarList::push_back(items, "Atari 7800", "7800");
  myConsoleWidgetLbl = new LabelWidget(pane, font, "Console");
  myConsoleWidget = new PopUpWidget(pane, font, items, Cmd::Console);
  myConsoleWidget->setToolTip("Emulate Color/B&W/Pause key and zero\n"
                              "page RAM initialization differently.");
  wid.push_back(myConsoleWidget);

  // PlusROM functionality
  myPlusRomWidget = new CheckboxWidget(pane, font, "PlusROM support");
  myPlusRomWidget->setToolTip("Enable PlusROM support");
  wid.push_back(myPlusRomWidget);

  // Randomize items
  myLoadingROMLbl = new LabelWidget(pane, font, "When loading a ROM:");
  wid.push_back(myLoadingROMLbl);

  myRandomBankWidget = new CheckboxWidget(pane, font, "Random startup bank");
  myRandomBankWidget->setToolTip("Randomize the startup bank for\n"
                                 "most classic bankswitching types.");
  wid.push_back(myRandomBankWidget);

  myRandomizeTIAWidget = new CheckboxWidget(pane, font, "Randomize TIA");
  wid.push_back(myRandomizeTIAWidget);

  // Randomize RAM
  myRandomizeRAMWidget = new CheckboxWidget(pane, font,
                                            "Randomize zero-page and extended RAM");
  wid.push_back(myRandomizeRAMWidget);

  // Randomize CPU
  myRandomizeCPULbl = new LabelWidget(pane, font, "Randomize CPU");
  wid.push_back(myRandomizeCPULbl);

  const std::array<string, 5> cpuregsLabels = {"SP", "A", "X", "Y", "PS"};
  for(int i = 0; i < 5; ++i)
  {
    myRandomizeCPUWidget[i] = new CheckboxWidget(pane, font, cpuregsLabels[i]);
    wid.push_back(myRandomizeCPUWidget[i]);
  }

  myRandomHotspotsWidget = new CheckboxWidget(pane, font,
                                              "Random hotspot peek values");
  wid.push_back(myRandomHotspotsWidget);

  // How to handle undriven TIA pins
  myUndrivenPinsWidget = new CheckboxWidget(pane, font,
                                            "Drive unused TIA pins randomly on a read/peek");
  myUndrivenPinsWidget->setToolTip("Read TIA pins random instead of last databus values.\n"
                                   "Helps detecting missing '#' for immediate loads.");
  wid.push_back(myUndrivenPinsWidget);

#ifdef DEBUGGER_SUPPORT
  myPortBreakLbl = new LabelWidget(pane, font, "Break on:");
  myRWPortBreakWidget = new CheckboxWidget(pane, font, "Reads from write ports");
  myRWPortBreakWidget->setToolTip("Cause reads from write ports to interrupt\n"
                                  "emulation and enter debugger.");
  wid.push_back(myRWPortBreakWidget);

  myWRPortBreakWidget = new CheckboxWidget(pane, font, "Writes to read ports");
  myWRPortBreakWidget->setToolTip("Cause writes to read ports to interrupt\n"
                                  "emulation and enter debugger.");
  wid.push_back(myWRPortBreakWidget);
#endif
  // Thumb ARM/ELF emulation exception
  myThumbExceptionWidget = new CheckboxWidget(pane, font, "Strict ARM emulation (*)");
  myThumbExceptionWidget->setToolTip("Strict checking for exceptions and suspicious program\n"
                                     "behaviour in ARM emulation.\n"
                                     "Interrupts emulation and enters debugger in such cases.");
  wid.push_back(myThumbExceptionWidget);

  myArmSpeedWidgetLbl = new LabelWidget(pane, font, "Limit ARM speed (*)");
  myArmSpeedWidget = new SliderWidget(pane, font, 10, Cmd::ArmSpeedChanged, 9, " MIPS");
  myArmSpeedWidget->setMinValue(CartridgeELF::MIPS_MIN);
  myArmSpeedWidget->setMaxValue(CartridgeELF::MIPS_MAX);
  myArmSpeedWidget->setStepValue(2);
  myArmSpeedWidget->setTickmarkIntervals((CartridgeELF::MIPS_MAX - CartridgeELF::MIPS_MIN) / 50);
  myArmSpeedWidget->setToolTip("Limit emulation speed to simulate ARM CPU used for ELF.");
  wid.push_back(myArmSpeedWidget);

  myEmuInfo = new LabelWidget(pane, infofont,
                                   "(*) Change requires a reload for ELF ROMs");

  // Add items for tab 0
  addToFocusList(wid, myTab, tabID);

  pane->setHelpAnchor("DeveloperEmulator");

  // Describe the layout once; the pane runs it on every resize.  Three of the
  // options have a second option beside them, and those three share a column —
  // which is what a grid is for: the column is as wide as the widest option in
  // it, and the rows that have no second option simply span across it
  pane->setLayout([this](GUI::BoxLayout& col) {
    using GUI::BoxLayout;
    using GUI::GridLayout;
    using GUI::anchoredItem;
    using GUI::labeledRow;
    using GUI::indentedItem;
    using Dir = BoxLayout::Dir;

    const int fontWidth = Dialog::fontWidth(),
              VGAP      = Dialog::vGap(),
              INDENT    = Dialog::indent();

    // These two controls are nine rows apart, so a shared label column would
    // buy no alignment and cost the shorter label a wide gap between it and
    // its value box.  Each gets a group of its own, purely for the clearance
    // a group supplies
    GUI::alignLabels({{myConsoleWidgetLbl, INDENT}});
    GUI::alignLabels({{myArmSpeedWidgetLbl, INDENT}});

    enum Col: uInt8 { MAIN, EXTRA, COLS };
    enum Row: uInt8 {
      PLR, DEV, STATS, ACCESS, CONSOLE, LOADING, BANK, RAM, CPU, HOTSPOTS, PINS,
#ifdef DEBUGGER_SUPPORT
      PORTS,
#endif
      THUMB, ARM, ROWS
    };
    auto grid = std::make_unique<GridLayout>(COLS, ROWS, fontWidth * 3, VGAP);
    grid->columnAuto(MAIN).columnStretch(EXTRA);
    for(int r = 0; r < ROWS; ++r)
      grid->rowAuto(r);

    // An option with no second option beside it takes the whole row
    const auto option = [&](int row, Widget* w, int indent) {
      grid->place(MAIN, row, indentedItem(w, indent), COLS - MAIN);
    };

    grid->place(MAIN, PLR, anchoredItem(myEmuSettings[0]), COLS - MAIN);
    grid->place(MAIN, DEV, anchoredItem(myEmuSettings[1]), COLS - MAIN);

    grid->place(MAIN,  STATS, indentedItem(myFrameStatsWidget, INDENT));
    grid->place(EXTRA, STATS, anchoredItem(myDetectedInfoWidget));
    option(ACCESS, myExternAccessWidget, INDENT);
    auto consoleRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    consoleRow->addSpace(INDENT);
    consoleRow->addStretch(labeledRow(myConsoleWidgetLbl, myConsoleWidget));
    grid->place(MAIN,  CONSOLE, std::move(consoleRow));
    grid->place(EXTRA, CONSOLE, anchoredItem(myPlusRomWidget));

    option(LOADING, myLoadingROMLbl, INDENT);
    grid->place(MAIN,  BANK, indentedItem(myRandomBankWidget, INDENT * 2));
    grid->place(EXTRA, BANK, anchoredItem(myRandomizeTIAWidget));
    option(RAM, myRandomizeRAMWidget, INDENT * 2);

    // The five CPU registers are evenly spaced: each as wide as the widest of
    // them (none of them can know that alone), with a uniform gap between
    GUI::alignButtons({myRandomizeCPUWidget[0], myRandomizeCPUWidget[1],
                       myRandomizeCPUWidget[2], myRandomizeCPUWidget[3],
                       myRandomizeCPUWidget[4]});

    auto regs = std::make_unique<BoxLayout>(Dir::Horizontal, fontWidth * 2);
    for(auto* reg: myRandomizeCPUWidget)
      regs->addAuto(anchoredItem(reg));

    auto cpuRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    cpuRow->addAuto(indentedItem(myRandomizeCPULbl, INDENT * 2));
    cpuRow->addSpace(fontWidth * 1.25);
    cpuRow->addAuto(std::move(regs));
    cpuRow->addStretchSpace();
    grid->place(MAIN, CPU, std::move(cpuRow), COLS - MAIN);

    option(HOTSPOTS, myRandomHotspotsWidget, INDENT);
    option(PINS, myUndrivenPinsWidget, INDENT);
#ifdef DEBUGGER_SUPPORT
    auto portRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    portRow->addAuto(indentedItem(myPortBreakLbl, INDENT));
    portRow->addSpace(fontWidth);
    portRow->addAuto(anchoredItem(myRWPortBreakWidget));
    portRow->addSpace(fontWidth * 2);
    portRow->addAuto(anchoredItem(myWRPortBreakWidget));
    portRow->addStretchSpace();
    grid->place(MAIN, PORTS, std::move(portRow), COLS - MAIN);
#endif
    option(THUMB, myThumbExceptionWidget, INDENT);
    auto armRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    armRow->addSpace(INDENT);
    armRow->addStretch(labeledRow(myArmSpeedWidgetLbl, myArmSpeedWidget));
    grid->place(MAIN, ARM, std::move(armRow), COLS - MAIN);

    col.addAuto(std::move(grid));
    // Usage note along the bottom of the tab
    col.addStretchSpace();
    col.addAuto(anchoredItem(myEmuInfo));
  });
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::addTiaTab(const GUI::Font& font)
{
  WidgetArray wid;
  VariantList items;

  const int tabID = myTab->addTab("  TIA  ", TabWidget::AUTO_WIDTH);
  auto* pane = new TabPaneWidget(myTab, font);
  myTab->setPaneWidget(tabID, pane);

  // settings set
  mySettingsGroupTia = std::make_unique<RadioButtonGroup>();
  myTiaSettings[0] = new RadioButtonWidget(pane, font, "Player settings",
                                           mySettingsGroupTia.get(), Cmd::PlayerSettings);
  myTiaSettings[0]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myTiaSettings[0]);
  myTiaSettings[1] = new RadioButtonWidget(pane, font, "Developer settings",
                                           mySettingsGroupTia.get(), Cmd::DeveloperSettings);
  myTiaSettings[1]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myTiaSettings[1]);

  items.clear();
  VarList::push_back(items, "Standard", "standard");
  VarList::push_back(items, "Faulty Kool-Aid Man", "koolaidman");
  VarList::push_back(items, "Faulty Cosmic Ark stars", "cosmicark");
  VarList::push_back(items, "Glitched Pesco", "pesco");
  VarList::push_back(items, "Glitched Quick Step!", "quickstep");
  VarList::push_back(items, "Glitched Matchie line", "matchie");
  VarList::push_back(items, "Glitched Indy 500 menu", "indy500");
  VarList::push_back(items, "Glitched He-Man title", "heman");
  VarList::push_back(items, "Shifted flashcart menu", "flashmenu");
  VarList::push_back(items, "Glitched Light Sixer", "lightsixer");
  VarList::push_back(items, "Glitched Jr. missiles", "juniorbug");
  VarList::push_back(items, "Custom", "custom");
  myTIATypeWidgetLbl = new LabelWidget(pane, font, "Chip type");
  myTIATypeWidget = new PopUpWidget(pane, font, items, Cmd::TiaType);
  myTIATypeWidget->setToolTip("Select which TIA chip type to emulate.\n"
                              "Some types cause defined glitches.");
  wid.push_back(myTIATypeWidget);

  myInvPhaseLbl = new LabelWidget(pane, font, "Inverted HMOVE clock phase for");
  myInvPhaseLbl->setToolTip("Objects react different to too\n"
                            "early HM" + ELLIPSIS + " after HMOVE changes.");
  wid.push_back(myInvPhaseLbl);
  myPlInvPhaseWidget = new CheckboxWidget(pane, font, "Players");
  wid.push_back(myPlInvPhaseWidget);
  myMsInvPhaseWidget = new CheckboxWidget(pane, font, "Missiles");
  wid.push_back(myMsInvPhaseWidget);
  myBlInvPhaseWidget = new CheckboxWidget(pane, font, "Ball");
  wid.push_back(myBlInvPhaseWidget);

  myLateHMoveLbl = new LabelWidget(pane, font, "Short late HMOVE for");
  myLateHMoveLbl->setToolTip("Objects react different to late HMOVEs");
  wid.push_back(myLateHMoveLbl);
  myPlLateHMoveWidget = new CheckboxWidget(pane, font, "Players");
  wid.push_back(myPlLateHMoveWidget);
  myMsLateHMoveWidget = new CheckboxWidget(pane, font, "Missiles");
  wid.push_back(myMsLateHMoveWidget);
  myBlLateHMoveWidget = new CheckboxWidget(pane, font, "Ball");
  wid.push_back(myBlLateHMoveWidget);

  myLateRespxLbl = new LabelWidget(pane, font, "Late RESPx for");
  myLateRespxLbl->setToolTip("RESP/RESM/RESBL strobed during HBLANK at HMOVE start shifts object 1 pixel right");
  wid.push_back(myLateRespxLbl);
  myPlLateRespxWidget = new CheckboxWidget(pane, font, "Players");
  wid.push_back(myPlLateRespxWidget);
  myMsLateRespxWidget = new CheckboxWidget(pane, font, "Missiles");
  wid.push_back(myMsLateRespxWidget);
  myBlLateRespxWidget = new CheckboxWidget(pane, font, "Ball");
  wid.push_back(myBlLateRespxWidget);

  myPlayfieldLbl = new LabelWidget(pane, font, "Delayed playfield");
  myPlayfieldLbl->setToolTip("Playfield reacts one color clock slower to updates.");
  wid.push_back(myPlayfieldLbl);
  myPFBitsWidget = new CheckboxWidget(pane, font, "Bits");
  wid.push_back(myPFBitsWidget);
  myPFColorWidget = new CheckboxWidget(pane, font, "Color");
  wid.push_back(myPFColorWidget);
  myPFScoreWidget = new CheckboxWidget(pane, font, "Score color");
  myPFScoreWidget->setToolTip("In score mode, playfield color gets updated one pixel early.");
  wid.push_back(myPFScoreWidget);

  myBackgroundLbl = new LabelWidget(pane, font, "Delayed background");
  myBackgroundLbl->setToolTip("Background color reacts one color clock slower to updates.");
  wid.push_back(myBackgroundLbl);
  myBKColorWidget = new CheckboxWidget(pane, font, "Color");
  wid.push_back(myBKColorWidget);

  mySwapLbl = new LabelWidget(pane, font,
    std::format("Delayed VDEL{} swap for", ELLIPSIS));
  mySwapLbl->setToolTip("VDELed objects react one color clock slower to updates.");
  wid.push_back(mySwapLbl);
  myPlSwapWidget = new CheckboxWidget(pane, font, "Players");
  wid.push_back(myPlSwapWidget);
  myBlSwapWidget = new CheckboxWidget(pane, font, "Ball");
  wid.push_back(myBlSwapWidget);

  // Add items for tab 2
  addToFocusList(wid, myTab, tabID);

  pane->setHelpAnchor("DeveloperTIA");

  // Describe the layout once; the pane runs it on every resize
  pane->setLayout([this](GUI::BoxLayout& col) {
    using GUI::BoxLayout;
    using GUI::anchoredItem;
    using GUI::labeledRow;
    using GUI::indentedItem;
    using Dir = BoxLayout::Dir;

    const int fontWidth = Dialog::fontWidth(),
              VGAP      = Dialog::vGap(),
              INDENT    = Dialog::indent();
    const int gap = fontWidth * 2.5;

    // The chip-type pop-up's label gets a column of its own
    GUI::alignLabels({{myTIATypeWidgetLbl, INDENT}});

    // Each quirk is a heading with a row of the objects it applies to beneath it
    const auto objectRow = [&](CheckboxWidget* first, CheckboxWidget* second,
                               CheckboxWidget* third) {
      auto row = std::make_unique<BoxLayout>(Dir::Horizontal);
      row->addAuto(indentedItem(first, INDENT * 3));
      row->addSpace(gap);
      row->addAuto(anchoredItem(second));
      if(third != nullptr)
      {
        row->addSpace(gap);
        row->addAuto(anchoredItem(third));
      }
      row->addStretchSpace();
      return row;
    };
    const auto quirk = [&](LabelWidget* label, CheckboxWidget* first,
                           CheckboxWidget* second, CheckboxWidget* third) {
      col.addAuto(indentedItem(label, INDENT * 2));
      col.addSpace(VGAP);
      col.addAuto(objectRow(first, second, third));
      col.addSpace(VGAP);
    };

    col.addAuto(anchoredItem(myTiaSettings[0]));
    col.addSpace(VGAP);
    col.addAuto(anchoredItem(myTiaSettings[1]));
    col.addSpace(VGAP);
    auto tiaTypeRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    tiaTypeRow->addSpace(INDENT);
    tiaTypeRow->addStretch(labeledRow(myTIATypeWidgetLbl, myTIATypeWidget));
    col.addAuto(std::move(tiaTypeRow));
    col.addSpace(VGAP);

    quirk(myInvPhaseLbl, myPlInvPhaseWidget, myMsInvPhaseWidget, myBlInvPhaseWidget);
    quirk(myLateHMoveLbl, myPlLateHMoveWidget, myMsLateHMoveWidget, myBlLateHMoveWidget);
    quirk(myLateRespxLbl, myPlLateRespxWidget, myMsLateRespxWidget, myBlLateRespxWidget);
    quirk(myPlayfieldLbl, myPFBitsWidget, myPFColorWidget, myPFScoreWidget);
    col.addAuto(indentedItem(myBackgroundLbl, INDENT * 2));
    col.addSpace(VGAP);
    col.addAuto(indentedItem(myBKColorWidget, INDENT * 3));
    col.addSpace(VGAP);
    quirk(mySwapLbl, myPlSwapWidget, myBlSwapWidget, nullptr);
  });
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::addVideoTab(const GUI::Font& font)
{
  const int pwidth = Dialog::fontWidth() * 6;
  WidgetArray wid;
  VariantList items;

  const int tabID = myTab->addTab(" Video ", TabWidget::AUTO_WIDTH);
  auto* pane = new TabPaneWidget(myTab, font);
  myTab->setPaneWidget(tabID, pane);

  // settings set
  mySettingsGroupVideo = std::make_unique<RadioButtonGroup>();
  myVideoSettings[0] = new RadioButtonWidget(pane, font, "Player settings",
                                             mySettingsGroupVideo.get(), Cmd::PlayerSettings);
  myVideoSettings[0]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myVideoSettings[0]);
  myVideoSettings[1] = new RadioButtonWidget(pane, font, "Developer settings",
                                             mySettingsGroupVideo.get(), Cmd::DeveloperSettings);
  myVideoSettings[1]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myVideoSettings[1]);

  // TV jitter effect
  myTVJitterWidget = new CheckboxWidget(pane, font, "Jitter/roll effect", Cmd::TvJitter);
  myTVJitterWidget->setToolTip("Enable to emulate TV loss of sync.", Event::ToggleJitter);
  wid.push_back(myTVJitterWidget);

  myTVJitterSenseWidgetLbl = new LabelWidget(pane, font, "Sensitivity");
  myTVJitterSenseWidget = new SliderWidget(pane, font, 10, GuiCmd::None, 2);
  myTVJitterSenseWidget->setMinValue(JitterEmulation::MIN_SENSITIVITY);
  myTVJitterSenseWidget->setMaxValue(JitterEmulation::MAX_SENSITIVITY);
  myTVJitterSenseWidget->setTickmarkIntervals(3);
  myTVJitterSenseWidget->setToolTip("Define sensitivity to unstable frames.",
    Event::JitterSenseDecrease, Event::JitterSenseIncrease);
  wid.push_back(myTVJitterSenseWidget);

  myTVJitterRecWidgetLbl = new LabelWidget(pane, font, "Recovery");
  myTVJitterRecWidget = new SliderWidget(pane, font, 10, GuiCmd::None, 2);
  myTVJitterRecWidget->setMinValue(JitterEmulation::MIN_RECOVERY);
  myTVJitterRecWidget->setMaxValue(JitterEmulation::MAX_RECOVERY);
  myTVJitterRecWidget->setTickmarkIntervals(5);
  myTVJitterRecWidget->setToolTip("Define speed of sync recovery.",
    Event::JitterRecDecrease, Event::JitterRecIncrease);
  wid.push_back(myTVJitterRecWidget);

  myColorLossWidget = new CheckboxWidget(pane, font, "PAL color-loss");
  myColorLossWidget->setToolTip("PAL games with odd scanline count\n"
                                "will be displayed without color.", Event::ToggleColorLoss);
  wid.push_back(myColorLossWidget);

  // debug colors
  myDebugColorsWidget = new CheckboxWidget(pane, font, "Debug colors (*)");
  myDebugColorsWidget->setToolTip("Enable fixed debug colors", Event::ToggleFixedColors);
  wid.push_back(myDebugColorsWidget);

  items.clear();
  VarList::push_back(items, "Red", "r");
  VarList::push_back(items, "Orange", "o");
  VarList::push_back(items, "Yellow", "y");
  VarList::push_back(items, "Green", "g");
  VarList::push_back(items, "Purple", "p");
  VarList::push_back(items, "Blue", "b");

  static constexpr std::array<GuiCmd::Code, DEBUG_COLORS> dbg_cmds = {
    Cmd::Player0ColourChanged,  Cmd::Missile0ColourChanged,  Cmd::Player1ColourChanged,
    Cmd::Missile1ColourChanged,  Cmd::PlayfieldColourChanged,  Cmd::BallColourChanged
  };

  const auto createDebugColourWidgets = [&](int idx, string_view desc)
  {
    myDbgColourLbl[idx] = new LabelWidget(pane, font, desc);
    myDbgColour[idx] = new PopUpWidget(pane, font, pwidth, items, dbg_cmds[idx]);
    wid.push_back(myDbgColour[idx]);
    myDbgColourSwatch[idx] = new ColorWidget(pane, font);
  };

  createDebugColourWidgets(0, "Player 0");
  createDebugColourWidgets(1, "Missile 0");
  createDebugColourWidgets(2, "Player 1");
  createDebugColourWidgets(3, "Missile 1");
  createDebugColourWidgets(4, "Playfield");
  createDebugColourWidgets(5, "Ball");

  myVideoInfo = new LabelWidget(pane, instance().frameBuffer().infoFont(),
                                     "(*) Colors identical for player and developer settings");

  // Add items for tab 2
  addToFocusList(wid, myTab, tabID);

  pane->setHelpAnchor("DeveloperVideo");

  // Describe the layout once; the pane runs it on every resize
  pane->setLayout([this](GUI::BoxLayout& col) {
    using GUI::BoxLayout;
    using GUI::anchoredItem;
    using GUI::labeledRow;
    using GUI::indentedItem;
    using Dir = BoxLayout::Dir;

    const int fontWidth = Dialog::fontWidth(),
              VGAP      = Dialog::vGap(),
              INDENT    = Dialog::indent();
    const int prefix = CheckboxWidget::prefixSize(_font);

    // The two jitter sliders sit side by side, so a shared label column would
    // align nothing (their tracks start at different places regardless) and
    // would only pad the shorter label out to the longer one.  Each gets a
    // group of its own, purely for the clearance a group supplies
    GUI::alignLabels({{myTVJitterSenseWidgetLbl}});
    GUI::alignLabels({{myTVJitterRecWidgetLbl}});

    // The jitter sliders share a row, indented under the checkbox's text
    auto jitterRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    jitterRow->addAuto(labeledRow(myTVJitterSenseWidgetLbl, myTVJitterSenseWidget,
                                  0, INDENT + prefix));
    jitterRow->addSpace(fontWidth * 2);
    jitterRow->addAuto(labeledRow(myTVJitterRecWidgetLbl, myTVJitterRecWidget));
    jitterRow->addStretchSpace();

    col.addAuto(anchoredItem(myVideoSettings[0]));
    col.addSpace(VGAP);
    col.addAuto(anchoredItem(myVideoSettings[1]));
    col.addSpace(VGAP);
    col.addAuto(indentedItem(myTVJitterWidget, INDENT));
    col.addSpace(VGAP);
    col.addAuto(std::move(jitterRow));
    col.addSpace(VGAP * 2);
    col.addAuto(indentedItem(myColorLossWidget, INDENT));
    col.addSpace(VGAP);
    col.addAuto(indentedItem(myDebugColorsWidget, INDENT));
    col.addSpace(VGAP + 2);

    // Each debug colour is a pop-up with its colour swatch beside it.  Their
    // labels share one column, keeping their value boxes in line
    GUI::alignLabels({{myDbgColourLbl[0]}, {myDbgColourLbl[1]}, {myDbgColourLbl[2]},
                      {myDbgColourLbl[3]}, {myDbgColourLbl[4]}, {myDbgColourLbl[5]}});

    for(int i = 0; i < DEBUG_COLORS; ++i)
    {
      // The pop-up width is the dialog's choice, not the pop-up's own, so it is
      // re-applied here and follows a live font change (PopUpWidget does not
      // re-derive its width -- see its refreshFont)
      myDbgColour[i]->setBoxWidth(fontWidth * 6);

      auto colourRow = std::make_unique<BoxLayout>(Dir::Horizontal);
      colourRow->addSpace(INDENT);
      colourRow->addAuto(labeledRow(myDbgColourLbl[i], myDbgColour[i]));
      colourRow->addSpace(fontWidth * 1.25);
      colourRow->addAuto(anchoredItem(myDbgColourSwatch[i]));
      colourRow->addStretchSpace();
      col.addAuto(std::move(colourRow));
      if(i < DEBUG_COLORS - 1)
        col.addSpace(VGAP);
    }

    // Usage note along the bottom of the tab
    col.addStretchSpace();
    col.addAuto(anchoredItem(myVideoInfo));
  });
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::addTimeMachineTab(const GUI::Font& font)
{
  static constexpr std::array<string_view, RewindManager::NUM_INTERVALS> INTERVALS = {
    " 1 frame",
    " 3 frames",
    "10 frames",
    "30 frames",
    " 1 second",
    " 3 seconds",
    "10 seconds"
  };
  static constexpr std::array<string_view, RewindManager::NUM_HORIZONS> HORIZONS = {
    "~  3 seconds",
    "~ 10 seconds",
    "~ 30 seconds",
    "~  1 minute",
    "~  3 minutes",
    "~ 10 minutes",
    "~ 30 minutes",
    "~ 60 minutes"
  };
  const int lwidth = 11;
  WidgetArray wid;
  VariantList items;

  const int tabID = myTab->addTab(" Time Machine ", TabWidget::AUTO_WIDTH);
  auto* pane = new TabPaneWidget(myTab, font);
  myTab->setPaneWidget(tabID, pane);

  // settings set
  mySettingsGroupTM = std::make_unique<RadioButtonGroup>();
  myTMSettings[0] = new RadioButtonWidget(pane, font, "Player settings",
                                          mySettingsGroupTM.get(), Cmd::PlayerSettings);
  myTMSettings[0]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myTMSettings[0]);
  myTMSettings[1] = new RadioButtonWidget(pane, font, "Developer settings",
                                          mySettingsGroupTM.get(), Cmd::DeveloperSettings);
  myTMSettings[1]->setToolTip(Event::ToggleDeveloperSet);
  wid.push_back(myTMSettings[1]);

  myTimeMachineWidget = new CheckboxWidget(pane, font, "Time Machine", Cmd::TimeMachine);
  myTimeMachineWidget->setToolTip(Event::ToggleTimeMachine);
  wid.push_back(myTimeMachineWidget);

  myStateSizeWidgetLbl = new LabelWidget(pane, font, "Buffer size (*)");
  myStateSizeWidget = new SliderWidget(pane, font, 0, Cmd::SizeChanged, lwidth, " states");
  myStateSizeWidget->setMinValue(RewindManager::MIN_BUF_SIZE);
  myStateSizeWidget->setMaxValue(RewindManager::MAX_BUF_SIZE);
  myStateSizeWidget->setStepValue(20);
  myStateSizeWidget->setTickmarkIntervals(5);
  myStateSizeWidget->setToolTip("Define the total Time Machine buffer size.");
  wid.push_back(myStateSizeWidget);

  myUncompressedWidgetLbl = new LabelWidget(pane, font, "Uncompressed size");
  myUncompressedWidget = new SliderWidget(pane, font, 0, Cmd::UncompressedChanged, lwidth, " states");
  myUncompressedWidget->setMinValue(0);
  myUncompressedWidget->setMaxValue(RewindManager::MAX_BUF_SIZE);
  myUncompressedWidget->setStepValue(20);
  myUncompressedWidget->setTickmarkIntervals(5);
  myUncompressedWidget->setToolTip("Define the number of completely kept states.\n"
                                   "States beyond this number will be slowly removed\n"
                                   "to fit the requested horizon into the buffer.");
  wid.push_back(myUncompressedWidget);

  items.clear();
  for(int i = 0; i < RewindManager::NUM_INTERVALS; ++i)
    VarList::push_back(items, INTERVALS[i], RewindManager::INT_SETTINGS[i]);
  myStateIntervalWidgetLbl = new LabelWidget(pane, font, "Interval");
  myStateIntervalWidget = new PopUpWidget(pane, font, items, Cmd::IntervalChanged);
  myStateIntervalWidget->setToolTip("Define the interval between each saved state.");
  wid.push_back(myStateIntervalWidget);

  items.clear();
  for(int i = 0; i < RewindManager::NUM_HORIZONS; ++i)
    VarList::push_back(items, HORIZONS[i], RewindManager::HOR_SETTINGS[i]);
  myStateHorizonWidgetLbl = new LabelWidget(pane, font, "Horizon");
  myStateHorizonWidget = new PopUpWidget(pane, font, items, Cmd::HorizonChanged);
  myStateHorizonWidget->setToolTip("Define how far the Time Machine\n"
                                   "will allow moving back in time.");
  wid.push_back(myStateHorizonWidget);

  myTMInfo = new LabelWidget(pane, instance().frameBuffer().infoFont(),
                                  "(*) Any size change clears the buffer");

  addToFocusList(wid, myTab, tabID);

  pane->setHelpAnchor("DeveloperTimeMachine");

  // Describe the layout once; the pane runs it on every resize
  pane->setLayout([this](GUI::BoxLayout& col) {
    using GUI::BoxLayout;
    using GUI::anchoredItem;
    using GUI::labeledRow;
    using GUI::indentedItem;
    using Dir = BoxLayout::Dir;

    const int VGAP   = Dialog::vGap(),
              INDENT = Dialog::indent();
    // The sliders and pop-ups line up under the Time Machine checkbox's text
    const int under = INDENT + CheckboxWidget::prefixSize(_font);

    // The sliders' labels and the pop-ups' separate labels share one column, so
    // every control starts at the same x...
    GUI::alignLabels({{myStateSizeWidgetLbl, under}, {myUncompressedWidgetLbl, under},
                      {myStateIntervalWidgetLbl, under}, {myStateHorizonWidgetLbl, under}});
    // ...the pop-ups size their boxes to their own lists and then take one
    // shared box width, so their right edges are flush...
    GUI::alignPopUps({myStateIntervalWidget, myStateHorizonWidget});
    // ...and the sliders' tracks span that same box, so they end flush with it
    GUI::alignTracks({myStateSizeWidget, myUncompressedWidget}, myStateIntervalWidget);

    col.addAuto(anchoredItem(myTMSettings[0]));
    col.addSpace(VGAP);
    col.addAuto(anchoredItem(myTMSettings[1]));
    col.addSpace(VGAP);
    col.addAuto(indentedItem(myTimeMachineWidget, INDENT));
    col.addSpace(VGAP);
    col.addAuto(labeledRow(myStateSizeWidgetLbl, myStateSizeWidget, 0, under));
    col.addSpace(VGAP);
    col.addAuto(labeledRow(myUncompressedWidgetLbl, myUncompressedWidget, 0, under));
    col.addSpace(VGAP);
    auto intervalRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    intervalRow->addSpace(under);
    intervalRow->addStretch(labeledRow(myStateIntervalWidgetLbl, myStateIntervalWidget));
    col.addAuto(std::move(intervalRow));
    col.addSpace(VGAP);
    auto horizonRow = std::make_unique<BoxLayout>(Dir::Horizontal);
    horizonRow->addSpace(under);
    horizonRow->addStretch(labeledRow(myStateHorizonWidgetLbl, myStateHorizonWidget));
    col.addAuto(std::move(horizonRow));

    // Usage note along the bottom of the tab
    col.addStretchSpace();
    col.addAuto(anchoredItem(myTMInfo));
  });
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::addDebuggerTab(const GUI::Font& font)
{
  const int tabID = myTab->addTab(" Debugger ", TabWidget::AUTO_WIDTH);
  auto* pane = new TabPaneWidget(myTab, font);
  myTab->setPaneWidget(tabID, pane);
  WidgetArray wid;

#ifdef DEBUGGER_SUPPORT
  VariantList items;

  // font size
  items.clear();
  for(const auto& entry: FontManager::debuggerFonts())
    VarList::push_back(items, entry.label, entry.name);
  myDebuggerFontSizeLbl = new LabelWidget(pane, font, "Font size");
  myDebuggerFontSize = new PopUpWidget(pane, font, items, Cmd::DebuggerFontSizeChanged);
  wid.push_back(myDebuggerFontSize);

  // Font style (bold label vs. text, etc)
  items.clear();
  VarList::push_back(items, "All normal font", "0");
  VarList::push_back(items, "Bold labels only", "1");
  VarList::push_back(items, "Bold non-labels only", "2");
  VarList::push_back(items, "All bold font", "3");
  myDebuggerFontStyleLbl = new LabelWidget(pane, font, "Font style");
  myDebuggerFontStyle = new PopUpWidget(pane, font, items);
  wid.push_back(myDebuggerFontStyle);

  myGhostReadsTrapWidget = new CheckboxWidget(pane, font, "Trap on 'ghost' reads");
  myGhostReadsTrapWidget->setToolTip("Traps will consider CPU 'ghost' reads too.");
  wid.push_back(myGhostReadsTrapWidget);

  myDebuggerInfo = new LabelWidget(pane, instance().frameBuffer().infoFont(),
                                        "(*) Change requires a ROM reload");

#else
  myDebuggerInfo = new LabelWidget(pane, font, "Debugger support not included",
                                   TextAlign::Center);
#endif

  addToFocusList(wid, myTab, tabID);

  pane->setHelpAnchor("DeveloperDebugger");

  // Describe the layout once; the pane runs it on every resize
  pane->setLayout([this](GUI::BoxLayout& col) {
    using GUI::anchoredItem;
    using GUI::labeledRow;
    using GUI::alignedItem;
    using GUI::HAlign;
    using GUI::VAlign;

#ifdef DEBUGGER_SUPPORT
    const int VGAP = Dialog::vGap();

    // The two pop-ups each have a separate label; both share one column, and
    // the pop-ups take one shared box width
    GUI::alignLabels({{myDebuggerFontSizeLbl}, {myDebuggerFontStyleLbl}});
    GUI::alignPopUps({myDebuggerFontSize, myDebuggerFontStyle});

    col.addAuto(labeledRow(myDebuggerFontSizeLbl, myDebuggerFontSize));
    col.addSpace(VGAP);
    col.addAuto(labeledRow(myDebuggerFontStyleLbl, myDebuggerFontStyle));
    col.addSpace(VGAP * 4);
    col.addAuto(anchoredItem(myGhostReadsTrapWidget));

    // Usage note along the bottom of the tab
    col.addStretchSpace();
    col.addAuto(anchoredItem(myDebuggerInfo));
#else
    // A single message, centered in the tab
    col.addStretchSpace();
    col.addAuto(alignedItem(myDebuggerInfo, HAlign::Fill, VAlign::Center));
    col.addStretchSpace();
#endif
  });
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::getWidgetStates(SettingsSet set)
{
  myFrameStats[set] = myFrameStatsWidget->getState();
  myDetectedInfo[set] = myDetectedInfoWidget->getState();
  // AtariVox/SaveKey/PlusROM access
  myExternAccess[set] = myExternAccessWidget->getState();
  myConsole[set] = myConsoleWidget->getSelected() == 1;
  myPlusROM[set] = myPlusRomWidget->getState() == 1;
  // Randomization
  myRandomBank[set] = myRandomBankWidget->getState();
  myRandomizeTIA[set] = myRandomizeTIAWidget->getState();
  myRandomizeRAM[set] = myRandomizeRAMWidget->getState();
  string cpurandom;

  for(int i = 0; i < 5; ++i)
    if(myRandomizeCPUWidget[i]->getState())
      cpurandom += ourCPURegs[i];
  myRandomizeCPU[set] = cpurandom;
  // Random hotspot peeks
  myRandomHotspots[set] = myRandomHotspotsWidget->getState();
  // Undriven TIA pins
  myUndrivenPins[set] = myUndrivenPinsWidget->getState();
#ifdef DEBUGGER_SUPPORT
  // Read from write ports break
  myRWPortBreak[set] = myRWPortBreakWidget->getState();
  myWRPortBreak[set] = myWRPortBreakWidget->getState();
#endif
  // Thumb ARM emulation exception
  myThumbException[set] = myThumbExceptionWidget->getState();
  myArmSpeed[set] = myArmSpeedWidget->getValue();

  // TIA tab
  myTIAType[set] = myTIATypeWidget->getSelectedTag().toString();
  myPlInvPhase[set] = myPlInvPhaseWidget->getState();
  myMsInvPhase[set] = myMsInvPhaseWidget->getState();
  myBlInvPhase[set] = myBlInvPhaseWidget->getState();
  myPlLateHMove[set] = myPlLateHMoveWidget->getState();
  myMsLateHMove[set] = myMsLateHMoveWidget->getState();
  myBlLateHMove[set] = myBlLateHMoveWidget->getState();
  myPlLateRespx[set] = myPlLateRespxWidget->getState();
  myMsLateRespx[set] = myMsLateRespxWidget->getState();
  myBlLateRespx[set] = myBlLateRespxWidget->getState();
  myPFBits[set] = myPFBitsWidget->getState();
  myPFColor[set] = myPFColorWidget->getState();
  myPFScore[set] = myPFScoreWidget->getState();
  myBKColor[set] = myBKColorWidget->getState();
  myPlSwap[set] = myPlSwapWidget->getState();
  myBlSwap[set] = myBlSwapWidget->getState();

  // Debug colors
  myDebugColors[set] = myDebugColorsWidget->getState();
  // PAL color-loss effect
  myColorLoss[set] = myColorLossWidget->getState();
  // Jitter
  myTVJitter[set] = myTVJitterWidget->getState();
  myTVJitterSense[set] = myTVJitterSenseWidget->getValue();
  myTVJitterRec[set] = myTVJitterRecWidget->getValue();

  // States
  myTimeMachine[set] = myTimeMachineWidget->getState();
  myStateSize[set] = myStateSizeWidget->getValue();
  myUncompressed[set] = myUncompressedWidget->getValue();
  myStateInterval[set] = myStateIntervalWidget->getSelectedTag().toString();
  myStateHorizon[set] = myStateHorizonWidget->getSelectedTag().toString();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::setWidgetStates(SettingsSet set)
{
  myFrameStatsWidget->setState(myFrameStats[set]);
  myDetectedInfoWidget->setState(myDetectedInfo[set]);
  // AtariVox/SaveKey/PlusROM access
  myExternAccessWidget->setState(myExternAccess[set]);
  myConsoleWidget->setSelectedIndex(myConsole[set]);
  myPlusRomWidget->setState(myPlusROM[set]);
  // Randomization
  myRandomBankWidget->setState(myRandomBank[set]);
  myRandomizeTIAWidget->setState(myRandomizeTIA[set]);
  myRandomizeRAMWidget->setState(myRandomizeRAM[set]);

  const string_view cpurandom = myRandomizeCPU[set];

  for(int i = 0; i < 5; ++i)
    myRandomizeCPUWidget[i]->setState(BSPF::containsIgnoreCase(cpurandom, ourCPURegs[i]));
  // Random hotspot peeks
  myRandomHotspotsWidget->setState(myRandomHotspots[set]);
  // Undriven TIA pins
  myUndrivenPinsWidget->setState(myUndrivenPins[set]);
#ifdef DEBUGGER_SUPPORT
  // Read from write ports break
  myRWPortBreakWidget->setState(myRWPortBreak[set]);
  myWRPortBreakWidget->setState(myWRPortBreak[set]);
#endif
  // Thumb ARM emulation exception
  myThumbExceptionWidget->setState(myThumbException[set]);
  myArmSpeedWidget->setValue(myArmSpeed[set]);
  handleConsole();

  // TIA tab
  myTIATypeWidget->setSelected(myTIAType[set], "standard");
  handleTia();

  // Debug colors
  myDebugColorsWidget->setState(myDebugColors[set]);
  // PAL color-loss effect
  myColorLossWidget->setState(myColorLoss[set]);
  // Jitter
  myTVJitterWidget->setState(myTVJitter[set]);
  myTVJitterSenseWidget->setValue(myTVJitterSense[set]);
  myTVJitterRecWidget->setValue(myTVJitterRec[set]);

  handleTVJitterChange();

  // States
  myTimeMachineWidget->setState(myTimeMachine[set]);
  myStateSizeWidget->setValue(myStateSize[set]);
  myUncompressedWidget->setValue(myUncompressed[set]);
  myStateIntervalWidget->setSelected(myStateInterval[set]);
  myStateHorizonWidget->setSelected(myStateHorizon[set]);

  handleTimeMachine();
  handleSize();
  handleUncompressed();
  handleInterval();
  handleHorizon();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::loadConfig()
{
  const bool devSettings = instance().settings().getBool("dev.settings");
  handleSettings(devSettings);
  mySettings = devSettings;
  mySettingsGroupEmulation->setSelected(devSettings ? 1 : 0);
  mySettingsGroupTia->setSelected(devSettings ? 1 : 0);
  mySettingsGroupVideo->setSelected(devSettings ? 1 : 0);
  mySettingsGroupTM->setSelected(devSettings ? 1 : 0);

  // load both setting sets...
  loadSettings(SettingsSet::player);
  loadSettings(SettingsSet::developer);
  // ...and select the current one
  setWidgetStates(static_cast<SettingsSet>(mySettingsGroupEmulation->getSelected()));

  // Debug colours
  handleDebugColours(instance().settings().getString("tia.dbgcolors"));

#ifdef DEBUGGER_SUPPORT
  // Debugger font size
  // One pop-up drives both debugger roles; the two settings can still be
  // given different fonts by hand, and the text font is what shows here
  const string size = instance().settings().getString(
      FontManager::settingKey(FontManager::FontRole::DebuggerText));
  myDebuggerFontSize->setSelected(size, "low_medium");

  // Debugger font style
  const int style = instance().settings().getInt("dbg.fontstyle");
  myDebuggerFontStyle->setSelected(style, "0");

  // Ghost reads trap
  myGhostReadsTrapWidget->setState(instance().settings().getBool("dbg.ghostreadstrap"));
#endif

  myTab->loadConfig();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::saveConfig()
{
  const bool devSettings = mySettingsGroupEmulation->getSelected() == SettingsSet::developer;

  instance().settings().setValue("dev.settings", devSettings);
  // copy current widget status into set...
  getWidgetStates(static_cast<SettingsSet>(mySettingsGroupEmulation->getSelected()));
  // ...and save both sets
  saveSettings(SettingsSet::player);
  saveSettings(SettingsSet::developer);
  // activate the current settings
  applySettings(devSettings ? SettingsSet::developer : SettingsSet::player);

  // Debug colours
  string dbgcolors;
  for(int i = 0; i < DEBUG_COLORS; ++i)
    dbgcolors += myDbgColour[i]->getSelectedTag().toString();
  if(instance().hasConsole() &&
     instance().console().tia().setFixedColorPalette(dbgcolors))
    instance().settings().setValue("tia.dbgcolors", dbgcolors);

#ifdef DEBUGGER_SUPPORT
  // Debugger font style
  instance().settings().setValue("dbg.fontstyle",
                                 myDebuggerFontStyle->getSelectedTag().toString());
  // Debugger font size
  const string dbgFont = myDebuggerFontSize->getSelectedTag().toString();
  instance().settings().setValue(
      FontManager::settingKey(FontManager::FontRole::DebuggerLabel), dbgFont);
  instance().settings().setValue(
      FontManager::settingKey(FontManager::FontRole::DebuggerText), dbgFont);

  // Ghost reads trap
  instance().settings().setValue("dbg.ghostreadstrap", myGhostReadsTrapWidget->getState());
  if(instance().hasConsole())
    instance().console().system().m6502().setGhostReadsTrap(myGhostReadsTrapWidget->getState());
#endif
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::setDefaults()
{
  const bool devSettings = mySettings;
  const auto set = static_cast<SettingsSet>
      (mySettingsGroupEmulation->getSelected());

  switch(myTab->getActiveTab())
  {
    case 0: // Emulation
      myFrameStats[set] = devSettings;
      myDetectedInfo[set] = devSettings;
      // AtariVox/SaveKey/PlusROM access
      myExternAccess[set] = devSettings;
      myConsole[set] = false;
      myPlusROM[set] = true;
      // Randomization
      myRandomBank[set] = devSettings;
      myRandomizeTIA[set] = devSettings;
      myRandomizeRAM[set] = true;
      myRandomizeCPU[set] = devSettings ? "SAXYP" : "AXYP";
      // Random hotspot peeks
      myRandomHotspots[set] = devSettings;
      // Undriven TIA pins
      myUndrivenPins[set] = devSettings;
    #ifdef DEBUGGER_SUPPORT
      // Reads from write ports
      myRWPortBreak[set] = devSettings;
      myWRPortBreak[set] = devSettings;
    #endif
      // Thumb ARM emulation exception
      myThumbException[set] = devSettings;
      myArmSpeed[set] = devSettings ? CartridgeELF::MIPS_DEF : CartridgeELF::MIPS_MAX;

      setWidgetStates(set);
      break;

    case 1: // TIA
      myTIAType[set] = "standard";
      // reset "custom" mode
      myPlInvPhase[set] = devSettings;
      myMsInvPhase[set] = devSettings;
      myBlInvPhase[set] = devSettings;
      myPFBits[set] = devSettings;
      myPFColor[set] = devSettings;
      myPFScore[set] = devSettings;
      myBKColor[set] = devSettings;
      myPlSwap[set] = devSettings;
      myBlSwap[set] = devSettings;

      setWidgetStates(set);
      break;

    case 2: // Video
      // Jitter
      myTVJitter[set] = true;
      myTVJitterSense[set] = devSettings
        ? JitterEmulation::DEV_SENSITIVITY
        : JitterEmulation::PLR_SENSITIVITY;
      myTVJitterRec[set] = devSettings ? 2 : 10;
      // PAL color-loss effect
      myColorLoss[set] = devSettings;
      // Debug colors
      myDebugColors[set] = false;
      handleDebugColours("roygpb");

      setWidgetStates(set);
      break;

    case 3: // States
      myTimeMachine[set] = true;
      myStateSize[set] = devSettings ? 1000 : 200;
      myUncompressed[set] = devSettings ? 600 : 60;
      myStateInterval[set] = devSettings ? "1f" : "30f";
      myStateHorizon[set] = devSettings ? "30s" : "10m";

      setWidgetStates(set);
      break;

    case 4: // Debugger options
    {
#ifdef DEBUGGER_SUPPORT
      myDebuggerFontSize->setSelected("low_medium");
      myDebuggerFontStyle->setSelected("0");

      myGhostReadsTrapWidget->setState(true);
#endif
      break;
    }

    default:
      break;
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleCommand(CommandSender* sender, GuiCmd::Code cmd,
                                    int data, int id)
{
  switch(cmd)
  {
    case Cmd::PlayerSettings:
      handleSettings(false);
      break;

    case Cmd::DeveloperSettings:
      handleSettings(true);
      break;

    case Cmd::TiaType:
      handleTia();
      break;

    case Cmd::Console:
      handleConsole();
      break;

    case Cmd::TvJitter:
      handleTVJitterChange();
      break;

    case Cmd::TimeMachine:
      handleTimeMachine();
      break;

    case Cmd::SizeChanged:
      handleSize();
      break;

    case Cmd::UncompressedChanged:
      handleUncompressed();
      break;

    case Cmd::IntervalChanged:
      handleInterval();
      break;

    case Cmd::HorizonChanged:
      handleHorizon();
      break;

    case Cmd::Player0ColourChanged:
      handleDebugColours(0, myDbgColour[0]->getSelected());
      break;

    case Cmd::Missile0ColourChanged:
      handleDebugColours(1, myDbgColour[1]->getSelected());
      break;

    case Cmd::Player1ColourChanged:
      handleDebugColours(2, myDbgColour[2]->getSelected());
      break;

    case Cmd::Missile1ColourChanged:
      handleDebugColours(3, myDbgColour[3]->getSelected());
      break;

    case Cmd::PlayfieldColourChanged:
      handleDebugColours(4, myDbgColour[4]->getSelected());
      break;

    case Cmd::BallColourChanged:
      handleDebugColours(5, myDbgColour[5]->getSelected());
      break;

#ifdef DEBUGGER_SUPPORT
    case Cmd::DebuggerFontSizeChanged:
      break;
#endif

    case GuiObject::Cmd::OK:
    {
  #ifdef DEBUGGER_SUPPORT
      const bool informDebuggerFont = instance().hasConsole() &&
        (myDebuggerFontSize->getSelectedTag().toString() !=
             instance().settings().getString(
                 FontManager::settingKey(FontManager::FontRole::DebuggerText))
         || myDebuggerFontStyle->getSelectedTag().toString() !=
             instance().settings().getString("dbg.fontstyle"));
  #endif
      saveConfig();
      close();
  #ifdef DEBUGGER_SUPPORT
      if(informDebuggerFont)
        instance().debugger().changeFont();
  #endif
      break;
    }

    case GuiObject::Cmd::Close:
      // Revert changes made to event mapping
      close();
      break;

    case GuiObject::Cmd::Defaults:
      setDefaults();
      break;

    default:
      Dialog::handleCommand(sender, cmd, data, 0);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleSettings(bool devSettings)
{
  myPlusRomWidget->setEnabled(devSettings);
  myRandomHotspotsWidget->setEnabled(devSettings);
  myUndrivenPinsWidget->setEnabled(devSettings);
#ifdef DEBUGGER_SUPPORT
  myPortBreakLbl->setEnabled(devSettings);
  myRWPortBreakWidget->setEnabled(devSettings);
  myWRPortBreakWidget->setEnabled(devSettings);
#endif
  myThumbExceptionWidget->setEnabled(devSettings);
  myArmSpeedWidgetLbl->setEnabled(devSettings);
  myArmSpeedWidget->setEnabled(devSettings);

  if (mySettings != devSettings)
  {
    mySettings = devSettings; // block redundant events first!
    const SettingsSet set = devSettings ? SettingsSet::developer
                                        : SettingsSet::player;
    mySettingsGroupEmulation->setSelected(set);
    mySettingsGroupTia->setSelected(set);
    mySettingsGroupVideo->setSelected(set);
    mySettingsGroupTM->setSelected(set);
    // Save current widget states into old set
    getWidgetStates(devSettings ? SettingsSet::player
                                : SettingsSet::developer);
    // Load new set into widgets states
    setWidgetStates(set);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleTVJitterChange()
{
  const bool enable = myTVJitterWidget->getState();

  myTVJitterSenseWidgetLbl->setEnabled(enable);
  myTVJitterSenseWidget->setEnabled(enable);
  myTVJitterRecWidgetLbl->setEnabled(enable);
  myTVJitterRecWidget->setEnabled(enable);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleConsole()
{
  const bool is7800 = myConsoleWidget->getSelected() == 1;

  myRandomizeRAMWidget->setEnabled(!is7800);
  if(is7800)
    myRandomizeRAMWidget->setState(false);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleTia()
{
  const string tiaType = myTIATypeWidget->getSelectedTag().toString();
  const bool enable = BSPF::equalsIgnoreCase("custom", tiaType);

  myTIATypeWidgetLbl->setEnabled(mySettings);
  myTIATypeWidget->setEnabled(mySettings);
  myInvPhaseLbl->setEnabled(enable);
  myPlInvPhaseWidget->setEnabled(enable);
  myMsInvPhaseWidget->setEnabled(enable);
  myBlInvPhaseWidget->setEnabled(enable);
  myLateHMoveLbl->setEnabled(enable);
  myPlLateHMoveWidget->setEnabled(enable);
  myMsLateHMoveWidget->setEnabled(enable);
  myBlLateHMoveWidget->setEnabled(enable);
  myLateRespxLbl->setEnabled(enable);
  myPlLateRespxWidget->setEnabled(enable);
  myMsLateRespxWidget->setEnabled(enable);
  myBlLateRespxWidget->setEnabled(enable);
  myPlayfieldLbl->setEnabled(enable);
  myBackgroundLbl->setEnabled(enable);
  myPFBitsWidget->setEnabled(enable);
  myPFColorWidget->setEnabled(enable);
  myPFScoreWidget->setEnabled(enable);
  myBKColorWidget->setEnabled(enable);
  mySwapLbl->setEnabled(enable);
  myPlSwapWidget->setEnabled(enable);
  myBlSwapWidget->setEnabled(enable);

  if(BSPF::equalsIgnoreCase("custom", tiaType))
  {
    const SettingsSet set = SettingsSet::developer;

    myPlInvPhaseWidget->setState(myPlInvPhase[set]);
    myMsInvPhaseWidget->setState(myMsInvPhase[set]);
    myBlInvPhaseWidget->setState(myBlInvPhase[set]);
    myPlLateHMoveWidget->setState(myPlLateHMove[set]);
    myMsLateHMoveWidget->setState(myMsLateHMove[set]);
    myBlLateHMoveWidget->setState(myBlLateHMove[set]);
    myPlLateRespxWidget->setState(myPlLateRespx[set]);
    myMsLateRespxWidget->setState(myMsLateRespx[set]);
    myBlLateRespxWidget->setState(myBlLateRespx[set]);
    myPFBitsWidget->setState(myPFBits[set]);
    myPFColorWidget->setState(myPFColor[set]);
    myPFScoreWidget->setState(myPFScore[set]);
    myBKColorWidget->setState(myBKColor[set]);
    myPlSwapWidget->setState(myPlSwap[set]);
    myBlSwapWidget->setState(myBlSwap[set]);
  }
  else
  {
    myPlInvPhaseWidget->setState(BSPF::equalsIgnoreCase("koolaidman", tiaType));
    myMsInvPhaseWidget->setState(BSPF::equalsIgnoreCase("cosmicark", tiaType));
    myBlInvPhaseWidget->setState(false);
    myPlLateHMoveWidget->setState(BSPF::equalsIgnoreCase("flashmenu", tiaType));
    myMsLateHMoveWidget->setState(false);
    myBlLateHMoveWidget->setState(false);
    myPlLateRespxWidget->setState(BSPF::equalsIgnoreCase("lightsixer", tiaType));
    myMsLateRespxWidget->setState(BSPF::equalsIgnoreCase("lightsixer", tiaType) ||
                                  BSPF::equalsIgnoreCase("juniorbug", tiaType));
    myBlLateRespxWidget->setState(BSPF::equalsIgnoreCase("lightsixer", tiaType));
    myPFBitsWidget->setState(BSPF::equalsIgnoreCase("pesco", tiaType));
    myPFColorWidget->setState(BSPF::equalsIgnoreCase("quickstep", tiaType));
    myPFScoreWidget->setState(BSPF::equalsIgnoreCase("matchie", tiaType));
    myBKColorWidget->setState(BSPF::equalsIgnoreCase("indy500", tiaType));
    myPlSwapWidget->setState(BSPF::equalsIgnoreCase("heman", tiaType));
    myBlSwapWidget->setState(false);
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleTimeMachine()
{
  const bool enable = myTimeMachineWidget->getState();

  myStateSizeWidgetLbl->setEnabled(enable);
  myStateSizeWidget->setEnabled(enable);
  myUncompressedWidgetLbl->setEnabled(enable);
  myUncompressedWidget->setEnabled(enable);
  myStateIntervalWidgetLbl->setEnabled(enable);
  myStateIntervalWidget->setEnabled(enable);

  const uInt32 size = myStateSizeWidget->getValue();
  const uInt32 uncompressed = myUncompressedWidget->getValue();

  myStateHorizonWidgetLbl->setEnabled(enable && size > uncompressed);
  myStateHorizonWidget->setEnabled(enable && size > uncompressed);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleSize()
{
  const uInt32 size = myStateSizeWidget->getValue();
  const uInt32 uncompressed = myUncompressedWidget->getValue();
  Int32 interval = myStateIntervalWidget->getSelected();
  Int32 horizon = myStateHorizonWidget->getSelected();
  bool found = false;
  Int32 i = 0;

  // handle illegal values
  if(interval == -1)
    interval = 0;
  if(horizon == -1)
    horizon = 0;

  // adapt horizon and interval
  do
  {
    for(i = horizon; i < RewindManager::NUM_HORIZONS; ++i)
    {
      if(static_cast<uInt64>(size) * RewindManager::INTERVAL_CYCLES[interval]
         <= RewindManager::HORIZON_CYCLES[i])
      {
        found = true;
        break;
      }
    }
    if(!found)
      --interval;
  } while(!found);

  if(size < uncompressed)
    myUncompressedWidget->setValue(size);
  myStateIntervalWidget->setSelectedIndex(interval);
  myStateHorizonWidget->setSelectedIndex(i);
  myStateHorizonWidgetLbl->setEnabled(myTimeMachineWidget->getState() && size > uncompressed);
  myStateHorizonWidget->setEnabled(myTimeMachineWidget->getState() && size > uncompressed);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleUncompressed()
{
  const uInt32 size = myStateSizeWidget->getValue();
  const uInt32 uncompressed = myUncompressedWidget->getValue();

  if(size < uncompressed)
    myStateSizeWidget->setValue(uncompressed);
  myStateHorizonWidgetLbl->setEnabled(myTimeMachineWidget->getState() && size > uncompressed);
  myStateHorizonWidget->setEnabled(myTimeMachineWidget->getState() && size > uncompressed);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleInterval()
{
  uInt32 size = myStateSizeWidget->getValue();
  const uInt32 uncompressed = myUncompressedWidget->getValue();
  Int32 interval = myStateIntervalWidget->getSelected();
  Int32 horizon = myStateHorizonWidget->getSelected();
  bool found = false;
  Int32 i = 0;

  // handle illegal values
  if(interval == -1)
    interval = 0;
  if(horizon == -1)
    horizon = 0;

  // adapt horizon and size
  do
  {
    for(i = horizon; i < RewindManager::NUM_HORIZONS; ++i)
    {
      if(static_cast<uInt64>(size) * RewindManager::INTERVAL_CYCLES[interval]
         <= RewindManager::HORIZON_CYCLES[i])
      {
        found = true;
        break;
      }
    }
    if(!found)
      size -= myStateSizeWidget->getStepValue();
  } while(!found);

  myStateHorizonWidget->setSelectedIndex(i);
  myStateSizeWidget->setValue(size);
  if(size < uncompressed)
    myUncompressedWidget->setValue(size);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleHorizon()
{
  uInt32 size = myStateSizeWidget->getValue();
  const uInt32 uncompressed = myUncompressedWidget->getValue();
  Int32 interval = myStateIntervalWidget->getSelected();
  Int32 horizon = myStateHorizonWidget->getSelected();
  bool found = false;
  Int32 i = 0;

  // handle illegal values
  if(interval == -1)
    interval = 0;
  if(horizon == -1)
    horizon = 0;

  // adapt interval and size
  do
  {
    for(i = interval; i >= 0; --i)
    {
      if(static_cast<uInt64>(size) * RewindManager::INTERVAL_CYCLES[i]
         <= RewindManager::HORIZON_CYCLES[horizon])
      {
        found = true;
        break;
      }
    }
    if(!found)
      size -= myStateSizeWidget->getStepValue();
  } while(!found);

  myStateIntervalWidget->setSelectedIndex(i);
  myStateSizeWidget->setValue(size);
  if(size < uncompressed)
    myUncompressedWidget->setValue(size);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleDebugColours(int idx, int color)
{
  if(idx < 0 || idx >= DEBUG_COLORS)
    return;

  if(!instance().hasConsole())
  {
    myDbgColourLbl[idx]->clearFlags(Widget::Flag::Enabled);
    myDbgColour[idx]->clearFlags(Widget::Flag::Enabled);
    myDbgColourSwatch[idx]->clearFlags(Widget::Flag::Enabled);
    return;
  }

  static constexpr BSPF::array2D<ColorId, 3, DEBUG_COLORS> dbg_color = {{
    {
      TIA::FixedColor::NTSC_RED,
      TIA::FixedColor::NTSC_ORANGE,
      TIA::FixedColor::NTSC_YELLOW,
      TIA::FixedColor::NTSC_GREEN,
      TIA::FixedColor::NTSC_PURPLE,
      TIA::FixedColor::NTSC_BLUE
    },
    {
      TIA::FixedColor::PAL_RED,
      TIA::FixedColor::PAL_ORANGE,
      TIA::FixedColor::PAL_YELLOW,
      TIA::FixedColor::PAL_GREEN,
      TIA::FixedColor::PAL_PURPLE,
      TIA::FixedColor::PAL_BLUE
    },
    {
      TIA::FixedColor::SECAM_RED,
      TIA::FixedColor::SECAM_ORANGE,
      TIA::FixedColor::SECAM_YELLOW,
      TIA::FixedColor::SECAM_GREEN,
      TIA::FixedColor::SECAM_PURPLE,
      TIA::FixedColor::SECAM_BLUE
    }
  }};

  const int timing = instance().console().timing() == ConsoleTiming::ntsc ? 0
    : instance().console().timing() == ConsoleTiming::pal ? 1 : 2;

  myDbgColourSwatch[idx]->setColor(dbg_color[timing][color]);
  myDbgColour[idx]->setSelectedIndex(color);

  // make sure the selected debug colors are all different
  std::array<bool, DEBUG_COLORS> usedCol = {false};

  // identify used colors
  for(int i = 0; i < DEBUG_COLORS; ++i)
  {
    usedCol[i] = false;
    for(int j = 0; j < DEBUG_COLORS; ++j)
    {
      if(myDbgColourSwatch[j]->getColor() == dbg_color[timing][i])
      {
        usedCol[i] = true;
        break;
      }
    }
  }
  // check if currently changed color was used somewhere else
  for(int i = 0; i < DEBUG_COLORS; ++i)
  {
    if (i != idx && myDbgColourSwatch[i]->getColor() == dbg_color[timing][color])
    {
      // if already used, change the other color to an unused one
      for(int j = 0; j < DEBUG_COLORS; ++j)
      {
        if(!usedCol[j])
        {
          myDbgColourSwatch[i]->setColor(dbg_color[timing][j]);
          myDbgColour[i]->setSelectedIndex(j);
          break;
        }
      }
    }
  }
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
void DeveloperDialog::handleDebugColours(string_view colors)
{
  for(int i = 0; i < DEBUG_COLORS && std::cmp_less(i, colors.length()); ++i)
  {
    switch(colors[i])
    {
      case 'r': handleDebugColours(i, 0); break;
      case 'o': handleDebugColours(i, 1); break;
      case 'y': handleDebugColours(i, 2); break;
      case 'g': handleDebugColours(i, 3); break;
      case 'p': handleDebugColours(i, 4); break;
      case 'b': handleDebugColours(i, 5); break;
      default:                            break;
    }
  }
}

