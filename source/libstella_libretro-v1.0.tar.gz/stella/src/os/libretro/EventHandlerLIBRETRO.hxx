//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#ifndef EVENT_HANDLER_LIBRETRO_HXX
#define EVENT_HANDLER_LIBRETRO_HXX

#include "EventHandler.hxx"

/**
  This class handles event collection from the point of view of the specific
  backend toolkit (LIBRETRO).  It converts from LIBRETRO-specific events into events
  that the Stella core can understand.

  @author  Stephen Anthony
*/
extern void update_input();

class EventHandlerLIBRETRO : public EventHandler
{
  public:
    /**
      Create a new LIBRETRO event handler object.
    */
    explicit EventHandlerLIBRETRO(OSystem& osystem) : EventHandler(osystem) { }
    ~EventHandlerLIBRETRO() override = default;

  protected:
    /**
      Collects and dispatches any pending events.  Called (with the input
      window already open) from EventHandler::pollInput(), which libretro.cxx
      drives once per frame.  update_input() lives in libretro.cxx, where the
      RetroArch input callbacks it samples live.
    */
    void pollEvent() override { update_input(); }

  private:
    // Following constructors and assignment operators not supported
    EventHandlerLIBRETRO() = delete;
    EventHandlerLIBRETRO(const EventHandlerLIBRETRO&) = delete;
    EventHandlerLIBRETRO(EventHandlerLIBRETRO&&) = delete;
    EventHandlerLIBRETRO& operator=(const EventHandlerLIBRETRO&) = delete;
    EventHandlerLIBRETRO& operator=(EventHandlerLIBRETRO&&) = delete;
};

#endif  // EVENT_HANDLER_LIBRETRO_HXX
