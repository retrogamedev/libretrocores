//============================================================================
//
//   SSSS    tt          lll  lll
//  SS  SS   tt           ll   ll
//  SS     tttttt  eeee   ll   ll   aaaa
//   SSSS    tt   ee  ee  ll   ll      aa
//      SS   tt   eeeeee  ll   ll   aaaaa  --  "An Atari 2600 VCS Emulator"
//  SS  SS   tt   ee      ll   ll  aa  aa
//   SSSS     ttt  eeeee llll llll  aaaaa
//
// Copyright (c) 1995-2026 by Bradford W. Mott, Stephen Anthony
// and the Stella Team
//
// See the file "License.txt" for information on usage and redistribution of
// this file, and for a DISCLAIMER OF ALL WARRANTIES.
//============================================================================

#include <array>
#include <io.h>

#include "AsciiFold.hxx"
#include "HomeFinder.hxx"
#include "FSNodeWINDOWS.hxx"

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
FSNodeWINDOWS::FSNodeWINDOWS(std::string_view path)
{
  if(path.empty() || path == "~")
  {
    _pathW = HomeFinder::getHomePathW();
  }
  else
  {
    _pathW = utf8ToWide(path);

    if(!_pathW.empty() && _pathW[0] == L'~')
      _pathW.replace(0, 1, HomeFinder::getHomePathW());
  }

  setFlags();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
FSNodeWINDOWS::FSNodeWINDOWS(std::wstring_view path)
{
  if(path.empty() || path == L"~")
  {
    _pathW = HomeFinder::getHomePathW();
  }
  else
  {
    _pathW = path;

    if(!_pathW.empty() && _pathW[0] == L'~')
      _pathW.replace(0, 1, HomeFinder::getHomePathW());
  }

  setFlags();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool FSNodeWINDOWS::setFlags()
{
  // Get absolute path
  std::array<wchar_t, MAX_PATH> buf{};
  if(GetFullPathNameW(_pathW.c_str(), MAX_PATH - 1, buf.data(), nullptr))
    _pathW = buf.data();

  const DWORD fileAttribs = GetFileAttributesW(_pathW.c_str());

  if(fileAttribs != INVALID_FILE_ATTRIBUTES) [[likely]]
  {
    // Check whether it is a directory, and whether the file actually exists
    _kind = (fileAttribs & FILE_ATTRIBUTE_DIRECTORY) != 0 ? NodeKind::Directory : NodeKind::File;

    // Add a trailing backslash, if necessary
    if(_kind == NodeKind::Directory && !_pathW.empty() && _pathW.back() != L'\\')
      _pathW += L'\\';
  }
  else
    _kind = NodeKind::Invalid;

  // Only after making sure that there's a trailing backslash
  // will we update the UTF8 paths
  _pathUtf8 = wideToUtf8(_pathW);
  _displayName = AsciiFold::toAscii(lastPathComponent(_pathUtf8));

  return _kind != NodeKind::Invalid;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
string FSNodeWINDOWS::getShortPath() const
{
  // If the path starts with the home directory, replace it with '~'
  const std::wstring& home = HomeFinder::getHomePathW();
  if(!home.empty() && _wcsnicmp(_pathW.data(), home.data(), home.size()) == 0)
  {
    const std::wstring_view suffix = std::wstring_view{_pathW}.substr(home.size());
    const bool needsSeparator = (!suffix.empty() && suffix[0] != FSNode::PATH_SEPARATOR);

    std::wstring pathW;
    pathW.reserve(1 + (needsSeparator ? 1 : 0) + suffix.size());

    pathW.push_back(L'~');
    if(needsSeparator)
      pathW.push_back(FSNode::PATH_SEPARATOR);

    pathW.append(suffix);

    return wideToUtf8(pathW);
  }

  return wideToUtf8(_pathW);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
size_t FSNodeWINDOWS::getSize() const
{
  if(!_size && isFile())
  {
    struct _stat st;
    _size = (_wstat(_pathW.c_str(), &st) == 0) ? st.st_size : 0;
  }
  return _size.value_or(0);
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
AbstractFSNodePtr FSNodeWINDOWS::getParent() const
{
  if(_kind == NodeKind::PseudoRoot)
    return nullptr;
  else if(_pathW.size() > 3)
    return std::make_shared<FSNodeWINDOWS>(stemPathComponentW(_pathW));
  else
    return std::make_shared<FSNodeWINDOWS>();
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool FSNodeWINDOWS::getChildren(AbstractFSList& fslist, ListMode mode) const
{
  if(_kind == NodeKind::File || _kind == NodeKind::Invalid)
    return false;

  if(_kind == NodeKind::Directory) [[likely]]
  {
    std::wstring search = _pathW;
    if (!search.empty() && search.back() != L'\\')
      search += L'\\';
    search += L'*';

    WIN32_FIND_DATAW desc;
    HANDLE handle = FindFirstFileExW(search.c_str(), FindExInfoBasic, &desc,
      FindExSearchNameMatch, nullptr, FIND_FIRST_EX_LARGE_FETCH);
    if(handle == INVALID_HANDLE_VALUE)
      return false;

    do {
      // Skip files starting with '.' (we assume empty filenames never occur)
      if(desc.cFileName[0] == L'.')
        continue;

      const bool isDir = (desc.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) != 0;

      if((!isDir && mode == FSNode::ListMode::DirectoriesOnly) ||
         (isDir  && mode == FSNode::ListMode::FilesOnly))
        continue;

      std::wstring full = _pathW;
      if (!full.empty() && full.back() != L'\\')
        full += L'\\';
      full += desc.cFileName;
      // Directories must end with a separator, matching setFlags() and the
      // POSIX backend.  BrowserDialog::getResult() builds child paths by
      // concatenating the directory path with a filename, so a missing
      // trailing separator produces an invalid path (e.g. "dircassette.bin").
      if(isDir)
        full += L'\\';

      FSNodeWINDOWS entry;
      entry._kind        = isDir ? NodeKind::Directory : NodeKind::File;
      entry._pathW       = std::move(full);
      entry._pathUtf8    = wideToUtf8(entry._pathW);
      // Derive the display name from the bare filename, not the full path:
      // directory paths carry a trailing separator (for internal path joins)
      // that must not leak into the name shown to the user.
      entry._displayName = AsciiFold::toAscii(wideToUtf8(desc.cFileName));
      entry._size        = (static_cast<size_t>(desc.nFileSizeHigh) << 32) |
                                                desc.nFileSizeLow;

      fslist.emplace_back(std::make_shared<FSNodeWINDOWS>(std::move(entry)));

    } while(FindNextFileW(handle, &desc));

    FindClose(handle);
  }
  else  // PseudoRoot: drive enumeration
  {
    const DWORD driveMask = GetLogicalDrives();

    for(int i = 0; i < 26; ++i)
    {
      if(!(driveMask & (1 << i)))
        continue;

      FSNodeWINDOWS entry;
      entry._kind        = NodeKind::Directory;
      entry._pathW       = { static_cast<wchar_t>(L'A' + i), L':', L'\\' };
      entry._pathUtf8    = wideToUtf8(entry._pathW);
      entry._displayName = string(1, static_cast<char>('A' + i));

      fslist.emplace_back(std::make_shared<FSNodeWINDOWS>(std::move(entry)));
    }
  }

  return true;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool FSNodeWINDOWS::exists() const
{
  return _waccess(_pathW.c_str(), 0 /*F_OK*/) == 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool FSNodeWINDOWS::isReadable() const
{
  return _waccess(_pathW.c_str(), 4 /*R_OK*/) == 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool FSNodeWINDOWS::isWritable() const
{
  return _waccess(_pathW.c_str(), 2 /*W_OK*/) == 0;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool FSNodeWINDOWS::makeDir()
{
  if(_kind != NodeKind::PseudoRoot && CreateDirectoryW(_pathW.c_str(), nullptr) != 0)
    return setFlags();

  return false;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
bool FSNodeWINDOWS::rename(string_view newfile)
{
  if(_kind != NodeKind::PseudoRoot)
  {
    std::wstring newfilePath = utf8ToWide(newfile);
    if(MoveFileW(_pathW.c_str(), newfilePath.c_str()) != 0) {
      _pathW = std::move(newfilePath);
      _size.reset();
      if(_pathW[0] == L'~')
        _pathW.replace(0, 1, HomeFinder::getHomePathW());

      return setFlags();
    }
  }
  return false;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
std::wstring FSNodeWINDOWS::utf8ToWide(std::string_view s)
{
  if(s.empty())
    return {};

  const int size = MultiByteToWideChar(
    CP_UTF8, 0,
    s.data(), static_cast<int>(s.size()),
    nullptr, 0);

  std::wstring w(size, L'\0');

  MultiByteToWideChar(
    CP_UTF8, 0,
    s.data(), static_cast<int>(s.size()),
    w.data(), size);

  return w;
}

// - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
std::string FSNodeWINDOWS::wideToUtf8(const std::wstring_view w)
{
  if(w.empty())
    return {};

  const int needed = WideCharToMultiByte(
    CP_UTF8, 0,
    w.data(), static_cast<int>(w.size()),
    nullptr, 0, nullptr, nullptr);

  std::string out(needed, '\0');

  WideCharToMultiByte(
    CP_UTF8, 0,
    w.data(), static_cast<int>(w.size()),
    out.data(), needed,
    nullptr, nullptr);

  return out;
}
